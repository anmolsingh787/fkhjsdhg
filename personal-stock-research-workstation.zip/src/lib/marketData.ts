import type { Candle, Instrument, Quote, Region, Timeframe } from "./types";

/* ------------------------------------------------------------------ *
 * Deterministic pseudo-random helpers
 * ------------------------------------------------------------------ */
function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a += 0x6d2b79f5;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const gauss = (r: () => number) => {
  const u = Math.max(1e-9, r());
  const v = r();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
};

/* ------------------------------------------------------------------ *
 * Instrument universe
 * ------------------------------------------------------------------ */
type Seed = [
  symbol: string,
  name: string,
  exchange: string,
  sector: string,
  base: number,
  vol: number,
  drift: number,
  mcap: number,
  pe: number,
  eps: number,
  beta: number,
  div: number,
  roe: number,
  de: number,
  margin: number,
  revG: number,
];

const IN_SEEDS: Seed[] = [
  ["RELIANCE", "Reliance Industries", "NSE", "Energy", 1428.5, 0.0128, 0.00042, 1935000, 24.8, 57.6, 0.92, 0.38, 9.1, 0.44, 8.4, 7.2],
  ["TCS", "Tata Consultancy Services", "NSE", "IT", 3184.2, 0.0119, 0.00028, 1152000, 26.4, 120.5, 0.74, 1.4, 46.2, 0.02, 19.1, 6.1],
  ["HDFCBANK", "HDFC Bank", "NSE", "Banks", 1712.4, 0.0124, 0.00051, 1302000, 19.2, 89.2, 0.88, 1.1, 17.4, 0.92, 22.8, 12.4],
  ["INFY", "Infosys", "NSE", "IT", 1562.8, 0.0131, 0.00031, 648000, 23.7, 65.9, 0.81, 2.2, 31.8, 0.08, 16.7, 8.9],
  ["ICICIBANK", "ICICI Bank", "NSE", "Banks", 1284.6, 0.0135, 0.00056, 905000, 18.4, 69.8, 0.96, 0.72, 18.6, 0.71, 24.1, 14.2],
  ["SBIN", "State Bank of India", "NSE", "Banks", 812.3, 0.0161, 0.00048, 724000, 10.6, 76.6, 1.14, 1.6, 19.8, 1.34, 17.2, 11.8],
  ["BHARTIARTL", "Bharti Airtel", "NSE", "Telecom", 1610.9, 0.0138, 0.00061, 952000, 39.1, 41.2, 0.79, 0.6, 15.3, 1.28, 16.4, 13.7],
  ["ITC", "ITC Ltd", "NSE", "FMCG", 448.7, 0.0108, 0.00024, 560000, 26.9, 16.7, 0.68, 3.1, 28.9, 0.01, 26.4, 6.8],
  ["LT", "Larsen & Toubro", "NSE", "Infra", 3562.1, 0.0143, 0.00058, 489000, 32.4, 109.9, 1.05, 0.9, 15.7, 0.96, 8.9, 16.4],
  ["TATAMOTORS", "Tata Motors", "NSE", "Auto", 712.4, 0.0196, 0.00066, 262000, 11.2, 63.6, 1.42, 0.5, 32.1, 0.74, 12.6, 21.3],
  ["MARUTI", "Maruti Suzuki", "NSE", "Auto", 12480.0, 0.0141, 0.00037, 392000, 27.8, 448.9, 0.87, 1.2, 17.9, 0.02, 10.4, 9.2],
  ["ASIANPAINT", "Asian Paints", "NSE", "Consumer", 2412.8, 0.0126, 0.00019, 231000, 46.2, 52.2, 0.72, 1.4, 27.6, 0.06, 14.1, 4.2],
  ["SUNPHARMA", "Sun Pharmaceutical", "NSE", "Pharma", 1642.6, 0.0134, 0.00049, 394000, 32.1, 51.2, 0.76, 0.8, 17.2, 0.04, 21.8, 11.6],
  ["TITAN", "Titan Company", "NSE", "Consumer", 3384.4, 0.0152, 0.00043, 300000, 78.4, 43.2, 1.02, 0.4, 33.4, 0.31, 10.2, 15.1],
  ["HINDUNILVR", "Hindustan Unilever", "NSE", "FMCG", 2288.9, 0.0113, 0.00016, 536000, 52.1, 43.9, 0.58, 1.8, 21.4, 0.02, 17.6, 3.1],
  ["BAJFINANCE", "Bajaj Finance", "NSE", "NBFC", 6892.0, 0.0172, 0.00054, 426000, 28.6, 241.1, 1.28, 0.4, 21.8, 3.42, 22.4, 24.8],
  ["ADANIENT", "Adani Enterprises", "NSE", "Conglomerate", 2384.6, 0.0248, 0.00062, 273000, 52.4, 45.5, 1.68, 0.2, 12.6, 1.86, 9.4, 26.2],
  ["WIPRO", "Wipro", "NSE", "IT", 542.3, 0.0142, 0.00021, 283000, 21.4, 25.3, 0.84, 0.5, 16.8, 0.12, 14.2, 4.4],
  ["TATASTEEL", "Tata Steel", "NSE", "Metals", 142.8, 0.0186, 0.00033, 178000, 18.9, 7.6, 1.46, 2.4, 9.2, 1.12, 6.1, 8.4],
  ["DMART", "Avenue Supermarts", "NSE", "Retail", 3612.7, 0.0164, 0.00041, 235000, 88.2, 40.9, 0.91, 0.0, 14.6, 0.06, 6.2, 18.9],
  ["ZOMATO", "Eternal (Zomato)", "NSE", "Internet", 246.8, 0.0264, 0.00092, 232000, 118.4, 2.1, 1.52, 0.0, 6.4, 0.02, 4.1, 62.4],
  ["HDFCLIFE", "HDFC Life Insurance", "NSE", "Insurance", 742.6, 0.0147, 0.00038, 159000, 72.4, 10.3, 0.69, 0.3, 8.9, 0.14, 5.8, 12.1],
  ["NIFTY50", "NIFTY 50 Index", "NSE", "Index", 24218.6, 0.0081, 0.00038, 0, 0, 0, 1, 0, 0, 0, 0, 0],
  ["SENSEX", "BSE SENSEX", "BSE", "Index", 79420.4, 0.0082, 0.00037, 0, 0, 0, 1, 0, 0, 0, 0, 0],
  ["BANKNIFTY", "NIFTY Bank Index", "NSE", "Index", 52140.8, 0.0104, 0.00041, 0, 0, 0, 1.18, 0, 0, 0, 0, 0],
  ["INDIAVIX", "India VIX", "NSE", "Volatility", 13.42, 0.0520, -0.0001, 0, 0, 0, -3.2, 0, 0, 0, 0, 0],
  ["NIFTYIT", "NIFTY IT Index", "NSE", "Index", 36180.2, 0.0112, 0.00029, 0, 0, 0, 0.82, 0, 0, 0, 0, 0],
];

const US_SEEDS: Seed[] = [
  ["AAPL", "Apple Inc.", "NASDAQ", "Technology", 232.84, 0.0129, 0.00054, 3520000, 34.8, 6.69, 1.12, 0.44, 56.2, 1.42, 26.4, 5.1],
  ["MSFT", "Microsoft Corp.", "NASDAQ", "Technology", 428.16, 0.0121, 0.00061, 3180000, 33.2, 12.89, 0.91, 0.72, 38.4, 0.32, 35.8, 14.2],
  ["NVDA", "NVIDIA Corp.", "NASDAQ", "Semiconductors", 138.62, 0.0268, 0.00142, 3410000, 52.4, 2.65, 1.68, 0.03, 91.2, 0.14, 54.8, 68.4],
  ["AMZN", "Amazon.com Inc.", "NASDAQ", "Consumer Disc.", 204.52, 0.0164, 0.00068, 2140000, 41.6, 4.92, 1.16, 0.0, 21.8, 0.48, 8.9, 11.8],
  ["GOOGL", "Alphabet Inc.", "NASDAQ", "Communication", 174.82, 0.0148, 0.00052, 2150000, 24.1, 7.25, 1.02, 0.42, 30.6, 0.08, 28.6, 12.4],
  ["META", "Meta Platforms", "NASDAQ", "Communication", 582.44, 0.0182, 0.00078, 1470000, 27.8, 20.96, 1.22, 0.4, 36.4, 0.28, 36.2, 18.9],
  ["TSLA", "Tesla Inc.", "NASDAQ", "Auto", 342.18, 0.0312, 0.00088, 1090000, 92.4, 3.70, 2.14, 0.0, 20.2, 0.18, 7.4, 4.2],
  ["AMD", "Advanced Micro Devices", "NASDAQ", "Semiconductors", 142.36, 0.0284, 0.00094, 231000, 46.2, 3.08, 1.74, 0.0, 6.4, 0.04, 8.6, 22.4],
  ["NFLX", "Netflix Inc.", "NASDAQ", "Communication", 898.42, 0.0194, 0.00071, 383000, 44.8, 20.05, 1.24, 0.0, 28.4, 0.62, 21.4, 13.6],
  ["JPM", "JPMorgan Chase", "NYSE", "Banks", 244.68, 0.0132, 0.00056, 686000, 13.4, 18.26, 1.08, 2.1, 17.2, 1.34, 34.8, 6.8],
  ["V", "Visa Inc.", "NYSE", "Financials", 312.24, 0.0114, 0.00048, 624000, 31.6, 9.88, 0.94, 0.72, 48.6, 0.42, 54.2, 9.4],
  ["UNH", "UnitedHealth Group", "NYSE", "Healthcare", 542.86, 0.0142, 0.00022, 498000, 32.4, 16.75, 0.62, 1.4, 24.2, 0.68, 6.1, 7.2],
  ["COST", "Costco Wholesale", "NASDAQ", "Consumer Staples", 942.68, 0.0121, 0.00058, 418000, 54.2, 17.39, 0.78, 0.5, 30.8, 0.24, 3.6, 7.4],
  ["XOM", "Exxon Mobil", "NYSE", "Energy", 118.42, 0.0152, 0.00031, 518000, 14.2, 8.34, 0.86, 3.3, 15.4, 0.22, 10.2, 2.4],
  ["LLY", "Eli Lilly & Co.", "NYSE", "Healthcare", 812.44, 0.0178, 0.00098, 772000, 78.4, 10.36, 0.42, 0.6, 42.6, 1.92, 28.4, 32.1],
  ["AVGO", "Broadcom Inc.", "NASDAQ", "Semiconductors", 218.62, 0.0231, 0.00112, 1020000, 62.4, 3.50, 1.18, 1.2, 32.4, 1.04, 32.1, 41.2],
  ["PLTR", "Palantir Technologies", "NASDAQ", "Software", 78.42, 0.0324, 0.00138, 178000, 212.4, 0.37, 1.82, 0.0, 12.4, 0.04, 18.2, 42.6],
  ["QQQ", "Invesco QQQ Trust", "NASDAQ", "ETF", 512.84, 0.0104, 0.00062, 0, 0, 0, 1.06, 0.6, 0, 0, 0, 0],
  ["SPY", "SPDR S&P 500 ETF", "NYSE", "ETF", 592.42, 0.0084, 0.00048, 0, 0, 0, 1.0, 1.2, 0, 0, 0, 0],
  ["SPX", "S&P 500 Index", "INDEX", "Index", 5921.4, 0.0080, 0.00046, 0, 0, 0, 1, 0, 0, 0, 0, 0],
  ["NDX", "Nasdaq 100 Index", "NASDAQ", "Index", 21184.6, 0.0102, 0.00064, 0, 0, 0, 1.12, 0, 0, 0, 0, 0],
  ["DJI", "Dow Jones Industrial", "DJ", "Index", 44212.8, 0.0074, 0.00034, 0, 0, 0, 0.92, 0, 0, 0, 0, 0],
  ["VIX", "CBOE Volatility Index", "CBOE", "Volatility", 14.86, 0.0580, -0.00012, 0, 0, 0, -3.6, 0, 0, 0, 0, 0],
];

function build(seed: Seed, region: Region): Instrument {
  const [symbol, name, exchange, sector, base, vol, drift, mcap, pe, eps, beta, div, roe, de, margin, revG] = seed;
  const r = rng(hash(symbol));
  return {
    symbol,
    name,
    exchange,
    currency: region === "IN" ? "INR" : "USD",
    region,
    kind: sector === "Index" ? "index" : sector === "ETF" ? "etf" : "stock",
    sector,
    mcap,
    base,
    vol,
    drift,
    pe: pe || undefined,
    pb: pe ? +(pe / (3 + r() * 6)).toFixed(2) : undefined,
    eps: eps || undefined,
    beta,
    divYield: div || undefined,
    roe: roe || undefined,
    roce: roe ? +(roe - 1 - r() * 4).toFixed(1) : undefined,
    debtEquity: de || undefined,
    netMargin: margin || undefined,
    revGrowth: revG || undefined,
    epsGrowth: revG ? +(revG * (1.1 + r() * 1.6)).toFixed(1) : undefined,
    fcf: eps ? +(eps * (0.4 + r() * 0.8)).toFixed(2) : undefined,
  };
}

export const INSTRUMENTS: Instrument[] = [...IN_SEEDS.map((s) => build(s, "IN")), ...US_SEEDS.map((s) => build(s, "US"))];
export const BY_SYMBOL: Record<string, Instrument> = Object.fromEntries(INSTRUMENTS.map((i) => [i.symbol, i]));
export const IN_STOCKS = INSTRUMENTS.filter((i) => i.region === "IN" && i.kind === "stock");
export const US_STOCKS = INSTRUMENTS.filter((i) => i.region === "US" && i.kind === "stock");
export const INDICES: Record<Region, string[]> = {
  IN: ["NIFTY50", "SENSEX", "BANKNIFTY", "INDIAVIX"],
  US: ["SPX", "NDX", "DJI", "VIX"],
};

/* ------------------------------------------------------------------ *
 * Session helpers
 * ------------------------------------------------------------------ */
export interface Zone {
  weekday: number;
  hour: number;
  minute: number;
  mins: number;
  label: string;
}

export function zonedNow(tz: string): Zone {
  const f = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
  const parts = f.formatToParts(new Date());
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  const wdMap: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  const hour = parseInt(get("hour"), 10) % 24;
  const minute = parseInt(get("minute"), 10);
  return {
    weekday: wdMap[get("weekday")] ?? 1,
    hour,
    minute,
    mins: hour * 60 + minute,
    label: `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`,
  };
}

export type Phase = "pre" | "open" | "closed" | "post";

export function session(region: Region): { phase: Phase; label: string; tz: Zone } {
  const z = zonedNow(region === "IN" ? "Asia/Kolkata" : "America/New_York");
  const weekend = z.weekday === 0 || z.weekday === 6;
  if (region === "IN") {
    if (weekend) return { phase: "closed", label: "Weekend · Closed", tz: z };
    if (z.mins >= 555 && z.mins <= 930) return { phase: "open", label: "NSE Open", tz: z };
    if (z.mins < 555) return { phase: "pre", label: "Pre-open", tz: z };
    return { phase: "closed", label: "NSE Closed", tz: z };
  }
  if (weekend) return { phase: "closed", label: "Weekend · Closed", tz: z };
  if (z.mins >= 570 && z.mins <= 960) return { phase: "open", label: "US Open", tz: z };
  if (z.mins < 570) return { phase: "pre", label: "Pre-market", tz: z };
  return { phase: "post", label: "After-hours", tz: z };
}

export function isOpen(region: Region) {
  return session(region).phase === "open";
}

/* ------------------------------------------------------------------ *
 * Candle synthesis
 * ------------------------------------------------------------------ */
const TF_MS: Record<Timeframe, number> = {
  "1m": 60e3,
  "3m": 180e3,
  "5m": 300e3,
  "15m": 900e3,
  "30m": 1800e3,
  "1H": 3600e3,
  "2H": 7200e3,
  "4H": 14400e3,
  "1D": 864e5,
  "1W": 6048e5,
  "1M": 2592e6,
};

export const TIMEFRAMES: Timeframe[] = ["1m", "3m", "5m", "15m", "30m", "1H", "2H", "4H", "1D", "1W", "1M"];

const seriesCache = new Map<string, Candle[]>();

export function getSeries(symbol: string, tf: Timeframe, limit = 260): Candle[] {
  const inst = BY_SYMBOL[symbol];
  if (!inst) return [];
  const key = `${symbol}|${tf}|${limit}`;
  const hit = seriesCache.get(key);
  if (hit) return hit;

  const r = rng(hash(key));
  const scale = tf === "1D" ? 1 : tf === "1W" ? 2.1 : tf === "1M" ? 3.2 : Math.sqrt(TF_MS[tf] / TF_MS["1D"]);
  const step = TF_MS[tf];
  const drift = inst.drift * scale * 0.42;
  const vola = inst.vol * scale;

  // walk backwards from a "current" price so the newest bar lines up with the live quote
  const path: number[] = [];
  let p = inst.base;
  for (let i = 0; i < limit; i++) {
    path.push(p);
    p = p / (1 + drift + gauss(r) * vola);
  }
  path.reverse();

  const candles: Candle[] = [];
  const now = Date.now();
  const startT = now - (limit - 1) * step;
  for (let i = 0; i < limit; i++) {
    const close = path[i];
    const prevClose = i === 0 ? close / (1 + gauss(r) * vola) : path[i - 1];
    const open = i === 0 ? prevClose * (1 + gauss(r) * vola * 0.25) : prevClose;
    const body = Math.abs(close - open);
    const wick = (body + close * vola * (0.5 + r())) * (0.55 + r() * 0.9);
    const high = Math.max(open, close) + wick * (0.25 + r() * 0.6);
    const low = Math.min(open, close) - wick * (0.25 + r() * 0.6);
    const baseVol = inst.kind === "stock" ? 1.6e6 : 0;
    const volume = Math.max(1000, Math.round(baseVol * (0.6 + r() * 1.1) * (1 + (body / (close * vola + 1e-9)) * 0.5)));
    candles.push({ time: Math.floor((startT + i * step) / 1000), open, high, low, close, volume });
  }
  seriesCache.set(key, candles);
  return candles;
}

/* ------------------------------------------------------------------ *
 * Live quote engine
 * ------------------------------------------------------------------ */
interface TickState {
  price: number;
  prevClose: number;
  open: number;
  high: number;
  low: number;
  volume: number;
  avgVolume: number;
  ts: number;
}

const ticks = new Map<string, TickState>();

function seedTick(symbol: string): TickState {
  const inst = BY_SYMBOL[symbol];
  const day = getSeries(symbol, "1D", 120);
  const last = day[day.length - 1];
  const avgVolume = day.slice(-20).reduce((a, b) => a + b.volume, 0) / 20;
  const s = session(inst.region);
  const frac = s.phase === "open" ? 0.55 : 0.18;
  const prevClose = last.close;
  const gap = gauss(rng(hash(symbol + "gap"))) * inst.vol * prevClose * 0.6;
  const open = prevClose + gap;
  const move = gauss(rng(hash(symbol + "mv"))) * inst.vol * prevClose * (s.phase === "open" ? 1.15 : 0.4);
  const price = open + move;
  return {
    price,
    prevClose,
    open,
    high: Math.max(open, price) + Math.abs(move) * 0.35 + prevClose * inst.vol * 0.12,
    low: Math.min(open, price) - Math.abs(move) * 0.3 - prevClose * inst.vol * 0.1,
    volume: Math.round(avgVolume * frac * (0.7 + rng(hash(symbol + "v"))())),
    avgVolume,
    ts: Date.now(),
  };
}

function tickOf(symbol: string): TickState {
  let t = ticks.get(symbol);
  if (!t) {
    t = seedTick(symbol);
    ticks.set(symbol, t);
  }
  return t;
}

export function quote(symbol: string): Quote {
  const inst = BY_SYMBOL[symbol];
  if (!inst)
    return {
      symbol,
      price: 0,
      change: 0,
      changePercent: 0,
      open: 0,
      high: 0,
      low: 0,
      previousClose: 0,
      volume: 0,
      avgVolume: 0,
      timestamp: Date.now(),
    };
  const t = tickOf(symbol);
  const change = t.price - t.prevClose;
  return {
    symbol,
    price: t.price,
    change,
    changePercent: (change / t.prevClose) * 100,
    open: t.open,
    high: t.high,
    low: t.low,
    previousClose: t.prevClose,
    volume: t.volume,
    avgVolume: t.avgVolume,
    timestamp: t.ts,
  };
}

export function allQuotes(): Quote[] {
  return INSTRUMENTS.map((i) => quote(i.symbol));
}

export function quotesFor(symbols: string[]): Quote[] {
  return symbols.map(quote);
}

export function quotesMap(): Record<string, Quote> {
  const out: Record<string, Quote> = {};
  for (const i of INSTRUMENTS) out[i.symbol] = quote(i.symbol);
  return out;
}

const listeners = new Set<() => void>();
let engineStarted = false;

export function startEngine() {
  if (engineStarted) return;
  engineStarted = true;
  window.setInterval(() => {
    const t = Date.now();
    for (const inst of INSTRUMENTS) {
      const st = tickOf(inst.symbol);
      const live = session(inst.region).phase === "open";
      const amp = inst.vol * (live ? 0.16 : 0.03);
      const drift = live ? inst.drift * 0.05 : 0;
      const next = st.price * (1 + drift + gauss(Math.random) * amp);
      st.price = Math.max(0.5, next);
      st.high = Math.max(st.high, st.price);
      st.low = Math.min(st.low, st.price);
      st.volume += live ? Math.round(st.avgVolume * 0.00042 * (0.5 + Math.random())) : 0;
      st.ts = t;
    }
    listeners.forEach((l) => l());
  }, 1600);
}

export function subscribeTicks(cb: () => void): () => void {
  listeners.add(cb);
  startEngine();
  return () => listeners.delete(cb);
}

/* ------------------------------------------------------------------ *
 * Aggregations
 * ------------------------------------------------------------------ */
export function sparkline(symbol: string, points = 32, tf: Timeframe = "1D"): number[] {
  const s = getSeries(symbol, tf, Math.max(40, points));
  const tail = s.slice(-points).map((c) => c.close);
  const live = quote(symbol).price;
  return [...tail.slice(0, -1), live];
}

export function regionChange(region: Region): number {
  const idx = region === "IN" ? "NIFTY50" : "SPX";
  return quote(idx).changePercent;
}

export function breadth(region: Region) {
  const list = (region === "IN" ? IN_STOCKS : US_STOCKS).map((i) => quote(i.symbol));
  const adv = list.filter((q) => q.changePercent > 0).length;
  const dec = list.filter((q) => q.changePercent < 0).length;
  const unc = list.length - adv - dec;
  return { adv, dec, unc, total: list.length, ratio: dec ? adv / dec : adv ? 4 : 1 };
}

export function movers(region: Region, n = 6) {
  const list = (region === "IN" ? IN_STOCKS : US_STOCKS).map((i) => ({ inst: i, q: quote(i.symbol) }));
  const sorted = [...list].sort((a, b) => b.q.changePercent - a.q.changePercent);
  return { gainers: sorted.slice(0, n), losers: sorted.slice(-n).reverse() };
}

export function sectorPerformance(region: Region) {
  const map = new Map<string, { sum: number; n: number; mcap: number }>();
  for (const i of region === "IN" ? IN_STOCKS : US_STOCKS) {
    const q = quote(i.symbol);
    const cur = map.get(i.sector) ?? { sum: 0, n: 0, mcap: 0 };
    const w = Math.log10(Math.max(10, i.mcap));
    cur.sum += q.changePercent * w;
    cur.mcap += i.mcap;
    cur.n += w;
    map.set(i.sector, cur);
  }
  return [...map.entries()]
    .map(([sector, v]) => ({ sector, change: v.sum / (v.n || 1) }))
    .sort((a, b) => b.change - a.change);
}

export function marketMood(region: Region): number {
  const idxChange = regionChange(region);
  const b = breadth(region);
  const breadthScore = (b.adv / Math.max(1, b.adv + b.dec)) * 100;
  const volSym = region === "IN" ? "INDIAVIX" : "VIX";
  const vix = quote(volSym).changePercent;
  const wl = region === "IN" ? IN_STOCKS.slice(0, 8) : US_STOCKS.slice(0, 8);
  const mom = wl.reduce((a, i) => a + quote(i.symbol).changePercent, 0) / wl.length;
  const score =
    50 + idxChange * 9 + (breadthScore - 50) * 0.24 + mom * 6 - vix * 1.6;
  return Math.max(2, Math.min(98, Math.round(score)));
}

export function moodLabel(score: number): { label: string; tone: "neg" | "warn" | "info" | "pos" } {
  if (score < 20) return { label: "Extreme Risk", tone: "neg" };
  if (score < 40) return { label: "Bearish", tone: "neg" };
  if (score <= 60) return { label: "Neutral", tone: "info" };
  if (score <= 80) return { label: "Bullish", tone: "pos" };
  return { label: "Strong Bullish", tone: "pos" };
}

/* ------------------------------------------------------------------ *
 * Format helpers
 * ------------------------------------------------------------------ */
export function fmtPrice(v: number, currency: "INR" | "USD" = "INR", digits?: number) {
  const d = digits ?? (Math.abs(v) >= 10 ? 2 : 3);
  const sym = currency === "INR" ? "₹" : "$";
  return `${sym}${v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d })}`;
}

export function fmtNum(v: number, digits = 2) {
  return v.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

export function fmtCompact(v: number, currency: "INR" | "USD" = "USD") {
  const abs = Math.abs(v);
  if (currency === "INR") {
    if (abs >= 1e7) return `₹${(v / 1e7).toFixed(2)}Cr`;
    if (abs >= 1e5) return `₹${(v / 1e5).toFixed(2)}L`;
    if (abs >= 1e3) return `₹${(v / 1e3).toFixed(1)}K`;
    return `₹${v.toFixed(0)}`;
  }
  if (abs >= 1e12) return `$${(v / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `$${(v / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `$${(v / 1e6).toFixed(1)}M`;
  if (abs >= 1e3) return `$${(v / 1e3).toFixed(1)}K`;
  return `$${v.toFixed(0)}`;
}

export function fmtVol(v: number) {
  if (v >= 1e9) return `${(v / 1e9).toFixed(2)}B`;
  if (v >= 1e6) return `${(v / 1e6).toFixed(2)}M`;
  if (v >= 1e3) return `${(v / 1e3).toFixed(1)}K`;
  return String(Math.round(v));
}

export function fmtSigned(v: number, digits = 2) {
  return `${v >= 0 ? "+" : "−"}${Math.abs(v).toFixed(digits)}`;
}

export function searchSymbols(q: string): Instrument[] {
  const s = q.trim().toLowerCase();
  if (!s) return [];
  return INSTRUMENTS.filter(
    (i) => i.symbol.toLowerCase().includes(s) || i.name.toLowerCase().includes(s),
  ).slice(0, 12);
}
