import { useMemo, useState } from "react";
import { actions, useApp, useTick } from "../lib/store";
import { usePortfolio } from "../lib/portfolio";
import {
  BY_SYMBOL,
  INDICES,
  breadth,
  fmtCompact,
  fmtSigned,
  marketMood,
  moodLabel,
  movers,
  quote,
  session,
  sparkline,
} from "../lib/marketData";
import { AreaChart, BreadthCard, Donut, KpiCard, MoversList, RadialGauge, SectorBars, WatchlistTable } from "../components/market/widgets";
import { CompanionCard } from "../components/anime/Companion";
import { Badge, Card, CardHead, GhostButton, Icon, Segmented } from "../components/ui/primitives";
import { cn } from "../utils/cn";
import type { Region } from "../lib/types";

export function ScreenHead({ title, sub, right }: { title: string; sub?: string; right?: React.ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="font-display text-[22px] font-extrabold tracking-[-0.03em] text-ink">{title}</h2>
        {sub && <p className="mt-0.5 text-[12.5px] text-ink2">{sub}</p>}
      </div>
      {right && <div className="flex flex-wrap items-center gap-2">{right}</div>}
    </div>
  );
}

const EARNINGS = [
  { symbol: "HDFCBANK", when: "Today · After close", est: "₹1,840 revenue cr" },
  { symbol: "TCS", when: "Tomorrow · Pre-open", est: "EPS ₹32.10" },
  { symbol: "NVDA", when: "In 3 days · After close", est: "EPS $0.84" },
  { symbol: "INFY", when: "In 5 days", est: "Deal wins TCV" },
  { symbol: "TATAMOTORS", when: "In 6 days", est: "JLR margins" },
];

export function Overview() {
  useTick();
  const s = useApp();
  const region = s.settings.region;
  const pf = usePortfolio(s.transactions);
  const [period, setPeriod] = useState<"1W" | "1M" | "3M" | "6M" | "1Y">("1M");
  const mood = marketMood(region);
  const moodInfo = moodLabel(mood);
  const idxSymbol = INDICES[region][0];
  const idxSeries = useMemo(() => {
    const tf = period === "1W" ? "15m" : period === "1M" ? "1D" : "1W";
    const pts = { "1W": 40, "1M": 30, "3M": 45, "6M": 52, "1Y": 52 }[period];
    const raw = sparkline(idxSymbol, pts, tf as "15m" | "1D" | "1W");
    return raw;
  }, [idxSymbol, period]);
  const idxQ = quote(idxSymbol);
  const mv = movers(region, 5);
  const b = breadth(region);
  const sess = session(region);

  const labels = useMemo(() => {
    const n = idxSeries.length;
    const fmt = period === "1W" ? { hour: "2-digit", minute: "2-digit" } : { day: "2-digit", month: "short" };
    return [0, 0.25, 0.5, 0.75, 1].map((f) => {
      const d = new Date(Date.now() - (1 - f) * (period === "1W" ? 5 * 864e5 : period === "1M" ? 30 * 864e5 : period === "3M" ? 90 * 864e5 : period === "6M" ? 180 * 864e5 : 365 * 864e5));
      return d.toLocaleDateString("en-US", fmt as Intl.DateTimeFormatOptions);
    }).map((l, i) => (i === 0 ? l : l)).slice(0, Math.max(2, Math.min(5, n)));
  }, [idxSeries.length, period]);

  return (
    <div className="anim-page space-y-4">
      {/* KPI row */}
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <KpiCard
          label="Portfolio value"
          value={fmtCompact(pf.value + pf.cash, "INR")}
          sub={`${pf.holdings.length} positions · ${region === "IN" ? "INR" : "USD"} book`}
          icon="portfolio"
          delta={pf.totalPnlPct}
          spark={sparkline(idxSymbol, 30)}
        />
        <KpiCard
          label="Today's P&L"
          value={fmtSigned(pf.dayPnl, 0)}
          sub={`${b.adv} up · ${b.dec} down in universe`}
          icon={pf.dayPnl >= 0 ? "trendUp" : "trendDown"}
          tone={pf.dayPnl >= 0 ? "pos" : "neg"}
          delta={pf.dayPnlPct}
          spark={sparkline(INDICES[region][1], 30)}
        />
        <KpiCard
          label="Total return"
          value={`${fmtSigned(pf.totalPnlPct)}%`}
          sub={`${fmtCompact(pf.totalPnl, "INR")} unrealised + ${fmtCompact(pf.realized, "INR")} booked`}
          icon="analytics"
          tone={pf.totalPnl >= 0 ? "pos" : "neg"}
          delta={pf.totalPnlPct}
          spark={sparkline(INDICES[region][2], 30)}
        />
        <Card hover className="flex items-center justify-between">
          <div>
            <p className="text-[12px] font-semibold text-ink2">Market mood</p>
            <p className="tabnum mt-2 font-display text-[25px] font-extrabold leading-none tracking-[-0.025em] text-ink">{mood}</p>
            <div className="mt-2">
              <Badge tone={moodInfo.tone}>{moodInfo.label}</Badge>
            </div>
            <p className="mt-2 text-[10px] leading-tight text-ink3">Custom visualisation · not a prediction</p>
          </div>
          <RadialGauge value={mood} label="" size={92} />
        </Card>
      </div>

      {/* Performance + companion */}
      <div className="grid gap-3 xl:grid-cols-[minmax(0,2.1fr)_minmax(0,1fr)]">
        <Card>
          <CardHead
            title={region === "IN" ? "NIFTY 50 performance" : "S&P 500 performance"}
            sub={`${idxQ.price.toFixed(2)} · ${fmtSigned(idxQ.changePercent)}% today · ${sess.label}`}
            icon="markets"
            right={
              <>
                <Segmented
                  size="sm"
                  value={period}
                  onChange={setPeriod}
                  options={[
                    { value: "1W", label: "1W" },
                    { value: "1M", label: "1M" },
                    { value: "3M", label: "3M" },
                    { value: "6M", label: "6M" },
                    { value: "1Y", label: "1Y" },
                  ]}
                />
                <GhostButton onClick={() => actions.openSymbol(idxSymbol, "chart")}>
                  Pro chart <Icon name="arrowUpRight" size={12} />
                </GhostButton>
              </>
            }
          />
          <div className="mb-2 flex flex-wrap gap-4 text-[11px]">
            <span className="flex items-center gap-1.5 text-ink3">
              <span className="h-2 w-2 rounded-full bg-brand" /> {BY_SYMBOL[idxSymbol]?.name}
            </span>
            <span className="flex items-center gap-1.5 text-ink3">
              <span className="h-2 w-2 rounded-full bg-line2" /> Previous close {idxQ.previousClose.toFixed(2)}
            </span>
            <span className="flex items-center gap-1.5 text-ink3">
              <Icon name="wave" size={12} /> Breadth {b.adv}:{b.dec}
            </span>
          </div>
          <AreaChart data={idxSeries} labels={labels} baseline={idxQ.previousClose} height={196} color={idxQ.changePercent >= 0 ? "#27A66A" : "#E35D68"} />
        </Card>

        {s.settings.anime !== "off" ? (
          <CompanionCard
            score={mood}
            state={
              s.settings.anime === "minimal"
                ? mood >= 55
                  ? "mildBull"
                  : mood <= 45
                    ? "mildBear"
                    : "neutral"
                : companionState(mood, idxQ.changePercent, sess.phase === "open", s.connected)
            }
            onOpenSettings={() => actions.navigate("settings")}
          />
        ) : (
          <Card>
            <CardHead title="Market mood" sub="Companion disabled in settings" icon="spark" />
            <div className="flex justify-center py-4">
              <RadialGauge value={mood} label={moodInfo.label} sub="custom score" />
            </div>
          </Card>
        )}
      </div>

      {/* Watchlist / movers / alerts */}
      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)_minmax(0,1fr)]">
        <Card>
          <CardHead
            title="Watchlist"
            sub={s.watchlists.find((w) => w.id === s.activeWatchlist)?.name ?? "India Core"}
            icon="watchlist"
            right={
              <GhostButton onClick={() => actions.navigate("watchlists")}>
                All lists <Icon name="chevronRight" size={12} />
              </GhostButton>
            }
          />
          <WatchlistTable symbols={(s.watchlists.find((w) => w.id === s.activeWatchlist)?.symbols ?? []).slice(0, 7)} density={s.settings.density} />
        </Card>

        <Card>
          <CardHead title="Top movers" sub={`${region === "IN" ? "NSE" : "US"} universe · today`} icon="flame" />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.07em] text-pos">Gainers</p>
              <MoversList items={mv.gainers} kind="gain" />
            </div>
            <div>
              <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.07em] text-neg">Losers</p>
              <MoversList items={mv.losers} kind="lose" />
            </div>
          </div>
        </Card>

        <Card>
          <CardHead
            title="Alerts & signals"
            sub={`${s.alerts.filter((a) => a.active).length} active rules`}
            icon="alerts"
            right={
              <GhostButton onClick={() => actions.navigate("alerts")}>
                Manage <Icon name="chevronRight" size={12} />
              </GhostButton>
            }
          />
          <div className="space-y-1.5">
            {s.alerts.slice(0, 4).map((a) => (
              <div key={a.id} className="flex items-start gap-2 rounded-[12px] bg-muted px-2.5 py-2">
                <span className={cn("mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full", a.triggeredAt ? "bg-possoft text-pos" : "bg-brandsoft text-brand")}>
                  <Icon name={a.triggeredAt ? "check" : "bell"} size={12} />
                </span>
                <div className="min-w-0">
                  <p className="truncate text-[11.5px] font-semibold text-ink">{a.message}</p>
                  <p className="text-[10px] text-ink3">
                    {a.condition.replace(/_/g, " ")} · {a.frequency.replace(/_/g, " ")}
                  </p>
                </div>
              </div>
            ))}
            {s.notifications.slice(0, 2).map((n) => (
              <div key={n.id} className="flex items-start gap-2 rounded-[12px] border border-line px-2.5 py-2">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-warnsoft text-warn">
                  <Icon name="zap" size={12} />
                </span>
                <div className="min-w-0">
                  <p className="truncate text-[11.5px] font-semibold text-ink">{n.title}</p>
                  <p className="truncate text-[10px] text-ink3">{n.body}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Sector / breadth / events */}
      <div className="grid gap-3 xl:grid-cols-3">
        <Card>
          <CardHead title="Sector performance" sub="Cap-weighted, intraday" icon="heatmap" />
          <SectorBars region={region} />
        </Card>
        <Card>
          <CardHead title="Market breadth" sub="Advances vs declines" icon="wave" />
          <BreadthCard region={region} />
          <div className="mt-4 border-t border-line pt-3">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">Portfolio mix</p>
            <Donut items={pf.sectorMix.slice(0, 5)} size={104} thickness={13} />
          </div>
        </Card>
        <Card>
          <CardHead
            title="Upcoming events"
            sub="Earnings & results calendar"
            icon="calendar"
            right={<GhostButton onClick={() => actions.navigate("calendar")}>Calendar</GhostButton>}
          />
          <div className="space-y-1.5">
            {EARNINGS.map((e) => (
              <button
                key={e.symbol}
                onClick={() => actions.openSymbol(e.symbol, "chart")}
                className="flex w-full items-center gap-2.5 rounded-[12px] px-2 py-1.5 text-left transition-colors hover:bg-muted"
              >
                <span className="flex h-8 w-8 shrink-0 flex-col items-center justify-center rounded-[10px] bg-brandsoft text-brand">
                  <span className="text-[9px] font-bold leading-none">Q3</span>
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12px] font-semibold text-ink">{e.symbol}</span>
                  <span className="block truncate text-[10.5px] text-ink3">{e.when}</span>
                </span>
                <span className="tabnum shrink-0 text-[10.5px] text-ink3">{e.est}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>

      <p className="px-1 pb-1 text-center text-[10.5px] text-ink3">
        For personal research and informational purposes only. Not investment advice.
      </p>
    </div>
  );
}

function companionState(score: number, idxChange: number, open: boolean, connected: boolean) {
  if (!connected) return "disconnected" as const;
  if (!open) return "closed" as const;
  if (idxChange <= -3) return "crash" as const;
  if (idxChange >= 2.5) return "rally" as const;
  if (score <= 22) return "strongBear" as const;
  if (score <= 42) return "mildBear" as const;
  if (score >= 82) return "strongBull" as const;
  if (score >= 66) return "breakout" as const;
  if (score >= 56) return "mildBull" as const;
  return "neutral" as const;
}

export function RegionToggle({ value, onChange }: { value: Region; onChange: (r: Region) => void }) {
  return (
    <Segmented
      value={value}
      onChange={onChange}
      options={[
        { value: "IN", label: "India" },
        { value: "US", label: "USA" },
      ]}
    />
  );
}
