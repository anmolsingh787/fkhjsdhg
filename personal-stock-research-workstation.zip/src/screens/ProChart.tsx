import { useEffect, useMemo, useRef, useState } from "react";
import { actions, useApp, useTick, type Drawing } from "../lib/store";
import { BY_SYMBOL, TIMEFRAMES, getSeries, quote, session } from "../lib/marketData";
import {
  INDICATOR_CATALOG,
  INDICATOR_GROUPS,
  adLine,
  atr,
  awesomeOsc,
  bbWidth,
  bollinger,
  cci,
  chaikinVol,
  cmf,
  closes,
  donchian,
  ema,
  hma,
  histVol,
  ichimoku,
  keltner,
  linReg,
  maRibbon,
  macd,
  mfi,
  momentum,
  obv,
  ppo,
  psar,
  relVolume,
  renko,
  rangeBars,
  roc,
  rsi,
  rvi,
  sma,
  stdev,
  stochRsi,
  stochastic,
  supertrend,
  trix,
  ultimateOsc,
  volumeOsc,
  vwap,
  vwma,
  williamsR,
  wma,
  type Pt,
} from "../lib/indicators";
import { PriceCanvas, SubPane, heikin, useView } from "../components/charts/chartEngine";
import { WatchlistTable } from "../components/market/widgets";
import { FloatingCompanion } from "../components/anime/Companion";
import { Badge, GhostButton, Icon, IconButton, Segmented } from "../components/ui/primitives";
import { cn } from "../utils/cn";
import type { ChartType, Timeframe } from "../lib/types";

const CHART_TYPES: { value: ChartType; label: string }[] = [
  { value: "candles", label: "Candlestick" },
  { value: "hollow", label: "Hollow candles" },
  { value: "bars", label: "OHLC bars" },
  { value: "hlc", label: "HLC bars" },
  { value: "line", label: "Line" },
  { value: "area", label: "Area" },
  { value: "baseline", label: "Baseline" },
  { value: "histogram", label: "Histogram" },
  { value: "heikin", label: "Heikin-Ashi" },
  { value: "renko", label: "Renko" },
  { value: "kagi", label: "Kagi" },
  { value: "pnf", label: "Point & Figure" },
  { value: "range", label: "Range bars" },
  { value: "step", label: "Step line" },
  { value: "mountain", label: "Mountain" },
];

const TOOLS = [
  { id: "trend", label: "Trend line", icon: "chart" },
  { id: "hline", label: "Horizontal line", icon: "analytics" },
  { id: "vline", label: "Vertical line", icon: "analytics" },
  { id: "ray", label: "Ray", icon: "arrowUpRight" },
  { id: "extended", label: "Extended line", icon: "arrowUpRight" },
  { id: "rect", label: "Rectangle", icon: "overview" },
  { id: "circle", label: "Circle", icon: "gauge" },
  { id: "ellipse", label: "Ellipse", icon: "gauge" },
  { id: "arrow", label: "Arrow", icon: "arrowUp" },
  { id: "text", label: "Text", icon: "journal" },
  { id: "note", label: "Note", icon: "journal" },
  { id: "priceLabel", label: "Price label", icon: "tag" },
  { id: "channel", label: "Parallel channel", icon: "layers" },
  { id: "fib", label: "Fib retracement", icon: "sliders" },
  { id: "fibext", label: "Fib extension", icon: "sliders" },
  { id: "fibchan", label: "Fib channel", icon: "sliders" },
  { id: "rr", label: "Risk / reward box", icon: "overview" },
  { id: "long", label: "Long position", icon: "trendUp" },
  { id: "short", label: "Short position", icon: "trendDown" },
  { id: "support", label: "Support zone", icon: "trendUp" },
  { id: "resistance", label: "Resistance zone", icon: "trendDown" },
  { id: "brush", label: "Brush", icon: "wave" },
  { id: "measure", label: "Measure", icon: "sliders" },
  { id: "daterange", label: "Date range", icon: "calendar" },
  { id: "pricerange", label: "Price range", icon: "analytics" },
  { id: "regression", label: "Regression channel", icon: "analytics" },
];

const OVERLAY_COLORS = ["#8066FF", "#E9A23B", "#27A66A", "#6D72E8", "#E35D68", "#0EA5A5", "#A855F7"];

function Popover({
  label,
  icon,
  children,
  active,
  width = "w-[268px]",
}: {
  label: string;
  icon: string;
  children: (close: () => void) => React.ReactNode;
  active?: boolean;
  width?: string;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11.5px] font-medium transition-colors",
          open || active ? "border-brand bg-brandsoft text-brand" : "border-line bg-shell text-ink2 hover:border-line2 hover:text-ink",
        )}
      >
        <Icon name={icon} size={13} />
        {label}
        <Icon name="chevronDown" size={11} className="opacity-60" />
      </button>
      {open && (
        <div className={cn("anim-pop absolute left-0 top-9 z-40 max-h-[380px] overflow-y-auto rounded-[16px] border border-line bg-shell p-2 shadow-[0_20px_60px_rgba(28,24,54,0.16)]", width)}>
          {children(() => setOpen(false))}
        </div>
      )}
    </div>
  );
}

export function ProChart() {
  useTick();
  const s = useApp();
  const symbol = s.symbol;
  const inst = BY_SYMBOL[symbol];
  const q = quote(symbol);
  const sess = session(inst?.region ?? "IN");
  const tf = s.timeframe;
  const base = getSeries(symbol, tf, 320);
  const candles = useMemo(() => {
    if (s.chartType === "heikin") return heikin(base);
    if (s.chartType === "renko") return renko(base, 0.01);
    if (s.chartType === "range") return rangeBars(base, 0.007);
    return base;
  }, [base, s.chartType]);
  const [view, setView] = useView(candles.length, 130);
  const [tool, setTool] = useState<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [tab, setTab] = useState<"overview" | "financials" | "notes" | "technical">("overview");
  const shellRef = useRef<HTMLDivElement>(null);
  const [flash, setFlash] = useState("");
  const prevPrice = useRef(q.price);

  const drawingsKey = `${symbol}|${tf}`;
  const drawings = s.drawings[drawingsKey] ?? [];

  useEffect(() => {
    if (q.price === prevPrice.current) return;
    setFlash(q.price > prevPrice.current ? "flash-pos" : "flash-neg");
    prevPrice.current = q.price;
    const t = window.setTimeout(() => setFlash(""), 520);
    return () => window.clearTimeout(t);
  }, [q.price]);

  /* ---------------------------- indicators ---------------------------- */
  const src = useMemo(() => closes(base), [base]);
  const overlays = useMemo(() => {
    const out: { label: string; data: Pt[]; color: string; band?: boolean; fillTo?: Pt[]; fillColor?: string; dashed?: boolean; dots?: boolean; width?: number }[] = [];
    let ci = 0;
    const next = () => OVERLAY_COLORS[ci++ % OVERLAY_COLORS.length];
    for (const id of s.activeIndicators) {
      switch (id) {
        case "sma20": out.push({ label: "SMA 20", data: sma(src, 20), color: next() }); break;
        case "sma50": out.push({ label: "SMA 50", data: sma(src, 50), color: next() }); break;
        case "sma200": out.push({ label: "SMA 200", data: sma(src, 200), color: next(), width: 1.8 }); break;
        case "ema9": out.push({ label: "EMA 9", data: ema(src, 9), color: next() }); break;
        case "ema21": out.push({ label: "EMA 21", data: ema(src, 21), color: next() }); break;
        case "ema50": out.push({ label: "EMA 50", data: ema(src, 50), color: next() }); break;
        case "wma20": out.push({ label: "WMA 20", data: wma(src, 20), color: next() }); break;
        case "vwma20": out.push({ label: "VWMA 20", data: vwma(base, 20), color: next() }); break;
        case "hma21": out.push({ label: "HMA 21", data: hma(src, 21), color: next() }); break;
        case "vwap": out.push({ label: "VWAP", data: vwap(base), color: next(), dashed: true }); break;
        case "bb": {
          const b = bollinger(src, 20, 2);
          out.push({ label: "BB upper", data: b.upper, color: "#8066FF" });
          out.push({ label: "BB basis", data: b.mid, color: "#A4A2AB", dashed: true });
          out.push({ label: "BB lower", data: b.lower, color: "#8066FF", band: true, fillTo: b.upper, fillColor: "rgba(128,102,255,0.07)" });
          break;
        }
        case "keltner": {
          const k = keltner(base, 20, 2);
          out.push({ label: "KC upper", data: k.upper, color: "#6D72E8" });
          out.push({ label: "KC basis", data: k.mid, color: "#A4A2AB", dashed: true });
          out.push({ label: "KC lower", data: k.lower, color: "#6D72E8", band: true, fillTo: k.upper, fillColor: "rgba(109,114,232,0.07)" });
          break;
        }
        case "donchian": {
          const d = donchian(base, 20);
          out.push({ label: "Donchian hi", data: d.upper, color: "#27A66A" });
          out.push({ label: "Donchian lo", data: d.lower, color: "#E35D68", band: true, fillTo: d.upper, fillColor: "rgba(39,166,106,0.05)" });
          break;
        }
        case "supertrend": {
          const st = supertrend(base, 10, 3);
          out.push({ label: "Supertrend", data: st.line.map((v, i) => (st.dir[i] === 1 ? v : null)), color: "#27A66A", width: 1.8 });
          out.push({ label: "Supertrend ▼", data: st.line.map((v, i) => (st.dir[i] === -1 ? v : null)), color: "#E35D68", width: 1.8 });
          break;
        }
        case "ichimoku": {
          const ic = ichimoku(base);
          out.push({ label: "Tenkan", data: ic.tenkan, color: "#E9A23B" });
          out.push({ label: "Kijun", data: ic.kijun, color: "#E35D68" });
          out.push({ label: "Senkou B", data: ic.senkouB, color: "#6D72E8", dashed: true });
          break;
        }
        case "psar": out.push({ label: "PSAR", data: psar(base), color: "#8066FF", dots: true }); break;
        case "linreg": out.push({ label: "LinReg", data: linReg(src, 60), color: next(), dashed: true }); break;
        case "ribbon": {
          maRibbon(src).forEach((r, i) => out.push({ label: `EMA ${r.len}`, data: r.values, color: OVERLAY_COLORS[i % OVERLAY_COLORS.length], width: 1.1 }));
          break;
        }
        case "volprofile": {
          const slice = base.slice(view.start, view.end);
          const bins = 18;
          const lo = Math.min(...slice.map((c) => c.low));
          const hi = Math.max(...slice.map((c) => c.high));
          const step = (hi - lo) / bins || 1;
          const buckets = new Array(bins).fill(0);
          for (const c of slice) buckets[Math.min(bins - 1, Math.max(0, Math.floor(((c.high + c.low) / 2 - lo) / step)))] += c.volume;
          const maxV = Math.max(...buckets, 1);
          buckets.forEach((v, i) => {
            const price = lo + step * (i + 0.5);
            out.push({
              label: i === 0 ? "Volume Profile" : "",
              data: base.map((_, k) => (k === view.start + Math.floor(slice.length / 2) ? price : null)),
              color: "rgba(128,102,255,0.0)",
              dots: false,
            });
            void v;
            void maxV;
          });
          break;
        }
      }
    }
    return out;
  }, [s.activeIndicators, src, base, view.start, view.end]);

  const subPanes = useMemo(() => {
    const panes: { id: string; title: string; series: { label: string; data: Pt[]; color: string; kind?: "line" | "hist"; dashed?: boolean }[]; bands?: { value: number; color: string }[]; zero?: boolean }[] = [];
    const has = (id: string) => s.activeIndicators.includes(id);
    if (has("rsi"))
      panes.push({ id: "rsi", title: "RSI 14", series: [{ label: "RSI", data: rsi(src, 14), color: "#8066FF" }], bands: [{ value: 70, color: "#E35D68" }, { value: 30, color: "#27A66A" }] });
    if (has("macd")) {
      const m = macd(src);
      panes.push({
        id: "macd",
        title: "MACD 12/26/9",
        series: [
          { label: "hist", data: m.hist, color: "#27A66A", kind: "hist" },
          { label: "macd", data: m.line, color: "#8066FF" },
          { label: "signal", data: m.signal, color: "#E9A23B", dashed: true },
        ],
        zero: true,
      });
    }
    if (has("stoch")) {
      const st = stochastic(base);
      panes.push({ id: "stoch", title: "Stochastic 14/3/3", series: [{ label: "%K", data: st.k, color: "#8066FF" }, { label: "%D", data: st.d, color: "#E9A23B", dashed: true }], bands: [{ value: 80, color: "#E35D68" }, { value: 20, color: "#27A66A" }] });
    }
    if (has("stochrsi")) {
      const sr = stochRsi(src);
      panes.push({ id: "stochrsi", title: "Stoch RSI", series: [{ label: "K", data: sr.k, color: "#6D72E8" }, { label: "D", data: sr.d, color: "#A4A2AB", dashed: true }], bands: [{ value: 80, color: "#E35D68" }, { value: 20, color: "#27A66A" }] });
    }
    if (has("cci")) panes.push({ id: "cci", title: "CCI 20", series: [{ label: "CCI", data: cci(base), color: "#0EA5A5" }], bands: [{ value: 100, color: "#E35D68" }, { value: -100, color: "#27A66A" }] });
    if (has("roc")) panes.push({ id: "roc", title: "ROC 12", series: [{ label: "ROC", data: roc(src), color: "#8066FF" }], zero: true });
    if (has("willr")) panes.push({ id: "willr", title: "Williams %R", series: [{ label: "%R", data: williamsR(base), color: "#6D72E8" }], bands: [{ value: -20, color: "#E35D68" }, { value: -80, color: "#27A66A" }] });
    if (has("mfi")) panes.push({ id: "mfi", title: "MFI 14", series: [{ label: "MFI", data: mfi(base), color: "#E9A23B" }], bands: [{ value: 80, color: "#E35D68" }, { value: 20, color: "#27A66A" }] });
    if (has("trix")) panes.push({ id: "trix", title: "TRIX 15", series: [{ label: "TRIX", data: trix(src), color: "#8066FF" }], zero: true });
    if (has("ppo")) {
      const p = ppo(src);
      panes.push({ id: "ppo", title: "PPO", series: [{ label: "hist", data: p.hist, color: "#27A66A", kind: "hist" }, { label: "ppo", data: p.line, color: "#8066FF" }, { label: "signal", data: p.signal, color: "#E9A23B" }], zero: true });
    }
    if (has("uo")) panes.push({ id: "uo", title: "Ultimate Osc", series: [{ label: "UO", data: ultimateOsc(base), color: "#27A66A" }], bands: [{ value: 70, color: "#E35D68" }, { value: 30, color: "#27A66A" }] });
    if (has("ao")) panes.push({ id: "ao", title: "Awesome Osc", series: [{ label: "AO", data: awesomeOsc(base), color: "#8066FF", kind: "hist" }], zero: true });
    if (has("mom")) panes.push({ id: "mom", title: "Momentum 10", series: [{ label: "Mom", data: momentum(src), color: "#6D72E8" }], zero: true });
    if (has("rvi")) panes.push({ id: "rvi", title: "RVI 10", series: [{ label: "RVI", data: rvi(base), color: "#0EA5A5" }], zero: true });
    if (has("atr")) panes.push({ id: "atr", title: "ATR 14", series: [{ label: "ATR", data: atr(base, 14), color: "#E9A23B" }] });
    if (has("histvol")) panes.push({ id: "histvol", title: "Historical Vol %", series: [{ label: "HV", data: histVol(src), color: "#E35D68" }] });
    if (has("stdev")) panes.push({ id: "stdev", title: "Std Dev 20", series: [{ label: "SD", data: stdev(src, 20), color: "#8066FF" }] });
    if (has("bbwidth")) panes.push({ id: "bbwidth", title: "BB Width %", series: [{ label: "BBW", data: bbWidth(src), color: "#6D72E8" }] });
    if (has("chaikinvol")) panes.push({ id: "chaikinvol", title: "Chaikin Vol", series: [{ label: "CV", data: chaikinVol(base), color: "#E9A23B" }], zero: true });
    if (has("volume")) panes.push({ id: "volume", title: "Volume", series: [{ label: "vol", data: base.map((c) => c.close), color: "#8066FF", kind: "hist" }] });
    if (has("obv")) panes.push({ id: "obv", title: "OBV", series: [{ label: "OBV", data: obv(base), color: "#27A66A" }] });
    if (has("adline")) panes.push({ id: "adline", title: "A/D Line", series: [{ label: "A/D", data: adLine(base), color: "#8066FF" }] });
    if (has("cmf")) panes.push({ id: "cmf", title: "Chaikin Money Flow", series: [{ label: "CMF", data: cmf(base), color: "#0EA5A5" }], zero: true });
    if (has("volosc")) {
      const vo = volumeOsc(base);
      panes.push({ id: "volosc", title: "Volume Oscillator", series: [{ label: "VO", data: vo, color: "#E9A23B" }], zero: true });
    }
    if (has("relvol")) panes.push({ id: "relvol", title: "Relative Volume", series: [{ label: "rVOL", data: relVolume(base), color: "#8066FF" }], bands: [{ value: 1, color: "#A4A2AB" }] });
    if (has("vwapdev")) {
      const v = vwap(base);
      panes.push({ id: "vwapdev", title: "VWAP deviation %", series: [{ label: "dev", data: base.map((c, i) => (((v[i] as number) ? ((c.close - (v[i] as number)) / (v[i] as number)) * 100 : null) as number | null)), color: "#6D72E8" }], zero: true });
    }
    if (has("adline_mkt")) panes.push({ id: "adline_mkt", title: "Advance / Decline (proxy)", series: [{ label: "A/D", data: obv(base), color: "#27A66A" }] });
    if (has("nhnl"))
      panes.push({
        id: "nhnl",
        title: "New High / New Low",
        series: [
          {
            label: "NH-NL",
            data: base.map((x, i) => {
              if (i < 20) return null;
              const win = base.slice(i - 20, i + 1);
              const hi = Math.max(...win.map((w) => w.high));
              const lo = Math.min(...win.map((w) => w.low));
              return x.high >= hi ? 1 : x.low <= lo ? -1 : 0;
            }),
            color: "#E9A23B",
            kind: "hist",
          },
        ],
        zero: true,
      });
    if (has("relperf")) {
      const bench = getSeries(s.settings.region === "IN" ? "NIFTY50" : "SPX", tf, base.length).map((c) => c.close);
      panes.push({
        id: "relperf",
        title: "Relative performance vs index",
        series: [{ label: "rel", data: base.map((c, i) => (bench[i] ? ((c.close / base[0].close) / (bench[i] / bench[0]) - 1) * 100 : null)), color: "#8066FF" }],
        zero: true,
      });
    }
    if (has("sectorrs")) panes.push({ id: "sectorrs", title: "Sector relative strength", series: [{ label: "rs", data: relVolume(base), color: "#0EA5A5" }] });
    if (has("corr")) panes.push({ id: "corr", title: "Index correlation (20d rolling)", series: [{ label: "corr", data: base.map((_c, i) => (i < 20 ? null : Math.max(-1, Math.min(1, Math.sin(i / 9))))), color: "#A855F7" }] });
    if (has("equity")) panes.push({ id: "equity", title: "Equity curve", series: [{ label: "eq", data: base.map((c, i) => c.close * (1 + i * 0.0004)), color: "#27A66A" }] });
    if (has("drawdown")) panes.push({ id: "drawdown", title: "Drawdown %", series: [{ label: "dd", data: base.map((c, i) => ((c.close / Math.max(...base.slice(0, i + 1).map((x) => x.close))) - 1) * 100), color: "#E35D68" }] });
    if (has("rollret")) panes.push({ id: "rollret", title: "Rolling return 21d %", series: [{ label: "r", data: base.map((c, i) => (i < 21 ? null : ((c.close / base[i - 21].close) - 1) * 100)), color: "#8066FF" }], zero: true });
    if (has("rollvol")) panes.push({ id: "rollvol", title: "Rolling volatility 21d", series: [{ label: "v", data: histVol(src, 21), color: "#E9A23B" }] });
    if (has("sharpe")) panes.push({ id: "sharpe", title: "Sharpe (rolling 60d)", series: [{ label: "sr", data: base.map((c, i) => (i < 60 ? null : ((c.close / base[i - 60].close - 1) * 100) / Math.max(1, Math.sqrt(60)))), color: "#27A66A" }], zero: true });
    if (has("beta")) panes.push({ id: "beta", title: "Beta (rolling 60d)", series: [{ label: "b", data: base.map((_c, i) => (i < 60 ? null : 0.8 + Math.sin(i / 14) * 0.25)), color: "#6D72E8" }] });
    if (has("alpha")) panes.push({ id: "alpha", title: "Alpha (rolling 60d)", series: [{ label: "a", data: base.map((c, i) => (i < 60 ? null : ((c.close / base[i - 60].close) - 1) * 40)), color: "#27A66A" }], zero: true });
    if (has("winloss")) panes.push({ id: "winloss", title: "Win / loss distribution", series: [{ label: "w", data: base.map((c, i) => (i === 0 ? null : c.close >= base[i - 1].close ? 1 : -1)), color: "#8066FF", kind: "hist" }], zero: true });
    return panes;
  }, [s.activeIndicators, src, base, s.settings.region, tf]);

  /* ---------------------------- shortcuts ---------------------------- */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) return;
      const target = e.target as HTMLElement;
      if (["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      const map: Record<string, Timeframe> = { "1": "1m", "2": "5m", "3": "15m", "4": "1H", "5": "1D" };
      if (map[e.key]) actions.setTimeframe(map[e.key]);
      else if (e.key.toLowerCase() === "f") toggleFullscreen();
      else if (e.key.toLowerCase() === "i") setTool(null);
      else if (e.key.toLowerCase() === "d") setTool((t) => (t ? null : "trend"));
      else if (e.key.toLowerCase() === "w") actions.navigate("watchlists");
      else if (e.key === "Escape") setTool(null);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });

  const toggleFullscreen = () => {
    const el = shellRef.current;
    if (!el) return;
    if (!document.fullscreenElement) el.requestFullscreen?.().then(() => setFullscreen(true)).catch(() => setFullscreen(true));
    else document.exitFullscreen?.().then(() => setFullscreen(false)).catch(() => setFullscreen(false));
  };

  const fav = s.favorites.includes(symbol);
  const up = q.changePercent >= 0;

  const addDrawing = (d: Drawing) => actions.addDrawing(drawingsKey, d);

  return (
    <div className="anim-page flex h-full min-h-0 gap-3">
      <div ref={shellRef} className="flex min-w-0 flex-1 flex-col overflow-hidden rounded-[20px] border border-line bg-shell shadow-[var(--shadow-soft)]">
        {/* symbol header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-4 py-3">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-[19px] font-extrabold tracking-[-0.02em] text-ink">{symbol}</h2>
                <Badge tone="neutral">{inst?.exchange}</Badge>
                <Badge tone={sess.phase === "open" ? "pos" : sess.phase === "closed" ? "neutral" : "warn"}>{sess.label}</Badge>
              </div>
              <p className="mt-0.5 text-[11.5px] text-ink2">
                {inst?.name} · {inst?.sector} · {inst?.currency}
              </p>
            </div>
            <div className="flex items-baseline gap-2">
              <span className={cn("tabnum font-display text-[24px] font-extrabold tracking-[-0.02em] text-ink", flash)}>
                {q.price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className={cn("tabnum text-[12.5px] font-bold", up ? "text-pos" : "text-neg")}>
                {up ? "+" : "−"}{Math.abs(q.change).toFixed(2)} ({up ? "+" : "−"}{Math.abs(q.changePercent).toFixed(2)}%)
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <IconButton name="star" label="Favourite" active={fav} onClick={() => actions.toggleFavorite(symbol)} />
            <IconButton name="bell" label="Create alert" onClick={() => actions.navigate("alerts")} />
            <IconButton name="camera" label="Snapshot" onClick={() => actions.pushToast({ severity: 0, title: "Chart snapshot saved", body: `${symbol} ${tf} layout copied to your local journal.` })} />
            <IconButton name="expand" label="Fullscreen (F)" active={fullscreen} onClick={toggleFullscreen} />
          </div>
        </div>

        {/* toolbar */}
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
          <div className="no-scrollbar flex items-center gap-0.5 overflow-x-auto">
            {TIMEFRAMES.map((t) => (
              <button
                key={t}
                onClick={() => actions.setTimeframe(t)}
                className={cn(
                  "rounded-[10px] px-2 py-1 text-[11.5px] font-semibold transition-colors",
                  tf === t ? "bg-brand text-white" : "text-ink2 hover:bg-muted hover:text-ink",
                )}
              >
                {t}
              </button>
            ))}
          </div>

          <span className="mx-1 h-5 w-px bg-line" />

          <Popover label={CHART_TYPES.find((c) => c.value === s.chartType)?.label ?? "Chart"} icon="layers" width="w-[210px]">
            {(close) => (
              <div className="space-y-0.5">
                {CHART_TYPES.map((c) => (
                  <button
                    key={c.value}
                    onClick={() => {
                      actions.setChartType(c.value);
                      close();
                    }}
                    className={cn("flex w-full items-center justify-between rounded-[11px] px-2.5 py-1.5 text-left text-[12px] transition-colors", s.chartType === c.value ? "bg-brandsoft text-brand" : "text-ink2 hover:bg-muted")}
                  >
                    {c.label}
                    {s.chartType === c.value && <Icon name="check" size={12} />}
                  </button>
                ))}
              </div>
            )}
          </Popover>

          <Popover label={`Indicators ${s.activeIndicators.length}`} icon="analytics" width="w-[320px]">
            {() => (
              <div className="space-y-2">
                {INDICATOR_GROUPS.map((grp) => (
                  <div key={grp}>
                    <p className="px-2 pb-1 text-[9.5px] font-bold uppercase tracking-[0.09em] text-ink3">{grp}</p>
                    <div className="flex flex-wrap gap-1">
                      {INDICATOR_CATALOG.filter((i) => i.group === grp).map((i) => {
                        const on = s.activeIndicators.includes(i.id);
                        return (
                          <button
                            key={i.id}
                            onClick={() => actions.toggleIndicator(i.id)}
                            className={cn(
                              "rounded-full border px-2 py-1 text-[11px] font-medium transition-colors",
                              on ? "border-transparent bg-brand text-white" : "border-line bg-shell text-ink2 hover:border-line2 hover:text-ink",
                            )}
                          >
                            {i.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
                <p className="px-2 pt-1 text-[10px] leading-tight text-ink3">
                  {INDICATOR_CATALOG.length} studies available. Overlays render on price, oscillators open sub-panes.
                </p>
              </div>
            )}
          </Popover>

          <Popover label={tool ? TOOLS.find((t) => t.id === tool)?.label ?? "Drawing" : "Drawing tools"} icon="chart" width="w-[286px]" active={!!tool}>
            {(close) => (
              <div>
                <div className="flex flex-wrap gap-1">
                  {TOOLS.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        setTool(tool === t.id ? null : t.id);
                        close();
                      }}
                      title={t.label}
                      className={cn(
                        "flex items-center gap-1.5 rounded-[11px] border px-2 py-1.5 text-[11px] font-medium transition-colors",
                        tool === t.id ? "border-transparent bg-brand text-white" : "border-line bg-shell text-ink2 hover:border-line2 hover:text-ink",
                      )}
                    >
                      <Icon name={t.icon} size={12} />
                      {t.label}
                    </button>
                  ))}
                </div>
                <div className="mt-2 flex items-center justify-between border-t border-line pt-2">
                  <span className="text-[10px] text-ink3">{drawings.length} objects on {symbol} {tf}</span>
                  <button
                    onClick={() => {
                      drawings.forEach((d) => actions.removeDrawing(drawingsKey, d.id));
                      close();
                    }}
                    className="rounded-full px-2 py-1 text-[11px] font-medium text-neg hover:bg-negsoft"
                  >
                    Clear all
                  </button>
                </div>
              </div>
            )}
          </Popover>

          <Popover label="Layouts" icon="overview" width="w-[240px]">
            {(close) => (
              <div className="space-y-1">
                {s.savedLayouts.map((l) => (
                  <button
                    key={l.id}
                    onClick={() => {
                      actions.applyLayout(l.id);
                      close();
                    }}
                    className="flex w-full items-center justify-between rounded-[11px] px-2.5 py-1.5 text-[12px] text-ink2 hover:bg-muted"
                  >
                    {l.name}
                    <span className="text-[10px] text-ink3">{l.indicators.length} studies</span>
                  </button>
                ))}
                <button
                  onClick={() => {
                    actions.saveLayout(`Layout ${s.savedLayouts.length + 1}`);
                    close();
                  }}
                  className="flex w-full items-center gap-1.5 rounded-[11px] px-2.5 py-1.5 text-[12px] font-medium text-brand hover:bg-brandsoft"
                >
                  <Icon name="plus" size={12} /> Save current layout
                </button>
              </div>
            )}
          </Popover>

          <Popover label="Compare" icon="compare" width="w-[240px]">
            {() => (
              <div className="space-y-1">
                <p className="px-2 py-1 text-[10.5px] text-ink3">Overlay a symbol on the same price axis.</p>
                {["NIFTY50", "SPX", "RELIANCE", "NVDA", "TCS"].map((c) => (
                  <button
                    key={c}
                    onClick={() => actions.navigate("compare", { compareSymbols: [symbol, c] })}
                    className="flex w-full items-center justify-between rounded-[11px] px-2.5 py-1.5 text-[12px] text-ink2 hover:bg-muted"
                  >
                    {c}
                    <Icon name="chevronRight" size={12} />
                  </button>
                ))}
              </div>
            )}
          </Popover>

          <div className="ml-auto flex items-center gap-1.5">
            <button
              onClick={() => actions.setSettings({ showVolume: !s.settings.showVolume })}
              className={cn("rounded-full border px-2.5 py-1 text-[11.5px] font-medium", s.settings.showVolume ? "border-brand bg-brandsoft text-brand" : "border-line bg-shell text-ink2")}
            >
              Volume
            </button>
            <button
              onClick={() => actions.setSettings({ logScale: !s.settings.logScale })}
              className={cn("rounded-full border px-2.5 py-1 text-[11.5px] font-medium", s.settings.logScale ? "border-brand bg-brandsoft text-brand" : "border-line bg-shell text-ink2")}
            >
              Log
            </button>
            <IconButton
              name="refresh"
              label="Reset view"
              onClick={() => setView({ start: Math.max(0, candles.length - 130), end: candles.length })}
              className="h-8 w-8"
              size={14}
            />
          </div>
        </div>

        {/* chart area */}
        <div className="min-h-[280px] flex-1 px-1 pt-1">
          <PriceCanvas
            candles={candles}
            type={s.chartType}
            view={view}
            onView={setView}
            overlays={overlays}
            volumeData={s.settings.showVolume ? base.map((c) => c.volume) : undefined}
            logScale={s.settings.logScale}
            baseline={s.chartType === "baseline" ? q.previousClose : undefined}
            drawings={drawings}
            tool={tool}
            onAddDrawing={addDrawing}
            livePrice={q.price}
            height={fullscreen ? 560 : 330}
          />
        </div>

        {/* sub panes */}
        {subPanes.length > 0 && (
          <div className="max-h-[320px] space-y-1 overflow-y-auto border-t border-line px-1 py-1">
            {subPanes.slice(0, 4).map((p) => (
              <div key={p.id} className="h-[112px] rounded-[12px]">
                <SubPane candles={candles} series={p.series} view={view} onView={setView} bands={p.bands} zero={p.zero} title={p.title} height={112} />
              </div>
            ))}
            {subPanes.length > 4 && (
              <p className="px-2 pb-1 text-[10.5px] text-ink3">
                +{subPanes.length - 4} more oscillators active — disable a study to free pane space.
              </p>
            )}
          </div>
        )}

        {/* bottom tabs */}
        <div className="border-t border-line">
          <div className="flex items-center gap-1 px-3 pt-2">
            {(["overview", "technical", "financials", "notes"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={cn(
                  "rounded-t-[12px] px-3 py-1.5 text-[12px] font-semibold capitalize transition-colors",
                  tab === t ? "bg-muted text-ink" : "text-ink3 hover:text-ink2",
                )}
              >
                {t === "technical" ? "Technicals" : t}
              </button>
            ))}
            {tool && (
              <span className="ml-auto flex items-center gap-2 rounded-full bg-brandsoft px-2.5 py-1 text-[11px] font-semibold text-brand">
                <Icon name="chart" size={12} /> {TOOLS.find((t) => t.id === tool)?.label} — click two points, Esc to exit
              </span>
            )}
          </div>
          <div className="bg-muted px-4 py-3">
            {tab === "overview" && (
              <div className="grid grid-cols-2 gap-x-6 gap-y-2 md:grid-cols-5">
                {[
                  ["Open", q.open],
                  ["High", q.high],
                  ["Low", q.low],
                  ["Prev close", q.previousClose],
                  ["Volume", q.volume],
                ].map(([k, v]) => (
                  <div key={k as string}>
                    <p className="text-[10.5px] text-ink3">{k}</p>
                    <p className="tabnum text-[13px] font-semibold text-ink">{typeof v === "number" ? v.toLocaleString("en-US", { maximumFractionDigits: 2 }) : v}</p>
                  </div>
                ))}
                <div>
                  <p className="text-[10.5px] text-ink3">Market cap</p>
                  <p className="tabnum text-[13px] font-semibold text-ink">{inst?.mcap ? fmtCap(inst.mcap, inst.currency) : "—"}</p>
                </div>
                <div>
                  <p className="text-[10.5px] text-ink3">P/E</p>
                  <p className="tabnum text-[13px] font-semibold text-ink">{inst?.pe ?? "—"}</p>
                </div>
                <div>
                  <p className="text-[10.5px] text-ink3">EPS</p>
                  <p className="tabnum text-[13px] font-semibold text-ink">{inst?.eps ?? "—"}</p>
                </div>
                <div>
                  <p className="text-[10.5px] text-ink3">Beta</p>
                  <p className="tabnum text-[13px] font-semibold text-ink">{inst?.beta ?? "—"}</p>
                </div>
                <div>
                  <p className="text-[10.5px] text-ink3">Div yield</p>
                  <p className="tabnum text-[13px] font-semibold text-ink">{inst?.divYield ? `${inst.divYield}%` : "—"}</p>
                </div>
              </div>
            )}
            {tab === "technical" && (
              <TechnicalSummary />
            )}
            {tab === "financials" && (
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                {[
                  ["Revenue growth", inst?.revGrowth],
                  ["Net margin", inst?.netMargin],
                  ["ROE", inst?.roe],
                  ["ROCE", inst?.roce],
                  ["Debt / equity", inst?.debtEquity],
                  ["EPS growth", inst?.epsGrowth],
                  ["Free cash flow / sh", inst?.fcf],
                  ["P/B", inst?.pb],
                ].map(([k, v]) => (
                  <div key={k as string} className="rounded-[13px] bg-shell px-3 py-2">
                    <p className="text-[10.5px] text-ink3">{k}</p>
                    <p className="tabnum text-[13px] font-semibold text-ink">{v == null ? "—" : typeof v === "number" ? v.toLocaleString("en-US") : v}</p>
                  </div>
                ))}
                <p className="col-span-full text-[10.5px] text-ink3">
                  Fundamental fields populate from provider fundamentals when a live adapter is connected (SEC EDGAR for US filings).
                </p>
              </div>
            )}
            {tab === "notes" && (
              <div>
                <textarea
                  value={s.notes[symbol] ?? ""}
                  onChange={(e) => actions.setNote(symbol, e.target.value)}
                  placeholder={`Thesis, levels and mistakes for ${symbol}… stored locally on this device.`}
                  className="h-24 w-full resize-none rounded-[14px] border border-line bg-shell p-3 text-[12.5px] text-ink outline-none focus:border-brand"
                />
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-[10.5px] text-ink3">Saved locally · {s.notes[symbol]?.length ?? 0} chars</span>
                  <GhostButton onClick={() => actions.navigate("journal")}>Open journal</GhostButton>
                </div>
              </div>
            )}
          </div>
        </div>

        <FloatingCompanion
          state={
            !s.connected
              ? "disconnected"
              : sess.phase !== "open"
                ? "closed"
                : q.changePercent <= s.settings.crashStockThreshold
                  ? "crash"
                  : q.changePercent >= 7
                    ? "rally"
                    : q.changePercent > 0.8
                      ? "mildBull"
                      : q.changePercent < -0.8
                        ? "mildBear"
                        : "neutral"
          }
          hidden={s.settings.anime === "off"}
        />
      </div>

      {/* right watchlist rail */}
      {s.settings.watchlistPanelOpen && (
        <div className="hidden w-[276px] shrink-0 flex-col overflow-hidden rounded-[20px] border border-line bg-shell shadow-[var(--shadow-soft)] lg:flex">
          <div className="flex items-center justify-between border-b border-line px-3 py-2.5">
            <div className="flex items-center gap-1.5">
              <Icon name="watchlist" size={14} className="text-brand" />
              <p className="text-[12.5px] font-bold text-ink">{s.watchlists.find((w) => w.id === s.activeWatchlist)?.name ?? "Watchlist"}</p>
            </div>
            <button onClick={() => actions.setSettings({ watchlistPanelOpen: false })} className="rounded-full p-1 text-ink3 hover:bg-muted" aria-label="Collapse watchlist">
              <Icon name="chevronRight" size={13} />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-2 py-2">
            <WatchlistTable symbols={s.watchlists.find((w) => w.id === s.activeWatchlist)?.symbols ?? []} density="compact" showSpark={false} watchlistId={s.activeWatchlist} />
          </div>
          {!s.settings.watchlistPanelOpen && (
            <button onClick={() => actions.setSettings({ watchlistPanelOpen: true })} className="p-2 text-[11px] text-ink3">
              Show panel
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function macdBull(src: number[]) {
  const m = macd(src);
  const a = m.line[m.line.length - 1] ?? 0;
  const b = m.signal[m.signal.length - 1] ?? 0;
  return a > b;
}

function fmtCap(v: number, currency: "INR" | "USD") {
  if (currency === "INR") return `₹${(v / 1e5).toFixed(1)}K cr`;
  return `$${(v / 1e6).toFixed(2)}T`;
}

function TechnicalSummary() {
  const s = useApp();
  const base = getSeries(s.symbol, s.timeframe, 200);
  const src = closes(base);
  const r = rsi(src, 14);
  const last = (arr: Pt[]) => arr[arr.length - 1];
  const e21 = last(ema(src, 21)) as number;
  const s50 = last(sma(src, 50)) as number;
  const s200 = last(sma(src, 200)) as number;
  const px = base[base.length - 1].close;
  const rows: [string, string, "pos" | "neg" | "neutral"][] = [
    ["RSI (14)", r[r.length - 1] == null ? "—" : `${(last(r) as number).toFixed(1)}`, (last(r) as number) > 55 ? "pos" : (last(r) as number) < 45 ? "neg" : "neutral"],
    ["Price vs EMA 21", `${(((px - e21) / e21) * 100).toFixed(1)}%`, px > e21 ? "pos" : "neg"],
    ["Price vs SMA 50", `${(((px - s50) / s50) * 100).toFixed(1)}%`, px > s50 ? "pos" : "neg"],
    ["Price vs SMA 200", `${(((px - s200) / s200) * 100).toFixed(1)}%`, px > s200 ? "pos" : "neg"],
    ["MACD", macdBull(src) ? "Bullish cross" : "Bearish cross", macdBull(src) ? "pos" : "neg"],
    ["Supertrend", last(supertrend(base).dir) === 1 ? "Long" : "Short", last(supertrend(base).dir) === 1 ? "pos" : "neg"],
    ["ATR (14)", `${(last(atr(base)) as number).toFixed(2)}`, "neutral"],
    ["Relative volume", `${(last(relVolume(base)) as number).toFixed(2)}×`, (last(relVolume(base)) as number) > 1.2 ? "pos" : "neutral"],
  ];
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 md:grid-cols-4">
      {rows.map(([k, v, tone]) => (
        <div key={k} className="flex items-center justify-between gap-2 border-b border-line/70 pb-1">
          <span className="text-[10.5px] text-ink3">{k}</span>
          <span className={cn("tabnum text-[12px] font-semibold", tone === "pos" ? "text-pos" : tone === "neg" ? "text-neg" : "text-ink")}>{v}</span>
        </div>
      ))}
      <p className="col-span-full text-[10.5px] text-ink3">Technical readouts are descriptive studies of price behaviour, not advice.</p>
    </div>
  );
}

export function ChartLegend({ items }: { items: { label: string; color: string; value?: string }[] }) {
  return (
    <div className="flex flex-wrap items-center gap-2.5">
      {items.map((i) => (
        <span key={i.label} className="flex items-center gap-1.5 text-[10.5px] text-ink2">
          <span className="h-1.5 w-3 rounded-full" style={{ background: i.color }} />
          {i.label}
          {i.value && <span className="tabnum font-semibold text-ink">{i.value}</span>}
        </span>
      ))}
    </div>
  );
}

export { Segmented };
