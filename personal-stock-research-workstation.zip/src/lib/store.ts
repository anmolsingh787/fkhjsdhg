import { useCallback, useMemo, useSyncExternalStore } from "react";
import { subscribeTicks } from "./marketData";
import type {
  AlertDef,
  AnimeState,
  ChartType,
  JournalEntry,
  NotificationItem,
  Region,
  Settings,
  Timeframe,
  Toast,
  Transaction,
  Watchlist,
} from "./types";

/* ------------------------------------------------------------------ *
 * Store primitives
 * ------------------------------------------------------------------ */
export interface Drawing {
  id: string;
  tool: string;
  points: { t: number; p: number }[];
  color: string;
  text?: string;
  locked: boolean;
  hidden: boolean;
}

export interface AppState {
  screen: string;
  symbol: string;
  timeframe: Timeframe;
  chartType: ChartType;
  compareSymbols: string[];
  activeWatchlist: string;
  settings: Settings;
  watchlists: Watchlist[];
  favorites: string[];
  alerts: AlertDef[];
  notifications: NotificationItem[];
  toasts: Toast[];
  transactions: Transaction[];
  journal: JournalEntry[];
  notes: Record<string, string>;
  drawings: Record<string, Drawing[]>;
  recent: string[];
  savedLayouts: { id: string; name: string; indicators: string[]; chartType: ChartType }[];
  savedScreens: { id: string; name: string; filters: Record<string, unknown> }[];
  activeIndicators: string[];
  connected: boolean;
}

const DEFAULT_SETTINGS: Settings = {
  region: "IN",
  density: "comfortable",
  motion: "full",
  anime: "full",
  dataMode: "mock",
  crashIndexThreshold: -3,
  crashStockThreshold: -7,
  sound: false,
  browserNotify: false,
  showVolume: true,
  logScale: false,
  autoScale: true,
  crosshairMagnet: false,
  sidebarCollapsed: false,
  watchlistPanelOpen: true,
  defaultIndicators: ["ema21", "sma50", "volume", "rsi"],
  defaultChartType: "candles",
};

const DEFAULT_WATCHLISTS: Watchlist[] = [
  { id: "wl-in-core", name: "India Core", region: "IN", color: "#8066FF", symbols: ["RELIANCE", "HDFCBANK", "TCS", "ICICIBANK", "INFY", "ITC", "SBIN", "BHARTIARTL"] },
  { id: "wl-us-core", name: "US Core", region: "US", color: "#6D72E8", symbols: ["AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "META", "TSLA", "JPM"] },
  { id: "wl-tech", name: "Tech", region: "IN", color: "#27A66A", symbols: ["TCS", "INFY", "WIPRO", "AAPL", "MSFT", "NVDA", "AMD", "PLTR"] },
  { id: "wl-banks", name: "Banks", region: "IN", color: "#E9A23B", symbols: ["HDFCBANK", "ICICIBANK", "SBIN", "JPM", "BAJFINANCE"] },
  { id: "wl-momentum", name: "Momentum", region: "US", color: "#E35D68", symbols: ["NVDA", "PLTR", "AMD", "TSLA", "META", "ZOMATO", "TATAMOTORS"] },
  { id: "wl-long", name: "Long-Term", region: "IN", color: "#18171C", symbols: ["RELIANCE", "TITAN", "DMART", "HINDUNILVR", "COST", "LLY"] },
];

const DEFAULT_TX: Transaction[] = [
  { id: "t1", symbol: "RELIANCE", side: "buy", qty: 120, price: 1284.2, fees: 42, date: "2025-02-11", note: "Core position", tags: ["core"] },
  { id: "t2", symbol: "RELIANCE", side: "buy", qty: 60, price: 1372.8, fees: 28, date: "2025-06-04", tags: ["add-on"] },
  { id: "t3", symbol: "HDFCBANK", side: "buy", qty: 80, price: 1544.6, fees: 31, date: "2025-03-19", tags: ["core", "banks"] },
  { id: "t4", symbol: "TCS", side: "buy", qty: 40, price: 3412.0, fees: 24, date: "2025-01-22", tags: ["it"] },
  { id: "t5", symbol: "INFY", side: "buy", qty: 90, price: 1428.4, fees: 22, date: "2025-05-08", tags: ["it"] },
  { id: "t6", symbol: "NVDA", side: "buy", qty: 30, price: 96.4, fees: 12, date: "2025-04-30", tags: ["us", "ai"] },
  { id: "t7", symbol: "MSFT", side: "buy", qty: 12, price: 398.2, fees: 8, date: "2025-07-15", tags: ["us"] },
  { id: "t8", symbol: "AAPL", side: "buy", qty: 18, price: 214.6, fees: 9, date: "2025-08-02", tags: ["us"] },
  { id: "t9", symbol: "ITC", side: "sell", qty: 40, price: 462.4, fees: 11, date: "2025-09-12", tags: ["book-profit"] },
];

function seedAlerts(): AlertDef[] {
  const now = Date.now();
  return [
    { id: "a1", symbol: "RELIANCE", condition: "price_above", value: 1480, frequency: "once", channels: { inApp: true, browser: true, sound: false }, message: "RELIANCE crossed above ₹1,480", createdAt: now - 864e5, active: true },
    { id: "a2", symbol: "NVDA", condition: "rsi_below", value: 35, frequency: "once_per_bar", channels: { inApp: true, browser: false, sound: false }, message: "NVDA RSI(14) below 35", createdAt: now - 2 * 864e5, active: true },
    { id: "a3", symbol: "NIFTY50", condition: "pct_move", value: 1.5, frequency: "every_cross", channels: { inApp: true, browser: false, sound: false }, message: "NIFTY 50 moved 1.5% intraday", createdAt: now - 3 * 864e5, active: true },
    { id: "a4", symbol: "HDFCBANK", condition: "volume_above", value: 1.8, frequency: "once", channels: { inApp: true, browser: true, sound: false }, message: "HDFCBANK relative volume above 1.8x", createdAt: now - 5 * 864e5, active: true },
  ];
}

function initialState(): AppState {
  return {
    screen: "overview",
    symbol: "RELIANCE",
    timeframe: "1D",
    chartType: "candles",
    compareSymbols: ["NIFTY50"],
    activeWatchlist: "wl-in-core",
    settings: DEFAULT_SETTINGS,
    watchlists: DEFAULT_WATCHLISTS,
    favorites: ["RELIANCE", "NVDA", "HDFCBANK"],
    alerts: seedAlerts(),
    notifications: [
      { id: "n1", severity: 1, category: "Technical", title: "RSI entered overbought", body: "TCS RSI(14) at 71.4 on 1D", symbol: "TCS", ts: Date.now() - 26 * 6e4, read: false },
      { id: "n2", severity: 0, category: "Earnings", title: "Results scheduled today", body: "HDFC Bank Q3 results after market close", symbol: "HDFCBANK", ts: Date.now() - 96 * 6e4, read: false },
      { id: "n3", severity: 2, category: "Market", title: "High volatility in metals", body: "Tata Steel moved 2.4× ATR in 30 minutes", symbol: "TATASTEEL", ts: Date.now() - 168 * 6e4, read: true },
      { id: "n4", severity: 0, category: "System", title: "Mock data mode active", body: "Connect a provider in Data Sources for live quotes", ts: Date.now() - 300 * 6e4, read: true },
    ],
    toasts: [],
    transactions: DEFAULT_TX,
    journal: [
      { id: "j1", symbol: "RELIANCE", ts: Date.now() - 6 * 864e5, thesis: "Retail + Jio re-rating with OMC margin recovery. Position sized for a 2-quarter hold.", notes: "Watch capex guidance. Add on dips toward 20-week EMA.", tags: ["core", "energy"], mood: "confident" },
      { id: "j2", symbol: "NVDA", ts: Date.now() - 12 * 864e5, thesis: "Data-center capex cycle still expanding; valuation rich but momentum intact.", notes: "Do not average up above 3% band. Respect ATR stop.", tags: ["us", "ai"], mood: "calm" },
    ],
    notes: {
      RELIANCE: "Position size 180 shares avg ~1313. Thesis intact while above the 200-DAY. Next catalyst: quarterly capex commentary.",
    },
    drawings: {},
    recent: ["RELIANCE", "NVDA", "NIFTY50", "TCS", "HDFCBANK"],
    savedLayouts: [
      { id: "l1", name: "Swing default", indicators: ["ema21", "sma50", "volume", "rsi"], chartType: "candles" },
      { id: "l2", name: "Trend study", indicators: ["supertrend", "ichimoku", "macd", "volume"], chartType: "heikin" },
      { id: "l3", name: "Clean price action", indicators: ["volume"], chartType: "hollow" },
    ],
    savedScreens: [
      { id: "s1", name: "Momentum Breakout", filters: { rsiAbove: 60, relVol: 1.4, aboveSMA50: true } },
      { id: "s2", name: "Oversold Quality", filters: { rsiBelow: 35, peBelow: 30 } },
      { id: "s3", name: "Low Volatility Compounders", filters: { betaBelow: 1, atrPctBelow: 2 } },
    ],
    activeIndicators: DEFAULT_SETTINGS.defaultIndicators,
    connected: true,
  };
}

let state: AppState = load();
const subs = new Set<() => void>();

function load(): AppState {
  const base = initialState();
  try {
    const raw = localStorage.getItem("aerrik.v1");
    if (!raw) return base;
    const saved = JSON.parse(raw) as Partial<AppState>;
    return {
      ...base,
      ...saved,
      settings: { ...base.settings, ...(saved.settings ?? {}) },
      toasts: [],
    };
  } catch {
    return base;
  }
}

let saveTimer: number | null = null;
function persist() {
  if (saveTimer) window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    try {
      const { toasts: _t, ...rest } = state;
      localStorage.setItem("aerrik.v1", JSON.stringify(rest));
    } catch {
      /* storage unavailable */
    }
  }, 400);
}

export function setState(patch: Partial<AppState> | ((s: AppState) => Partial<AppState>)) {
  const next = typeof patch === "function" ? patch(state) : patch;
  state = { ...state, ...next };
  persist();
  subs.forEach((s) => s());
}

export function getState() {
  return state;
}

function subscribe(cb: () => void) {
  subs.add(cb);
  return () => subs.delete(cb);
}

export function useStore<T>(selector: (s: AppState) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => selector(state),
    () => selector(state),
  );
}

export const useApp = () => useStore((s) => s);

/* ------------------------------------------------------------------ *
 * Live tick hook
 * ------------------------------------------------------------------ */
let tickVersion = 0;

export function useTick(): number {
  const sub = useCallback(
    (cb: () => void) =>
      subscribeTicks(() => {
        tickVersion += 1;
        cb();
      }),
    [],
  );
  return useSyncExternalStore(sub, () => tickVersion, () => 0);
}

/* ------------------------------------------------------------------ *
 * Actions
 * ------------------------------------------------------------------ */
export const actions = {
  navigate(screen: string, extra: Partial<AppState> = {}) {
    setState({ screen, ...extra });
  },
  openSymbol(symbol: string, screen?: string) {
    setState((s) => ({
      symbol,
      recent: [symbol, ...s.recent.filter((x) => x !== symbol)].slice(0, 8),
      ...(screen ? { screen } : {}),
    }));
  },
  setTimeframe(tf: Timeframe) {
    setState({ timeframe: tf });
  },
  setChartType(t: ChartType) {
    setState({ chartType: t });
  },
  setSettings(patch: Partial<Settings>) {
    setState((s) => ({ settings: { ...s.settings, ...patch } }));
  },
  toggleIndicator(id: string) {
    setState((s) => ({
      activeIndicators: s.activeIndicators.includes(id)
        ? s.activeIndicators.filter((x) => x !== id)
        : [...s.activeIndicators, id],
    }));
  },
  toggleFavorite(symbol: string) {
    setState((s) => ({
      favorites: s.favorites.includes(symbol) ? s.favorites.filter((x) => x !== symbol) : [...s.favorites, symbol],
    }));
  },
  setActiveWatchlist(id: string) {
    setState({ activeWatchlist: id });
  },
  addWatchlist(name: string, region: Region) {
    const id = `wl-${Date.now()}`;
    setState((s) => ({
      watchlists: [...s.watchlists, { id, name, region, color: "#8066FF", symbols: [] }],
      activeWatchlist: id,
    }));
    return id;
  },
  deleteWatchlist(id: string) {
    setState((s) => ({ watchlists: s.watchlists.filter((w) => w.id !== id) }));
  },
  renameWatchlist(id: string, name: string) {
    setState((s) => ({ watchlists: s.watchlists.map((w) => (w.id === id ? { ...w, name } : w)) }));
  },
  addToWatchlist(watchlistId: string, symbol: string) {
    setState((s) => ({
      watchlists: s.watchlists.map((w) =>
        w.id === watchlistId && !w.symbols.includes(symbol) ? { ...w, symbols: [...w.symbols, symbol] } : w,
      ),
    }));
  },
  removeFromWatchlist(watchlistId: string, symbol: string) {
    setState((s) => ({
      watchlists: s.watchlists.map((w) =>
        w.id === watchlistId ? { ...w, symbols: w.symbols.filter((x) => x !== symbol) } : w,
      ),
    }));
  },
  moveSymbol(watchlistId: string, from: number, to: number) {
    setState((s) => ({
      watchlists: s.watchlists.map((w) => {
        if (w.id !== watchlistId) return w;
        const arr = [...w.symbols];
        const [it] = arr.splice(from, 1);
        arr.splice(to, 0, it);
        return { ...w, symbols: arr };
      }),
    }));
  },
  pushToast(toast: Omit<Toast, "id">) {
    const id = `t-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setState((s) => ({ toasts: [...s.toasts.slice(-3), { ...toast, id }] }));
    window.setTimeout(() => setState((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), 6000);
  },
  dismissToast(id: string) {
    setState((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));
  },
  pushNotification(n: Omit<NotificationItem, "id" | "ts" | "read">) {
    setState((s) => ({
      notifications: [{ ...n, id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`, ts: Date.now(), read: false }, ...s.notifications].slice(0, 60),
    }));
  },
  markAllRead() {
    setState((s) => ({ notifications: s.notifications.map((n) => ({ ...n, read: true })) }));
  },
  clearNotifications() {
    setState({ notifications: [] });
  },
  addAlert(a: Omit<AlertDef, "id" | "createdAt" | "active">) {
    setState((s) => ({
      alerts: [{ ...a, id: `a-${Date.now()}`, createdAt: Date.now(), active: true }, ...s.alerts],
    }));
  },
  removeAlert(id: string) {
    setState((s) => ({ alerts: s.alerts.filter((a) => a.id !== id) }));
  },
  toggleAlert(id: string) {
    setState((s) => ({ alerts: s.alerts.map((a) => (a.id === id ? { ...a, active: !a.active } : a)) }));
  },
  addTransaction(t: Omit<Transaction, "id">) {
    setState((s) => ({ transactions: [{ ...t, id: `tx-${Date.now()}` }, ...s.transactions] }));
  },
  removeTransaction(id: string) {
    setState((s) => ({ transactions: s.transactions.filter((t) => t.id !== id) }));
  },
  setNote(symbol: string, text: string) {
    setState((s) => ({ notes: { ...s.notes, [symbol]: text } }));
  },
  addJournal(e: Omit<JournalEntry, "id" | "ts">) {
    setState((s) => ({ journal: [{ ...e, id: `j-${Date.now()}`, ts: Date.now() }, ...s.journal] }));
  },
  removeJournal(id: string) {
    setState((s) => ({ journal: s.journal.filter((j) => j.id !== id) }));
  },
  setDrawings(key: string, items: Drawing[]) {
    setState((s) => ({ drawings: { ...s.drawings, [key]: items } }));
  },
  addDrawing(key: string, d: Drawing) {
    setState((s) => ({ drawings: { ...s.drawings, [key]: [...(s.drawings[key] ?? []), d] } }));
  },
  updateDrawing(key: string, id: string, patch: Partial<Drawing>) {
    setState((s) => ({
      drawings: { ...s.drawings, [key]: (s.drawings[key] ?? []).map((d) => (d.id === id ? { ...d, ...patch } : d)) },
    }));
  },
  removeDrawing(key: string, id: string) {
    setState((s) => ({ drawings: { ...s.drawings, [key]: (s.drawings[key] ?? []).filter((d) => d.id !== id) } }));
  },
  saveLayout(name: string) {
    setState((s) => ({
      savedLayouts: [
        ...s.savedLayouts,
        { id: `l-${Date.now()}`, name, indicators: s.activeIndicators, chartType: s.chartType },
      ],
    }));
  },
  applyLayout(id: string) {
    setState((s) => {
      const l = s.savedLayouts.find((x) => x.id === id);
      return l ? { activeIndicators: l.indicators, chartType: l.chartType } : {};
    });
  },
  setConnected(v: boolean) {
    setState({ connected: v });
  },
};

/* ------------------------------------------------------------------ *
 * Derived helpers
 * ------------------------------------------------------------------ */
export function useWatchlist(): Watchlist {
  const s = useApp();
  return s.watchlists.find((w) => w.id === s.activeWatchlist) ?? s.watchlists[0];
}

export function useSymbols(): string[] {
  const wl = useWatchlist();
  const s = useApp();
  return wl?.symbols ?? s.favorites;
}

export function useMotionClass(): string {
  const motion = useStore((s) => s.settings.motion);
  return motion === "off" ? "motion-off" : motion === "reduced" ? "motion-reduced" : "";
}

export function useAnimeState(indexChange: number, score: number, sessionOpen: boolean, connected: boolean): AnimeState {
  return useMemo(() => {
    if (!connected) return "disconnected";
    if (!sessionOpen) return "closed";
    if (indexChange <= -3) return "crash";
    if (indexChange >= 2.5) return "rally";
    if (score <= 22) return "strongBear";
    if (score <= 42) return "mildBear";
    if (score >= 82) return "strongBull";
    if (score >= 66) return "breakout";
    if (score >= 56) return "mildBull";
    return "neutral";
  }, [indexChange, score, sessionOpen, connected]);
}
