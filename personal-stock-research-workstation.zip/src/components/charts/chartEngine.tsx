import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Candle, ChartType } from "../../lib/types";
import type { Pt } from "../../lib/indicators";
import type { Drawing } from "../../lib/store";
import { cn } from "../../utils/cn";

export const AXIS_W = 62;
export const TIME_H = 20;

export interface ViewWindow {
  start: number;
  end: number; // exclusive
}

export function clampView(len: number, start: number, end: number): ViewWindow {
  const count = Math.max(10, Math.min(len, Math.round(end - start)));
  let s = Math.max(0, Math.min(start, len - count));
  if (s + count > len) s = len - count;
  return { start: s, end: s + count };
}

export function useView(len: number, initial = 140): [ViewWindow, (v: ViewWindow) => void] {
  const [view, setView] = useState<ViewWindow>(() => clampView(len, Math.max(0, len - initial), len));
  useEffect(() => {
    setView((v) => clampView(len, v.start, v.end));
  }, [len]);
  return [view, setView];
}

/* ------------------------------------------------------------------ *
 * scale helpers
 * ------------------------------------------------------------------ */
function niceTicks(min: number, max: number, count = 5): number[] {
  const span = max - min || 1;
  const raw = span / count;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  const step = (norm >= 5 ? 5 : norm >= 2 ? 2 : norm >= 1 ? 1 : 0.5) * mag;
  const start = Math.ceil(min / step) * step;
  const out: number[] = [];
  for (let v = start; v <= max + 1e-9; v += step) out.push(+v.toFixed(6));
  return out;
}

function fmtAxis(v: number) {
  const a = Math.abs(v);
  if (a >= 1e9) return `${(v / 1e9).toFixed(2)}B`;
  if (a >= 1e6) return `${(v / 1e6).toFixed(2)}M`;
  if (a >= 1e4) return `${(v / 1e3).toFixed(1)}K`;
  if (a >= 100) return v.toFixed(0);
  return v.toFixed(2);
}

function fmtTime(ts: number, intraday: boolean) {
  const d = new Date(ts * 1000);
  if (intraday)
    return d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
  return d.toLocaleDateString("en-US", { day: "2-digit", month: "short" });
}

function fmtTimeLong(ts: number, intraday: boolean) {
  const d = new Date(ts * 1000);
  if (intraday)
    return `${d.toLocaleDateString("en-US", { day: "2-digit", month: "short" })} ${d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })}`;
  return d.toLocaleDateString("en-US", { weekday: "short", day: "2-digit", month: "short", year: "numeric" });
}

export function heikin(c: Candle[]): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i < c.length; i++) {
    const close = (c[i].open + c[i].high + c[i].low + c[i].close) / 4;
    const open = i === 0 ? (c[0].open + c[0].close) / 2 : (out[i - 1].open + out[i - 1].close) / 2;
    out.push({
      time: c[i].time,
      open,
      close,
      high: Math.max(c[i].high, open, close),
      low: Math.min(c[i].low, open, close),
      volume: c[i].volume,
    });
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * Price canvas
 * ------------------------------------------------------------------ */
export interface Overlay {
  label: string;
  data: Pt[];
  color: string;
  width?: number;
  dashed?: boolean;
  dots?: boolean;
  band?: boolean;
  fillTo?: Pt[];
  fillColor?: string;
}

export interface PriceCanvasProps {
  candles: Candle[];
  type: ChartType;
  view: ViewWindow;
  onView: (v: ViewWindow) => void;
  overlays?: Overlay[];
  volumeData?: number[];
  logScale?: boolean;
  height?: number;
  baseline?: number;
  drawings?: Drawing[];
  tool?: string | null;
  onAddDrawing?: (d: Drawing) => void;
  livePrice?: number;
  compare?: { label: string; data: Pt[]; color: string }[];
  className?: string;
}

export function PriceCanvas(props: PriceCanvasProps) {
  const {
    candles,
    type,
    view,
    onView,
    overlays = [],
    volumeData,
    logScale,
    height: hProp = 380,
    baseline,
    drawings = [],
    tool,
    onAddDrawing,
    livePrice,
    compare = [],
    className,
  } = props;

  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ w: 800, h: hProp });
  const [cursor, setCursor] = useState<{ x: number; y: number; idx: number } | null>(null);
  const drag = useRef<{ x: number; start: number } | null>(null);
  const anchor = useRef<{ t: number; p: number } | null>(null);
  const freeHand = useRef<{ t: number; p: number }[]>([]);
  const [preview, setPreview] = useState<{ t: number; p: number } | null>(null);

  const showVolume = volumeData !== undefined;
  const volH = showVolume ? 52 : 0;
  const axisW = AXIS_W;
  const timeH = TIME_H;

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      setSize({ w: el.clientWidth, h: el.clientHeight });
    });
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  const geom = useMemo(() => {
    const W = size.w;
    const H = size.h;
    const plotW = W - axisW;
    const priceTop = 10;
    const priceBottom = H - timeH - volH - 6;
    const count = Math.max(2, view.end - view.start);
    const barW = plotW / count;
    return { W, H, plotW, priceTop, priceBottom, count, barW };
  }, [size, view, volH, timeH, axisW]);

  const range = useMemo(() => {
    const slice = candles.slice(view.start, view.end);
    let min = Infinity;
    let max = -Infinity;
    for (const c of slice) {
      min = Math.min(min, c.low);
      max = Math.max(max, c.high);
    }
    if (baseline !== undefined) {
      min = Math.min(min, baseline);
      max = Math.max(max, baseline);
    }
    for (const o of overlays) {
      for (let i = view.start; i < view.end; i++) {
        const v = o.data[i];
        if (v == null) continue;
        min = Math.min(min, v);
        max = Math.max(max, v);
      }
    }
    for (const c of compare) {
      for (let i = view.start; i < view.end; i++) {
        const v = c.data[i];
        if (v == null) continue;
        min = Math.min(min, v);
        max = Math.max(max, v);
      }
    }
    if (!isFinite(min) || !isFinite(max)) return { min: 0, max: 1 };
    const pad = (max - min) * 0.08 || max * 0.01;
    return { min: Math.max(0, min - pad), max: max + pad };
  }, [candles, view, overlays, baseline, compare]);

  const xOf = useCallback(
    (i: number) => (i - view.start + 0.5) * geom.barW,
    [view.start, geom.barW],
  );

  const yOf = useCallback(
    (p: number) => {
      const { priceTop, priceBottom } = geom;
      if (logScale) {
        const lmin = Math.log(Math.max(1e-6, range.min));
        const lmax = Math.log(Math.max(1e-6, range.max));
        const t = (Math.log(Math.max(1e-6, p)) - lmin) / (lmax - lmin || 1);
        return priceBottom - t * (priceBottom - priceTop);
      }
      const t = (p - range.min) / (range.max - range.min || 1);
      return priceBottom - t * (priceBottom - priceTop);
    },
    [geom, range, logScale],
  );

  const pOf = useCallback(
    (y: number) => {
      const { priceTop, priceBottom } = geom;
      const t = (priceBottom - y) / (priceBottom - priceTop || 1);
      if (logScale) {
        const lmin = Math.log(Math.max(1e-6, range.min));
        const lmax = Math.log(Math.max(1e-6, range.max));
        return Math.exp(lmin + t * (lmax - lmin));
      }
      return range.min + t * (range.max - range.min);
    },
    [geom, range, logScale],
  );

  const tOf = useCallback(
    (x: number) => {
      const i = Math.floor(x / geom.barW) + view.start;
      return candles[Math.max(0, Math.min(candles.length - 1, i))]?.time ?? Date.now() / 1000;
    },
    [geom.barW, view.start, candles],
  );

  const tToX = useCallback(
    (t: number) => {
      const idx = candles.findIndex((c) => c.time >= t);
      const i = idx === -1 ? candles.length - 1 : idx;
      return xOf(i);
    },
    [candles, xOf],
  );

  /* ------------------------------ draw ------------------------------ */
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const { W, H, plotW, priceTop, priceBottom, count, barW } = geom;
    cv.width = W * dpr;
    cv.height = H * dpr;
    cv.style.width = `${W}px`;
    cv.style.height = `${H}px`;
    const g = cv.getContext("2d");
    if (!g) return;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, W, H);

    const slice = candles.slice(view.start, view.end);
    if (!slice.length) return;

    // grid + price axis
    g.font = "500 10px Inter, system-ui, sans-serif";
    g.textBaseline = "middle";
    const ticks = niceTicks(range.min, range.max, Math.max(3, Math.floor((priceBottom - priceTop) / 54)));
    g.strokeStyle = "#F1EFF6";
    g.lineWidth = 1;
    ticks.forEach((t) => {
      const y = Math.round(yOf(t)) + 0.5;
      g.beginPath();
      g.moveTo(0, y);
      g.lineTo(plotW, y);
      g.stroke();
      g.fillStyle = "#A4A2AB";
      g.textAlign = "left";
      g.fillText(fmtAxis(t), plotW + 8, y);
    });

    // baseline
    if (baseline !== undefined) {
      const y = Math.round(yOf(baseline)) + 0.5;
      g.strokeStyle = "#DCD9E3";
      g.setLineDash([3, 3]);
      g.beginPath();
      g.moveTo(0, y);
      g.lineTo(plotW, y);
      g.stroke();
      g.setLineDash([]);
    }

    // time axis
    const intraday = ["1m", "3m", "5m", "15m", "30m", "1H", "2H", "4H"].includes(type ? "" : "") || (slice.length > 1 && slice[1].time - slice[0].time < 86400);
    const every = Math.max(1, Math.round(count / Math.max(3, Math.floor(plotW / 92))));
    g.textAlign = "center";
    for (let i = 0; i < count; i += every) {
      const c = slice[i];
      if (!c) continue;
      const x = Math.round(xOf(view.start + i)) + 0.5;
      g.strokeStyle = "#F5F4F8";
      g.beginPath();
      g.moveTo(x, priceTop);
      g.lineTo(x, H - timeH);
      g.stroke();
      g.fillStyle = "#A4A2AB";
      g.fillText(fmtTime(c.time, intraday), x, H - timeH / 2);
    }

    // volume strip
    if (showVolume && volumeData) {
      const vmax = Math.max(...volumeData.slice(view.start, view.end), 1);
      const vTop = H - timeH - volH + 8;
      const vBot = H - timeH - 4;
      for (let i = 0; i < slice.length; i++) {
        const c = slice[i];
        const v = volumeData[view.start + i] ?? c.volume;
        const h = ((v / vmax) * (vBot - vTop)) || 0;
        const up = c.close >= c.open;
        g.fillStyle = up ? "rgba(39,166,106,0.28)" : "rgba(227,93,104,0.26)";
        const x = xOf(view.start + i) - Math.max(1, barW * 0.3) / 2;
        g.fillRect(x, vBot - h, Math.max(1, barW * 0.6), h);
      }
      const vAvg = volumeData.slice(Math.max(0, view.start), view.end).reduce((a, b) => a + b, 0) / Math.max(1, count);
      g.strokeStyle = "rgba(128,102,255,0.4)";
      g.setLineDash([4, 4]);
      g.beginPath();
      g.moveTo(0, vBot - (vAvg / vmax) * (vBot - vTop));
      g.lineTo(plotW, vBot - (vAvg / vmax) * (vBot - vTop));
      g.stroke();
      g.setLineDash([]);
    }

    // ---- series ----
    const drawLine = (data: Pt[], color: string, width = 1.6, dashed = false, dots = false) => {
      g.strokeStyle = color;
      g.lineWidth = width;
      g.setLineDash(dashed ? [4, 3] : []);
      g.beginPath();
      let started = false;
      for (let i = view.start; i < view.end; i++) {
        const v = data[i];
        if (v == null) {
          started = false;
          continue;
        }
        const x = xOf(i);
        const y = yOf(v);
        if (!started) {
          g.moveTo(x, y);
          started = true;
        } else g.lineTo(x, y);
      }
      g.stroke();
      g.setLineDash([]);
      if (dots) {
        g.fillStyle = color;
        for (let i = view.start; i < view.end; i++) {
          const v = data[i];
          if (v == null) continue;
          g.beginPath();
          g.arc(xOf(i), yOf(v), 1.5, 0, Math.PI * 2);
          g.fill();
        }
      }
    };

    const drawBand = (upper: Pt[], lower: Pt[], fillCol: string) => {
      g.beginPath();
      let started = false;
      for (let i = view.start; i < view.end; i++) {
        const v = upper[i];
        if (v == null) continue;
        const x = xOf(i);
        const y = yOf(v);
        if (!started) {
          g.moveTo(x, y);
          started = true;
        } else g.lineTo(x, y);
      }
      for (let i = view.end - 1; i >= view.start; i--) {
        const v = lower[i];
        if (v == null) continue;
        g.lineTo(xOf(i), yOf(v));
      }
      g.closePath();
      g.fillStyle = fillCol;
      g.fill();
    };

    // bands first
    for (const o of overlays) {
      if (o.band && o.fillTo) drawBand(o.data, o.fillTo, o.fillColor ?? "rgba(128,102,255,0.07)");
    }

    const bodyW = Math.max(1, Math.min(barW * 0.68, 16));

    if (type === "line" || type === "area" || type === "mountain" || type === "step" || type === "baseline") {
      const pts: [number, number][] = [];
      for (let i = view.start; i < view.end; i++) {
        if (type === "step" && pts.length) {
          const prev = candles[i - 1];
          pts.push([xOf(i - 1) + barW / 2, yOf(prev.close)]);
        }
        pts.push([xOf(i), yOf(candles[i].close)]);
      }
      if (type === "area" || type === "mountain" || type === "baseline") {
        const grad = g.createLinearGradient(0, priceTop, 0, priceBottom);
        const col = type === "baseline" && candles[view.end - 1].close < (baseline ?? 0) ? "#E35D68" : "#8066FF";
        grad.addColorStop(0, col + "33");
        grad.addColorStop(1, col + "00");
        g.beginPath();
        g.moveTo(pts[0][0], priceBottom);
        pts.forEach((p) => g.lineTo(p[0], p[1]));
        g.lineTo(pts[pts.length - 1][0], priceBottom);
        g.closePath();
        g.fillStyle = grad;
        g.fill();
      }
      g.strokeStyle = type === "baseline" ? (candles[view.end - 1].close < (baseline ?? 0) ? "#E35D68" : "#8066FF") : "#8066FF";
      g.lineWidth = 1.8;
      g.beginPath();
      pts.forEach((p, i) => (i === 0 ? g.moveTo(p[0], p[1]) : g.lineTo(p[0], p[1])));
      g.stroke();
    } else if (type === "histogram") {
      for (let i = view.start; i < view.end; i++) {
        const c = candles[i];
        const up = c.close >= c.open;
        const y0 = yOf(c.open);
        const y1 = yOf(c.close);
        g.fillStyle = up ? "#27A66A" : "#E35D68";
        const x = xOf(i) - bodyW / 2;
        g.fillRect(x, Math.min(y0, y1), bodyW, Math.max(1, Math.abs(y1 - y0)));
      }
    } else if (type === "renko" || type === "kagi" || type === "pnf") {
      for (let i = view.start; i < view.end; i++) {
        const c = candles[i];
        const up = c.close >= c.open;
        const col = up ? "#27A66A" : "#E35D68";
        if (type === "pnf") {
          g.fillStyle = col;
          g.beginPath();
          g.arc(xOf(i), yOf(c.close), Math.max(1.6, bodyW * 0.3), 0, Math.PI * 2);
          g.fill();
        } else {
          g.strokeStyle = col;
          g.lineWidth = Math.max(1.2, bodyW * 0.4);
          g.beginPath();
          g.moveTo(xOf(i) - bodyW / 2, yOf(c.open));
          g.lineTo(xOf(i) + bodyW / 2, yOf(c.close));
          g.stroke();
        }
      }
    } else if (type === "bars" || type === "hlc") {
      for (let i = view.start; i < view.end; i++) {
        const c = candles[i];
        const up = c.close >= c.open;
        g.strokeStyle = up ? "#27A66A" : "#E35D68";
        g.lineWidth = 1.2;
        const x = xOf(i);
        g.beginPath();
        g.moveTo(x, yOf(c.high));
        g.lineTo(x, yOf(c.low));
        g.moveTo(x - bodyW / 2, yOf(c.open));
        g.lineTo(x, yOf(c.open));
        if (type === "bars") {
          g.moveTo(x + bodyW / 2, yOf(c.close));
          g.lineTo(x, yOf(c.close));
        }
        g.stroke();
      }
    } else {
      // candles / hollow / heikin
      for (let i = view.start; i < view.end; i++) {
        const c = candles[i];
        const up = c.close >= c.open;
        const col = up ? "#27A66A" : "#E35D68";
        const x = Math.round(xOf(i));
        g.strokeStyle = col;
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(x + 0.5, yOf(c.high));
        g.lineTo(x + 0.5, yOf(c.low));
        g.stroke();
        const yO = yOf(c.open);
        const yC = yOf(c.close);
        const top = Math.min(yO, yC);
        const h = Math.max(1, Math.abs(yC - yO));
        if (type === "hollow" && up) {
          g.strokeStyle = col;
          g.strokeRect(x - bodyW / 2 + 0.5, top + 0.5, bodyW, h);
        } else {
          g.fillStyle = col;
          g.fillRect(x - bodyW / 2, top, bodyW, h);
        }
      }
    }

    // overlays (lines)
    for (const o of overlays) {
      if (o.band) continue;
      drawLine(o.data, o.color, o.width ?? 1.5, o.dashed, o.dots);
    }

    // compare series
    for (const c of compare) drawLine(c.data, c.color, 1.4, true);

    // live price line
    if (livePrice !== undefined && livePrice > 0) {
      const y = yOf(livePrice);
      if (y > priceTop && y < priceBottom) {
        g.strokeStyle = "rgba(128,102,255,0.55)";
        g.setLineDash([4, 4]);
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(0, y + 0.5);
        g.lineTo(plotW, y + 0.5);
        g.stroke();
        g.setLineDash([]);
        g.fillStyle = "#8066FF";
        const txt = fmtAxis(livePrice);
        const tw = g.measureText(txt).width + 10;
        g.beginPath();
        g.roundRect(plotW + 4, y - 8, Math.max(axisW - 8, tw), 16, 5);
        g.fill();
        g.fillStyle = "#fff";
        g.textAlign = "center";
        g.fillText(txt, plotW + 4 + Math.max(axisW - 8, tw) / 2, y + 0.5);
      }
    }

    // drawings
    const drawShapes = (items: Drawing[]) => {
      for (const d of items) {
        if (d.hidden) continue;
        const a = d.points[0];
        const b = d.points[1] ?? d.points[0];
        const x1 = tToX(a.t);
        const y1 = yOf(a.p);
        const x2 = tToX(b.t);
        const y2 = yOf(b.p);
        g.strokeStyle = d.color;
        g.fillStyle = d.color + "1a";
        g.lineWidth = d.locked ? 1.8 : 1.4;
        g.setLineDash(d.locked ? [5, 4] : []);
        const label = (txt: string, x: number, y: number) => {
          g.font = "600 10px Inter, system-ui, sans-serif";
          const w = g.measureText(txt).width + 8;
          g.fillStyle = "rgba(24,23,28,0.82)";
          g.beginPath();
          g.roundRect(x, y - 8, w, 15, 4);
          g.fill();
          g.fillStyle = "#fff";
          g.textAlign = "left";
          g.fillText(txt, x + 4, y + 0.5);
        };
        switch (d.tool) {
          case "hline":
          case "support":
          case "resistance": {
            g.beginPath();
            g.moveTo(0, y1);
            g.lineTo(plotW, y1);
            g.stroke();
            label(`${fmtAxis(a.p)}`, 8, y1 - 10);
            break;
          }
          case "vline":
            g.beginPath();
            g.moveTo(x1, priceTop);
            g.lineTo(x1, priceBottom);
            g.stroke();
            break;
          case "text":
          case "note":
          case "priceLabel":
            label(d.text || "Note", x1, y1);
            break;
          case "rect":
          case "zone":
          case "rr":
          case "long":
          case "short": {
            g.beginPath();
            g.rect(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
            g.fill();
            g.stroke();
            if (d.tool === "long" || d.tool === "short") {
              const entry = a.p;
              const target = d.tool === "long" ? b.p : a.p + (a.p - b.p);
              const stop = d.tool === "long" ? a.p - (b.p - a.p) : b.p;
              label(`Entry ${fmtAxis(entry)}`, Math.min(x1, x2) + 4, yOf(entry) - 10);
              label(`Target ${fmtAxis(target)}`, Math.min(x1, x2) + 4, yOf(target) - 10);
              label(`Stop ${fmtAxis(stop)}`, Math.min(x1, x2) + 4, yOf(stop) - 10);
            }
            if (d.tool === "rr") label(`R:R ${Math.abs((b.p - a.p) / (a.p - b.p || 1) * -1).toFixed(1)}`, Math.min(x1, x2) + 4, Math.min(y1, y2) + 12);
            break;
          }
          case "fib":
          case "fibext":
          case "fibchan": {
            const levels = d.tool === "fibext" ? [0, 0.618, 1, 1.618, 2.618] : [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];
            g.font = "500 10px Inter, system-ui, sans-serif";
            levels.forEach((lv, idx) => {
              const price = a.p + (b.p - a.p) * lv;
              const y = yOf(price);
              g.strokeStyle = ["#8066FF", "#E35D68", "#E9A23B", "#27A66A", "#6D72E8", "#A4A2AB", "#8066FF"][idx % 7];
              g.beginPath();
              g.moveTo(Math.min(x1, x2), y);
              g.lineTo(Math.max(x1, x2) + 40, y);
              g.stroke();
              g.fillStyle = "#717079";
              g.textAlign = "left";
              g.fillText(`${(lv * 100).toFixed(1)}%  ${fmtAxis(price)}`, Math.min(x1, x2) + 4, y - 6);
            });
            break;
          }
          case "brush": {
            g.beginPath();
            d.points.forEach((p, i) => (i === 0 ? g.moveTo(tToX(p.t), yOf(p.p)) : g.lineTo(tToX(p.t), yOf(p.p))));
            g.stroke();
            break;
          }
          case "measure": {
            g.beginPath();
            g.rect(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x2 - x1), Math.abs(y2 - y1));
            g.fillStyle = (b.p >= a.p ? "rgba(39,166,106,0.12)" : "rgba(227,93,104,0.12)");
            g.fill();
            g.stroke();
            const pct = ((b.p - a.p) / a.p) * 100;
            label(`${pct >= 0 ? "+" : ""}${pct.toFixed(2)}% · ${fmtAxis(b.p - a.p)}`, (x1 + x2) / 2 - 40, (y1 + y2) / 2);
            break;
          }
          case "daterange":
          case "pricerange": {
            g.beginPath();
            g.moveTo(x1, d.tool === "pricerange" ? y1 : priceBottom);
            g.lineTo(x2, d.tool === "pricerange" ? y2 : priceBottom);
            g.stroke();
            label(d.tool === "pricerange" ? fmtAxis(Math.abs(b.p - a.p)) : `${Math.round(Math.abs(b.t - a.t) / 86400)}d`, (x1 + x2) / 2 - 20, priceBottom - 14);
            break;
          }
          case "circle":
          case "ellipse": {
            g.beginPath();
            g.ellipse((x1 + x2) / 2, (y1 + y2) / 2, Math.abs(x2 - x1) / 2, Math.abs(y2 - y1) / 2, 0, 0, Math.PI * 2);
            g.fill();
            g.stroke();
            break;
          }
          case "arrow": {
            g.beginPath();
            g.moveTo(x1, y1);
            g.lineTo(x2, y2);
            g.stroke();
            const ang = Math.atan2(y2 - y1, x2 - x1);
            g.beginPath();
            g.moveTo(x2, y2);
            g.lineTo(x2 - 9 * Math.cos(ang - 0.4), y2 - 9 * Math.sin(ang - 0.4));
            g.lineTo(x2 - 9 * Math.cos(ang + 0.4), y2 - 9 * Math.sin(ang + 0.4));
            g.closePath();
            g.fillStyle = d.color;
            g.fill();
            break;
          }
          case "regression":
          case "channel":
          case "ray":
          case "extended":
          case "trend":
          default: {
            g.beginPath();
            g.moveTo(x1, y1);
            if (d.tool === "ray") {
              const dx = x2 - x1;
              const dy = y2 - y1;
              const k = (plotW - x1) / (dx || 1);
              g.lineTo(x1 + dx * Math.max(1, k), y1 + dy * Math.max(1, k));
            } else if (d.tool === "extended") {
              g.lineTo(x1 - (x2 - x1) * 2, y1 - (y2 - y1) * 2);
              g.moveTo(x1, y1);
              g.lineTo(x2 + (x2 - x1) * 2, y2 + (y2 - y1) * 2);
            } else if (d.tool === "channel" || d.tool === "regression") {
              g.lineTo(x2, y2);
              g.moveTo(x1, y1 + 26);
              g.lineTo(x2, y2 + 26);
            } else {
              g.lineTo(x2, y2);
            }
            g.stroke();
            if (d.tool === "trend" || d.tool === "ray") {
              g.fillStyle = d.color;
              g.beginPath();
              g.arc(x1, y1, 2.6, 0, Math.PI * 2);
              g.fill();
              g.beginPath();
              g.arc(x2, y2, 2.6, 0, Math.PI * 2);
              g.fill();
            }
          }
        }
        g.setLineDash([]);
      }
    };

    drawShapes(drawings);
    if (anchor.current && preview) {
      drawShapes([
        {
          id: "preview",
          tool: tool ?? "trend",
          points: [anchor.current, preview],
          color: "#8066FF",
          locked: false,
          hidden: false,
        },
      ]);
    }

    // crosshair
    if (cursor) {
      const cx = Math.round(cursor.x) + 0.5;
      const cy = Math.round(cursor.y) + 0.5;
      g.strokeStyle = "#C9C4DB";
      g.setLineDash([3, 3]);
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(cx, priceTop);
      g.lineTo(cx, H - timeH);
      g.moveTo(0, cy);
      g.lineTo(plotW, cy);
      g.stroke();
      g.setLineDash([]);
      // price chip
      const price = pOf(cursor.y);
      g.fillStyle = "#18171C";
      g.beginPath();
      g.roundRect(plotW + 4, cy - 8, axisW - 8, 16, 5);
      g.fill();
      g.fillStyle = "#fff";
      g.textAlign = "center";
      g.fillText(fmtAxis(price), plotW + 4 + (axisW - 8) / 2, cy + 0.5);
    }
  }, [candles, type, view, geom, range, overlays, volumeData, showVolume, logScale, baseline, drawings, cursor, livePrice, compare, xOf, yOf, tToX, preview, tool]);

  /* ------------------------------ pointer ------------------------------ */
  const idxAt = (x: number) => Math.max(0, Math.min(candles.length - 1, Math.floor(x / geom.barW) + view.start));

  const onMove = (e: React.PointerEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - r.left;
    const y = e.clientY - r.top;
    if (drag.current) {
      const dx = x - drag.current.x;
      const shift = Math.round(dx / geom.barW);
      const ns = drag.current.start - shift;
      onView(clampView(candles.length, ns, ns + (view.end - view.start)));
      return;
    }
    setCursor({ x, y, idx: idxAt(x) });
    if (anchor.current && tool) {
      setPreview({ t: tOf(x), p: pOf(y) });
      if (tool === "brush") freeHand.current.push({ t: tOf(x), p: pOf(y) });
    }
  };

  const onDown = (e: React.PointerEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - r.left;
    const y = e.clientY - r.top;
    const pt = { t: tOf(x), p: pOf(y) };
    if (tool === "hline" || tool === "vline" || tool === "text" || tool === "note" || tool === "priceLabel" || tool === "support" || tool === "resistance") {
      onAddDrawing?.({
        id: `d-${Date.now()}`,
        tool,
        points: [pt],
        color: tool === "support" ? "#27A66A" : tool === "resistance" ? "#E35D68" : "#8066FF",
        text: tool === "text" || tool === "note" ? "Note" : fmtAxis(pt.p),
        locked: false,
        hidden: false,
      });
      return;
    }
    if (tool === "brush") {
      anchor.current = pt;
      freeHand.current = [pt];
      return;
    }
    if (tool) {
      anchor.current = pt;
      setPreview(pt);
      return;
    }
    drag.current = { x, start: view.start };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const onUp = () => {
    drag.current = null;
    if (anchor.current && tool) {
      if (tool === "brush") {
        if (freeHand.current.length > 2)
          onAddDrawing?.({
            id: `d-${Date.now()}`,
            tool: "brush",
            points: freeHand.current,
            color: "#8066FF",
            locked: false,
            hidden: false,
          });
      } else if (preview) {
        onAddDrawing?.({
          id: `d-${Date.now()}`,
          tool,
          points: [anchor.current, preview],
          color: "#8066FF",
          locked: false,
          hidden: false,
        });
      }
      anchor.current = null;
      freeHand.current = [];
      setPreview(null);
    }
  };

  const onWheel = (e: React.WheelEvent) => {
    const count = view.end - view.start;
    const factor = e.deltaY > 0 ? 1.12 : 0.89;
    const next = Math.max(12, Math.min(candles.length, Math.round(count * factor)));
    const ratio = (cursor?.x ?? geom.plotW / 2) / geom.plotW;
    const s = Math.round(view.start + (count - next) * ratio);
    onView(clampView(candles.length, s, s + next));
  };

  const hovered = cursor ? candles[cursor.idx] : null;

  return (
    <div
      ref={wrapRef}
      className={cn("relative h-full w-full select-none", tool && "cursor-crosshair", !tool && "cursor-grab", className)}
      onPointerMove={onMove}
      onPointerDown={onDown}
      onPointerUp={onUp}
      onPointerLeave={() => {
        setCursor(null);
        drag.current = null;
      }}
      onWheel={onWheel}
    >
      <canvas ref={canvasRef} className="block" />
      {hovered && cursor && (
        <div
          className="pointer-events-none absolute z-10 rounded-[12px] border border-line bg-white/95 px-2.5 py-2 text-[11px] shadow-[var(--shadow-lift)] backdrop-blur"
          style={{
            left: Math.min(Math.max(8, cursor.x + 14), (size.w || 800) - 168),
            top: Math.min(Math.max(8, cursor.y - 10), (size.h || 400) - 110),
          }}
        >
          <div className="mb-1 text-[10px] font-medium text-ink3">{fmtTimeLong(hovered.time, (hovered.time % 86400) !== 0)}</div>
          <div className="tabnum grid grid-cols-2 gap-x-3 gap-y-0.5">
            <span className="text-ink3">O</span>
            <span className="text-right font-semibold text-ink">{hovered.open.toFixed(2)}</span>
            <span className="text-ink3">H</span>
            <span className="text-right font-semibold text-pos">{hovered.high.toFixed(2)}</span>
            <span className="text-ink3">L</span>
            <span className="text-right font-semibold text-neg">{hovered.low.toFixed(2)}</span>
            <span className="text-ink3">C</span>
            <span className="text-right font-semibold text-ink">{hovered.close.toFixed(2)}</span>
            {volumeData && (
              <>
                <span className="text-ink3">Vol</span>
                <span className="text-right font-semibold text-ink2">{fmtAxis(volumeData[cursor.idx])}</span>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Sub pane (oscillators)
 * ------------------------------------------------------------------ */
export interface SubSeries {
  label: string;
  data: Pt[];
  color: string;
  kind?: "line" | "hist" | "dots";
  dashed?: boolean;
}

export function SubPane({
  candles,
  series,
  view,
  height = 104,
  bands,
  zero,
  title,
  onView,
  className,
}: {
  candles: Candle[];
  series: SubSeries[];
  view: ViewWindow;
  height?: number;
  bands?: { value: number; color: string }[];
  zero?: boolean;
  title: string;
  onView: (v: ViewWindow) => void;
  className?: string;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ w: 800, h: height });

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = size.w;
    const H = size.h;
    cv.width = W * dpr;
    cv.height = H * dpr;
    cv.style.width = `${W}px`;
    cv.style.height = `${H}px`;
    const g = cv.getContext("2d");
    if (!g) return;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, W, H);

    const plotW = W - AXIS_W;
    const top = 14;
    const bottom = H - TIME_H;
    let min = Infinity;
    let max = -Infinity;
    for (const s of series)
      for (let i = view.start; i < view.end; i++) {
        const v = s.data[i];
        if (v == null) continue;
        min = Math.min(min, v);
        max = Math.max(max, v);
      }
    for (const b of bands ?? []) {
      min = Math.min(min, b.value);
      max = Math.max(max, b.value);
    }
    if (zero) {
      min = Math.min(min, 0);
      max = Math.max(max, 0);
    }
    if (!isFinite(min) || !isFinite(max)) {
      min = 0;
      max = 1;
    }
    const pad = (max - min) * 0.12 || 1;
    min -= pad;
    max += pad;
    const barW = plotW / Math.max(2, view.end - view.start);
    const yOf = (v: number) => bottom - ((v - min) / (max - min || 1)) * (bottom - top);
    const xOf = (i: number) => (i - view.start + 0.5) * barW;

    g.font = "500 10px Inter, system-ui, sans-serif";
    g.textBaseline = "middle";
    g.strokeStyle = "#F1EFF6";
    for (const b of bands ?? []) {
      const y = Math.round(yOf(b.value)) + 0.5;
      g.beginPath();
      g.moveTo(0, y);
      g.lineTo(plotW, y);
      g.stroke();
      g.fillStyle = b.color;
      g.textAlign = "left";
      g.fillText(fmtAxis(b.value), plotW + 8, y);
    }
    if (zero) {
      const y = Math.round(yOf(0)) + 0.5;
      g.strokeStyle = "#DCD9E3";
      g.beginPath();
      g.moveTo(0, y);
      g.lineTo(plotW, y);
      g.stroke();
    }
    const midT = niceTicks(min, max, 2).find((t) => t > min && t < max && !(bands ?? []).some((b) => b.value === t));
    if (midT !== undefined) {
      const y = Math.round(yOf(midT)) + 0.5;
      g.strokeStyle = "#F1EFF6";
      g.beginPath();
      g.moveTo(0, y);
      g.lineTo(plotW, y);
      g.stroke();
      g.fillStyle = "#A4A2AB";
      g.textAlign = "left";
      g.fillText(fmtAxis(midT), plotW + 8, y);
    }

    // histogram-style series behind lines
    for (const s of series) {
      if (s.kind !== "hist") continue;
      for (let i = view.start; i < view.end; i++) {
        const v = s.data[i];
        if (v == null) continue;
        const y0 = yOf(0);
        const y1 = yOf(v);
        g.fillStyle = v >= 0 ? "rgba(39,166,106,0.35)" : "rgba(227,93,104,0.32)";
        g.fillRect(xOf(i) - Math.max(1, barW * 0.28), Math.min(y0, y1), Math.max(1, barW * 0.56), Math.max(1, Math.abs(y1 - y0)));
      }
    }

    for (const s of series) {
      if (s.kind === "hist") continue;
      g.strokeStyle = s.color;
      g.lineWidth = 1.4;
      g.setLineDash(s.dashed ? [4, 3] : []);
      g.beginPath();
      let started = false;
      for (let i = view.start; i < view.end; i++) {
        const v = s.data[i];
        if (v == null) {
          started = false;
          continue;
        }
        const x = xOf(i);
        const y = yOf(v);
        if (!started) {
          g.moveTo(x, y);
          started = true;
        } else g.lineTo(x, y);
      }
      g.stroke();
      g.setLineDash([]);
    }

    // time labels
    const count = view.end - view.start;
    const every = Math.max(1, Math.round(count / Math.max(2, Math.floor(plotW / 96))));
    g.fillStyle = "#A4A2AB";
    g.textAlign = "center";
    const intraday = candles.length > 1 && candles[1].time - candles[0].time < 86400;
    for (let i = 0; i < count; i += every) {
      const c = candles[view.start + i];
      if (!c) continue;
      g.fillText(fmtTime(c.time, intraday), xOf(view.start + i), H - TIME_H / 2);
    }

    // title chip
    g.fillStyle = "rgba(113,112,121,0.9)";
    g.font = "600 10px Inter, system-ui, sans-serif";
    g.textAlign = "left";
    g.fillText(title, 8, 10);
  }, [size, series, view, bands, zero, candles, title]);

  const dragRef = useRef<{ x: number; start: number } | null>(null);

  return (
    <div
      ref={wrapRef}
      className={cn("h-full w-full cursor-grab", className)}
      onPointerDown={(e) => {
        dragRef.current = { x: e.clientX, start: view.start };
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      }}
      onPointerMove={(e) => {
        if (!dragRef.current) return;
        const shift = Math.round((e.clientX - dragRef.current.x) / 6);
        const ns = dragRef.current.start - shift;
        onView(clampView(candles.length, ns, ns + (view.end - view.start)));
      }}
      onPointerUp={() => (dragRef.current = null)}
      onWheel={(e) => {
        const count = view.end - view.start;
        const next = Math.max(12, Math.min(candles.length, Math.round(count * (e.deltaY > 0 ? 1.12 : 0.89))));
        onView(clampView(candles.length, view.start + (count - next), view.start + (count - next) + next));
      }}
    >
      <canvas ref={canvasRef} className="block" />
    </div>
  );
}
