export type Currency = "INR" | "USD";
export type Region = "IN" | "US";
export type AssetKind = "stock" | "index" | "etf";

export interface Instrument {
  symbol: string;
  name: string;
  exchange: string;
  currency: Currency;
  region: Region;
  kind: AssetKind;
  sector: string;
  mcap: number; // in native currency, crores / millions
  base: number; // reference price
  vol: number; // daily volatility factor
  drift: number;
  pe?: number;
  pb?: number;
  eps?: number;
  beta?: number;
  divYield?: number;
  roe?: number;
  roce?: number;
  debtEquity?: number;
  netMargin?: number;
  revGrowth?: number;
  epsGrowth?: number;
  fcf?: number;
}

export interface Quote {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  open: number;
  high: number;
  low: number;
  previousClose: number;
  volume: number;
  avgVolume: number;
  timestamp: number;
}

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export type Timeframe = "1m" | "3m" | "5m" | "15m" | "30m" | "1H" | "2H" | "4H" | "1D" | "1W" | "1M";

export interface Series {
  symbol: string;
  tf: Timeframe;
  candles: Candle[];
}

export type ChartType =
  | "candles"
  | "hollow"
  | "bars"
  | "hlc"
  | "line"
  | "area"
  | "baseline"
  | "histogram"
  | "heikin"
  | "renko"
  | "kagi"
  | "pnf"
  | "range"
  | "step"
  | "mountain";

export interface MarketDataProvider {
  id: string;
  label: string;
  region: Region;
  searchSymbols(q: string): Promise<Instrument[]>;
  getQuote(symbol: string): Promise<Quote>;
  getCandles(symbol: string, tf: Timeframe, limit: number): Promise<Candle[]>;
  subscribeQuotes(symbols: string[], cb: (q: Quote) => void): () => void;
}

export type AlertCondition =
  | "price_above"
  | "price_below"
  | "price_cross_up"
  | "price_cross_down"
  | "pct_move"
  | "rsi_above"
  | "rsi_below"
  | "volume_above"
  | "sma_cross";

export interface AlertDef {
  id: string;
  symbol: string;
  condition: AlertCondition;
  value: number;
  frequency: "once" | "once_per_bar" | "every_cross";
  channels: { inApp: boolean; browser: boolean; sound: boolean };
  message: string;
  createdAt: number;
  triggeredAt?: number;
  active: boolean;
}

export type Severity = 0 | 1 | 2 | 3;

export interface NotificationItem {
  id: string;
  severity: Severity;
  category: "Price" | "Technical" | "Market" | "Earnings" | "System";
  title: string;
  body?: string;
  symbol?: string;
  ts: number;
  read: boolean;
}

export interface Toast {
  id: string;
  severity: Severity;
  title: string;
  body?: string;
  symbol?: string;
}

export interface Transaction {
  id: string;
  symbol: string;
  side: "buy" | "sell";
  qty: number;
  price: number;
  fees: number;
  date: string;
  note?: string;
  tags?: string[];
}

export interface JournalEntry {
  id: string;
  symbol: string;
  ts: number;
  thesis: string;
  notes: string;
  tags: string[];
  mood: "calm" | "confident" | "uncertain" | "regretful";
}

export type AnimeState =
  | "neutral"
  | "mildBull"
  | "strongBull"
  | "breakout"
  | "mildBear"
  | "strongBear"
  | "crash"
  | "rally"
  | "closed"
  | "disconnected";

export interface Watchlist {
  id: string;
  name: string;
  region: Region;
  color: string;
  symbols: string[];
}

export interface Settings {
  region: Region;
  density: "compact" | "comfortable";
  motion: "full" | "reduced" | "off";
  anime: "full" | "minimal" | "off";
  dataMode: "mock" | "live";
  crashIndexThreshold: number;
  crashStockThreshold: number;
  sound: boolean;
  browserNotify: boolean;
  showVolume: boolean;
  logScale: boolean;
  autoScale: boolean;
  crosshairMagnet: boolean;
  sidebarCollapsed: boolean;
  watchlistPanelOpen: boolean;
  defaultIndicators: string[];
  defaultChartType: ChartType;
}
