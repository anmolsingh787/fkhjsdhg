import { useEffect, useMemo, useRef, useState } from "react";
import { actions, useApp } from "../../lib/store";
import { INDICES, INSTRUMENTS, quote, searchSymbols } from "../../lib/marketData";
import { NAV } from "./Shell";
import { Icon } from "../ui/primitives";
import { cn } from "../../utils/cn";

interface Row {
  kind: "symbol" | "page" | "command" | "watchlist" | "recent";
  label: string;
  sub?: string;
  icon: string;
  run: () => void;
  badge?: string;
}

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useApp();
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setQ("");
      setSel(0);
      window.setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open]);

  const rows = useMemo<Row[]>(() => {
    const term = q.trim().toLowerCase();
    const out: Row[] = [];

    const symbols = term ? searchSymbols(term) : INSTRUMENTS.filter((i) => s.recent.includes(i.symbol));
    for (const i of symbols.slice(0, 9)) {
      const qt = quote(i.symbol);
      out.push({
        kind: term ? "symbol" : "recent",
        label: i.symbol,
        sub: `${i.name} · ${i.exchange} · ${qt.price.toFixed(2)}`,
        icon: i.kind === "index" ? "markets" : i.kind === "etf" ? "layers" : "chart",
        badge: `${qt.changePercent >= 0 ? "+" : ""}${qt.changePercent.toFixed(2)}%`,
        run: () => actions.openSymbol(i.symbol, "chart"),
      });
    }

    for (const n of NAV.filter((n) => !term || n.label.toLowerCase().includes(term)).slice(0, 5)) {
      out.push({ kind: "page", label: n.label, sub: "Navigate", icon: n.icon, run: () => actions.navigate(n.id) });
    }

    for (const w of s.watchlists.filter((w) => term && w.name.toLowerCase().includes(term)).slice(0, 3)) {
      out.push({
        kind: "watchlist",
        label: w.name,
        sub: `${w.symbols.length} symbols`,
        icon: "watchlist",
        run: () => {
          actions.setActiveWatchlist(w.id);
          actions.navigate("watchlists");
        },
      });
    }

    const cmds: Row[] = [
      { kind: "command", label: "Compare NVDA · AMD · QQQ", sub: "Compare lab", icon: "compare", run: () => { actions.navigate("compare", { compareSymbols: ["NVDA", "AMD", "QQQ"] }); } },
      { kind: "command", label: `Compare ${s.symbol} vs index`, sub: "Compare lab", icon: "compare", run: () => actions.navigate("compare", { compareSymbols: [s.symbol, s.settings.region === "IN" ? "NIFTY50" : "SPX"] }) },
      { kind: "command", label: `New alert on ${s.symbol}`, sub: "Alert builder", icon: "alerts", run: () => actions.navigate("alerts") },
      { kind: "command", label: "Toggle anime companion", sub: "Settings", icon: "spark", run: () => actions.setSettings({ anime: s.settings.anime === "off" ? "full" : "off" }) },
      { kind: "command", label: `Add RSI to ${s.symbol}`, sub: "Indicator", icon: "analytics", run: () => { if (!s.activeIndicators.includes("rsi")) actions.toggleIndicator("rsi"); actions.navigate("chart"); } },
      { kind: "command", label: `Open ${INDICES[s.settings.region][0]}`, sub: "Index chart", icon: "markets", run: () => actions.openSymbol(INDICES[s.settings.region][0], "chart") },
      { kind: "command", label: "Run screener", sub: "Screen market", icon: "screener", run: () => actions.navigate("screener") },
      { kind: "command", label: "Toggle reduced motion", sub: "Motion", icon: "wave", run: () => actions.setSettings({ motion: s.settings.motion === "full" ? "reduced" : "full" }) },
    ];
    for (const c of cmds.filter((c) => term && (c.label.toLowerCase().includes(term) || (c.sub ?? "").toLowerCase().includes(term))).slice(0, 5)) out.push(c);

    return out.slice(0, 14);
  }, [q, s.recent, s.watchlists, s.symbol, s.settings, s.activeIndicators]);

  useEffect(() => setSel(0), [rows.length]);

  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSel((v) => Math.min(rows.length - 1, v + 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setSel((v) => Math.max(0, v - 1));
      } else if (e.key === "Enter") {
        e.preventDefault();
        rows[sel]?.run();
        onClose();
      } else if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, rows, sel, onClose]);

  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>(`[data-i="${sel}"]`)?.scrollIntoView({ block: "nearest" });
  }, [sel]);

  if (!open) return null;

  const groupLabel: Record<Row["kind"], string> = {
    symbol: "Symbols",
    recent: "Recent",
    page: "Pages",
    command: "Commands",
    watchlist: "Watchlists",
  };

  let lastKind = "";

  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center p-4 pt-[10vh]">
      <div className="anim-fade absolute inset-0 bg-[#1a1726]/28 backdrop-blur-[3px]" onClick={onClose} />
      <div className="anim-pop relative w-full max-w-[560px] overflow-hidden rounded-[22px] border border-line bg-shell shadow-[0_30px_90px_rgba(28,24,54,0.2)]">
        <div className="flex items-center gap-2.5 border-b border-line px-4 py-3">
          <Icon name="search" size={16} className="text-ink3" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search NSE / BSE / NYSE / Nasdaq symbols, pages, commands…"
            className="w-full bg-transparent text-[13.5px] text-ink outline-none placeholder:text-ink3"
          />
          <kbd className="rounded-md border border-line bg-muted px-1.5 py-[1px] text-[10px] font-semibold text-ink3">esc</kbd>
        </div>
        <div ref={listRef} className="max-h-[52vh] overflow-y-auto p-2">
          {rows.length === 0 && <p className="px-3 py-8 text-center text-[12px] text-ink3">No matches. Try RELIANCE, NVDA or “screener”.</p>}
          {rows.map((r, i) => {
            const header = r.kind !== lastKind ? groupLabel[r.kind] : null;
            lastKind = r.kind;
            return (
              <div key={`${r.kind}-${r.label}-${i}`}>
                {header && <p className="px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-[0.09em] text-ink3">{header}</p>}
                <button
                  data-i={i}
                  onMouseEnter={() => setSel(i)}
                  onClick={() => {
                    r.run();
                    onClose();
                  }}
                  className={cn(
                    "flex w-full items-center gap-2.5 rounded-[13px] px-3 py-2 text-left transition-colors",
                    sel === i ? "bg-brandsoft" : "hover:bg-muted",
                  )}
                >
                  <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px]", sel === i ? "bg-brand text-white" : "bg-muted text-ink2")}>
                    <Icon name={r.icon} size={14} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12.5px] font-semibold text-ink">{r.label}</span>
                    <span className="block truncate text-[11px] text-ink3">{r.sub}</span>
                  </span>
                  {r.badge && (
                    <span className={cn("tabnum shrink-0 rounded-full px-2 py-[2px] text-[10.5px] font-bold", r.badge.startsWith("+") ? "bg-possoft text-pos" : "bg-negsoft text-neg")}>
                      {r.badge}
                    </span>
                  )}
                </button>
              </div>
            );
          })}
        </div>
        <div className="flex items-center justify-between border-t border-line px-4 py-2 text-[10.5px] text-ink3">
          <span>↑↓ navigate · ↵ open · esc close</span>
          <span>AERRIK MARKET OS · demo data</span>
        </div>
      </div>
    </div>
  );
}
