import { useMemo, useState } from "react";
import { actions, useApp, useTick } from "../lib/store";
import { useCorrelationMatrix, usePortfolio } from "../lib/portfolio";
import { BY_SYMBOL, INDICES, fmtCompact, fmtSigned, getSeries, quote, session } from "../lib/marketData";
import { INDICATOR_CATALOG } from "../lib/indicators";
import { AreaChart, Donut } from "../components/market/widgets";
import { CompanionCard } from "../components/anime/Companion";
import { Badge, Card, CardHead, EmptyState, Field, GhostButton, Icon, Input, Pill, PrimaryButton, Segmented, Select, Toggle } from "../components/ui/primitives";
import { marketMood, moodLabel } from "../lib/marketData";
import { ScreenHead } from "./Overview";
import { cn } from "../utils/cn";
import type { AlertCondition, Region } from "../lib/types";

/* ================================================================== *
 * PORTFOLIO
 * ================================================================== */
export function PortfolioScreen() {
  useTick();
  const s = useApp();
  const pf = usePortfolio(s.transactions);
  const [form, setForm] = useState({ symbol: "RELIANCE", side: "buy" as "buy" | "sell", qty: "10", price: "", fees: "0", date: new Date().toISOString().slice(0, 10), note: "" });

  return (
    <div className="anim-page space-y-4">
      <ScreenHead
        title="Portfolio"
        sub="Manual, local-first transaction book · no brokerage connection"
        right={
          <>
            <Badge tone="brand">{pf.holdings.length} holdings</Badge>
            <Badge tone={pf.totalPnl >= 0 ? "pos" : "neg"}>{fmtSigned(pf.totalPnlPct)}% total</Badge>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <MiniKpi label="Total value" value={fmtCompact(pf.value + pf.cash, "INR")} sub={`${pf.holdings.length} positions`} tone="brand" />
        <MiniKpi label="Day P&L" value={fmtSigned(pf.dayPnl, 0)} sub={`${fmtSigned(pf.dayPnlPct)}%`} tone={pf.dayPnl >= 0 ? "pos" : "neg"} />
        <MiniKpi label="Unrealised" value={fmtCompact(pf.unrealized, "INR")} sub={`${fmtSigned(pf.totalPnlPct)}%`} tone={pf.unrealized >= 0 ? "pos" : "neg"} />
        <MiniKpi label="Realised" value={fmtCompact(pf.realized, "INR")} sub={`Win rate ${pf.winRate.toFixed(0)}%`} tone={pf.realized >= 0 ? "pos" : "neg"} />
      </div>

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <Card>
          <CardHead title="Equity curve" sub="Marked to market, 240 sessions" icon="analytics" />
          <AreaChart data={pf.equity} height={190} baseline={pf.invested} color={pf.totalPnl >= 0 ? "#27A66A" : "#E35D68"} />
          <div className="mt-3 grid grid-cols-2 gap-x-6 gap-y-1.5 border-t border-line pt-3 md:grid-cols-4">
            <Stat k="CAGR" v={`${fmtSigned(pf.cagr)}%`} tone={pf.cagr >= 0 ? "pos" : "neg"} />
            <Stat k="Max drawdown" v={`${pf.mdd.toFixed(1)}%`} tone="neg" />
            <Stat k="Sharpe" v={pf.sharpe.toFixed(2)} />
            <Stat k="Beta" v={pf.beta.toFixed(2)} />
          </div>
        </Card>
        <Card>
          <CardHead title="Country split" sub="India / United States exposure" icon="markets" />
          <Donut items={pf.countryMix} size={124} />
          <div className="mt-4 border-t border-line pt-3">
            <CardHead title="Sector mix" icon="heatmap" />
            <Donut items={pf.sectorMix.slice(0, 5)} size={124} />
          </div>
        </Card>
      </div>

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]">
        <Card>
          <CardHead title="Add transaction" sub="Buys and sells build average cost" icon="plus" />
          <div className="space-y-2.5">
            <div className="grid grid-cols-2 gap-2">
              <Field label="Symbol">
                <Input value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value.toUpperCase() })} className="py-1.5 text-[12.5px]" />
              </Field>
              <Field label="Side">
                <Segmented value={form.side} onChange={(v) => setForm({ ...form, side: v })} options={[{ value: "buy", label: "Buy" }, { value: "sell", label: "Sell" }]} className="w-full" />
              </Field>
              <Field label="Quantity">
                <Input type="number" value={form.qty} onChange={(e) => setForm({ ...form, qty: e.target.value })} className="py-1.5 text-[12.5px]" />
              </Field>
              <Field label="Price">
                <Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder={quote(form.symbol).price.toFixed(2)} className="py-1.5 text-[12.5px]" />
              </Field>
              <Field label="Fees">
                <Input type="number" value={form.fees} onChange={(e) => setForm({ ...form, fees: e.target.value })} className="py-1.5 text-[12.5px]" />
              </Field>
              <Field label="Date">
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="py-1.5 text-[12.5px]" />
              </Field>
            </div>
            <Field label="Note">
              <Input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="Optional reason / tag" className="py-1.5 text-[12.5px]" />
            </Field>
            <PrimaryButton
              className="w-full justify-center"
              onClick={() => {
                const qty = +form.qty;
                const price = +form.price || quote(form.symbol).price;
                if (!qty || !BY_SYMBOL[form.symbol]) return;
                actions.addTransaction({ symbol: form.symbol, side: form.side, qty, price, fees: +form.fees || 0, date: form.date, note: form.note });
                actions.pushToast({ severity: 0, title: `${form.side === "buy" ? "Bought" : "Sold"} ${qty} ${form.symbol}`, body: `Transaction saved locally to your portfolio book.` });
              }}
            >
              <Icon name="check" size={13} /> Save transaction
            </PrimaryButton>
          </div>
        </Card>

        <Card>
          <CardHead title="Holdings" sub="Marked at live prices" icon="portfolio" />
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px]">
              <thead>
                <tr className="border-b border-line text-left text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">
                  <th className="pb-2">Symbol</th>
                  <th className="pb-2 text-right">Qty</th>
                  <th className="pb-2 text-right">Avg</th>
                  <th className="pb-2 text-right">LTP</th>
                  <th className="pb-2 text-right">Value</th>
                  <th className="pb-2 text-right">P&L</th>
                  <th className="pb-2 text-right">Weight</th>
                </tr>
              </thead>
              <tbody>
                {pf.holdings.map((h) => (
                  <tr key={h.symbol} className="border-b border-line/60 last:border-0 hover:bg-subtle">
                    <td className="py-2">
                      <button onClick={() => actions.openSymbol(h.symbol, "detail")} className="text-left">
                        <span className="block text-[12px] font-semibold text-ink">{h.symbol}</span>
                        <span className="block text-[10px] text-ink3">{h.region === "IN" ? "India" : "US"} · {h.sector}</span>
                      </button>
                    </td>
                    <td className="tabnum text-right text-[12px] text-ink2">{h.qty}</td>
                    <td className="tabnum text-right text-[12px] text-ink2">{h.avgPrice.toFixed(2)}</td>
                    <td className="tabnum text-right text-[12px] font-semibold text-ink">{h.price.toFixed(2)}</td>
                    <td className="tabnum text-right text-[12px] text-ink2">{fmtCompact(h.value, h.currency)}</td>
                    <td className={cn("tabnum text-right text-[12px] font-semibold", h.pnl >= 0 ? "text-pos" : "text-neg")}>{fmtSigned(h.pnlPct)}%</td>
                    <td className="text-right">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="h-1.5 w-10 overflow-hidden rounded-full bg-muted">
                          <span className="block h-full rounded-full bg-brand" style={{ width: `${h.weight}%` }} />
                        </span>
                        <span className="tabnum text-[11px] text-ink3">{h.weight.toFixed(0)}%</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      <Card>
        <CardHead title="Transaction history" sub={`${s.transactions.length} records · local storage`} icon="journal" />
        <div className="max-h-[240px] overflow-y-auto">
          <table className="w-full min-w-[520px]">
            <thead>
              <tr className="border-b border-line text-left text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">
                <th className="pb-2">Date</th>
                <th className="pb-2">Symbol</th>
                <th className="pb-2">Side</th>
                <th className="pb-2 text-right">Qty</th>
                <th className="pb-2 text-right">Price</th>
                <th className="pb-2 text-right">Fees</th>
                <th className="pb-2 text-right">Note</th>
                <th className="pb-2" />
              </tr>
            </thead>
            <tbody>
              {s.transactions.map((t) => (
                <tr key={t.id} className="border-b border-line/60 last:border-0">
                  <td className="py-1.5 text-[11.5px] text-ink2">{t.date}</td>
                  <td className="text-[12px] font-semibold text-ink">{t.symbol}</td>
                  <td>
                    <Badge tone={t.side === "buy" ? "pos" : "neg"}>{t.side.toUpperCase()}</Badge>
                  </td>
                  <td className="tabnum text-right text-[12px] text-ink2">{t.qty}</td>
                  <td className="tabnum text-right text-[12px] text-ink2">{t.price.toFixed(2)}</td>
                  <td className="tabnum text-right text-[12px] text-ink2">{t.fees}</td>
                  <td className="text-[11px] text-ink3">{t.note ?? "—"}</td>
                  <td className="text-right">
                    <button onClick={() => actions.removeTransaction(t.id)} className="text-ink3 hover:text-neg" aria-label="Delete">
                      <Icon name="trash" size={12} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function MiniKpi({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: "brand" | "pos" | "neg" }) {
  const tones = { brand: "text-brand", pos: "text-pos", neg: "text-neg" };
  return (
    <Card hover>
      <p className="text-[12px] font-semibold text-ink2">{label}</p>
      <p className="tabnum mt-2 font-display text-[24px] font-extrabold leading-none tracking-[-0.025em] text-ink">{value}</p>
      {sub && <p className={cn("mt-1.5 text-[11px] font-medium", tone && tones[tone])}>{sub}</p>}
    </Card>
  );
}

function Stat({ k, v, tone }: { k: string; v: string; tone?: "pos" | "neg" }) {
  return (
    <div>
      <p className="text-[10.5px] text-ink3">{k}</p>
      <p className={cn("tabnum text-[13px] font-semibold", tone === "pos" ? "text-pos" : tone === "neg" ? "text-neg" : "text-ink")}>{v}</p>
    </div>
  );
}

/* ================================================================== *
 * ANALYTICS
 * ================================================================== */
export function Analytics() {
  useTick();
  const s = useApp();
  const pf = usePortfolio(s.transactions);
  const watchSyms = useMemo(() => (s.watchlists.find((w) => w.id === s.activeWatchlist)?.symbols ?? []).slice(0, 6), [s.watchlists, s.activeWatchlist]);
  const matrix = useCorrelationMatrix(watchSyms.length > 2 ? watchSyms : ["RELIANCE", "TCS", "HDFCBANK", "INFY"], 120);
  const bench = getSeries(INDICES[s.settings.region][0], "1D", 200).map((c) => c.close);
  const rel = pf.equity.map((v, i) => (bench[i] ? ((v / pf.equity[0]) / (bench[i] / bench[0]) - 1) * 100 : 0));

  return (
    <div className="anim-page space-y-4">
      <ScreenHead title="Analytics" sub="Portfolio risk, rolling statistics and attribution" right={<Badge tone="neutral">60+ visual modes in the chart engine</Badge>} />

      <div className="grid gap-3 xl:grid-cols-3">
        <Card>
          <CardHead title="Drawdown" sub="Peak-to-trough, % from equity high" icon="trendDown" />
          <AreaChart data={pf.dd} height={160} color="#E35D68" baseline={0} />
        </Card>
        <Card>
          <CardHead title="Relative performance" sub="Portfolio vs NIFTY 50, rebased" icon="compare" />
          <AreaChart data={rel} height={160} color="#6D72E8" baseline={0} />
        </Card>
        <Card>
          <CardHead title="Monthly returns" sub="Approx 21-session buckets" icon="calendar" />
          <div className="grid grid-cols-6 gap-1.5">
            {pf.monthly.slice(-12).map((m, i) => (
              <div key={i} className="rounded-[10px] p-1.5 text-center" style={{ background: m.ret >= 0 ? `rgba(39,166,106,${Math.min(0.65, 0.12 + Math.abs(m.ret) / 14)})` : `rgba(227,93,104,${Math.min(0.65, 0.12 + Math.abs(m.ret) / 14)})` }}>
                <p className="text-[9.5px] font-semibold text-ink/70">{m.label}</p>
                <p className="tabnum text-[11px] font-bold text-ink">{fmtSigned(m.ret, 1)}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)]">
        <Card>
          <CardHead title="Risk metrics" sub="Rolling 240 sessions" icon="gauge" />
          <div className="space-y-2">
            <Row k="Annualised CAGR" v={`${fmtSigned(pf.cagr)}%`} />
            <Row k="Max drawdown" v={`${pf.mdd.toFixed(2)}%`} />
            <Row k="Sharpe ratio" v={pf.sharpe.toFixed(2)} />
            <Row k="Beta vs NIFTY" v={pf.beta.toFixed(2)} />
            <Row k="Alpha (annual)" v={`${fmtSigned(pf.alpha)}%`} />
            <Row k="Win rate" v={`${pf.winRate.toFixed(0)}%`} />
            <Row k="Cash" v={fmtCompact(pf.cash, "INR")} />
          </div>
        </Card>
        <Card>
          <CardHead title="Top contributors" sub="Contribution to total return" icon="trendUp" />
          <div className="space-y-2">
            {pf.contributions.slice(0, 7).map((c) => (
              <div key={c.symbol} className="flex items-center gap-2">
                <span className="w-[86px] shrink-0 text-[11.5px] font-semibold text-ink2">{c.symbol}</span>
                <span className="relative h-2 flex-1 rounded-full bg-muted">
                  <span
                    className={cn("absolute inset-y-0 rounded-full", c.contribution >= 0 ? "left-1/2 bg-pos" : "right-1/2 bg-neg")}
                    style={{ width: `${Math.min(50, Math.abs(c.contribution) * 2)}%` }}
                  />
                </span>
                <span className={cn("tabnum w-[54px] text-right text-[11px] font-semibold", c.contribution >= 0 ? "text-pos" : "text-neg")}>{fmtSigned(c.contribution)}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHead title="Correlation matrix" sub="Watchlist daily returns, 120d" icon="heatmap" />
          <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${matrix.length + 1}, minmax(0,1fr))` }}>
            <span />
            {watchSyms.map((sym) => (
              <span key={sym} className="truncate text-center text-[9px] font-bold text-ink3">
                {sym.slice(0, 5)}
              </span>
            ))}
            {matrix.map((row, i) => (
              <div key={i} className="contents">
                <span className="truncate pr-1 text-right text-[9px] font-bold text-ink3">{(watchSyms[i] ?? "").slice(0, 5)}</span>
                {row.map((v, j) => (
                  <span key={j} className="tabnum rounded-[8px] py-2 text-center text-[10px] font-bold text-ink" style={{ background: `rgba(128,102,255,${Math.max(0.05, ((v + 1) / 2) * 0.5)})` }}>
                    {v.toFixed(2)}
                  </span>
                ))}
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <CardHead title="Indicator library" sub={`${INDICATOR_CATALOG.length} studies available in the chart engine`} icon="analytics" right={<GhostButton onClick={() => actions.navigate("chart")}>Open pro chart</GhostButton>} />
        <div className="grid gap-x-6 gap-y-1 sm:grid-cols-2 lg:grid-cols-3">
          {["Trend", "Momentum", "Volatility", "Volume", "Breadth", "Portfolio"].map((g) => (
            <div key={g}>
              <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.08em] text-ink3">{g}</p>
              <div className="flex flex-wrap gap-1">
                {INDICATOR_CATALOG.filter((i) => i.group === g).map((i) => (
                  <span key={i.id} className={cn("rounded-full border px-2 py-[3px] text-[10.5px]", s.activeIndicators.includes(i.id) ? "border-transparent bg-brand text-white" : "border-line bg-shell text-ink2")}>
                    {i.name}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between border-b border-line/70 pb-1.5 last:border-0">
      <span className="text-[11.5px] text-ink3">{k}</span>
      <span className="tabnum text-[12px] font-semibold text-ink">{v}</span>
    </div>
  );
}

/* ================================================================== *
 * ALERTS
 * ================================================================== */
const CONDITIONS: { value: AlertCondition; label: string }[] = [
  { value: "price_above", label: "Price crosses above" },
  { value: "price_below", label: "Price crosses below" },
  { value: "price_cross_up", label: "Price crosses up through" },
  { value: "price_cross_down", label: "Price crosses down through" },
  { value: "pct_move", label: "Percentage move exceeds" },
  { value: "rsi_above", label: "RSI above" },
  { value: "rsi_below", label: "RSI below" },
  { value: "volume_above", label: "Relative volume above" },
  { value: "sma_cross", label: "Price crosses SMA 50" },
];

export function Alerts() {
  useTick();
  const s = useApp();
  const [form, setForm] = useState({
    symbol: s.symbol,
    condition: "price_above" as AlertCondition,
    value: "1500",
    frequency: "once" as "once" | "once_per_bar" | "every_cross",
    channels: { inApp: true, browser: true, sound: false },
    message: "",
  });

  return (
    <div className="anim-page space-y-4">
      <ScreenHead title="Alerts" sub="In-app alert engine evaluates while the workstation is open" right={<Badge tone="brand">{s.alerts.filter((a) => a.active).length} live</Badge>} />

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)]">
        <Card>
          <CardHead title="Create alert" sub="Price, technical, volume and market rules" icon="bell" />
          <div className="space-y-2.5">
            <Field label="Symbol">
              <Input value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value.toUpperCase() })} className="py-1.5 text-[12.5px]" />
            </Field>
            <Field label="Condition">
              <Select
                value={form.condition}
                onChange={(v) => setForm({ ...form, condition: v as AlertCondition })}
                options={CONDITIONS.map((c) => ({ value: c.value, label: c.label }))}
              />
            </Field>
            <Field label="Value" hint={form.condition === "pct_move" ? "Percent move" : form.condition.startsWith("rsi") ? "RSI level" : form.condition === "volume_above" ? "Relative volume ×" : `Price in ${BY_SYMBOL[form.symbol]?.currency ?? "INR"}`}>
              <Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} className="py-1.5 text-[12.5px]" />
            </Field>
            <Field label="Frequency">
              <Segmented
                value={form.frequency}
                onChange={(v) => setForm({ ...form, frequency: v })}
                options={[
                  { value: "once", label: "Once" },
                  { value: "once_per_bar", label: "Per bar" },
                  { value: "every_cross", label: "Every cross" },
                ]}
              />
            </Field>
            <div className="rounded-[14px] bg-muted p-2.5">
              <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">Notify</p>
              <Toggle checked={form.channels.inApp} onChange={(v) => setForm({ ...form, channels: { ...form.channels, inApp: v } })} label="In-app toast" />
              <Toggle checked={form.channels.browser} onChange={(v) => setForm({ ...form, channels: { ...form.channels, browser: v } })} label="Browser notification" hint="Requires browser permission" />
              <Toggle checked={form.channels.sound} onChange={(v) => setForm({ ...form, channels: { ...form.channels, sound: v } })} label="Soft chime" hint="Never autoplayed loudly" />
            </div>
            <Field label="Message">
              <Input value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder={`${form.symbol} crossed ${form.value}`} className="py-1.5 text-[12.5px]" />
            </Field>
            <PrimaryButton
              className="w-full justify-center"
              onClick={() => {
                if (!BY_SYMBOL[form.symbol]) return;
                actions.addAlert({
                  symbol: form.symbol,
                  condition: form.condition,
                  value: +form.value,
                  frequency: form.frequency,
                  channels: form.channels,
                  message: form.message || `${form.symbol} ${CONDITIONS.find((c) => c.value === form.condition)?.label} ${form.value}`,
                });
                actions.pushToast({ severity: 0, title: "Alert created", body: `${form.symbol} · ${form.condition.replace(/_/g, " ")} ${form.value}` });
              }}
            >
              <Icon name="check" size={13} /> Create alert
            </PrimaryButton>
          </div>
        </Card>

        <div className="space-y-3">
          <Card>
            <CardHead title="Active rules" sub="Evaluated on every market tick" icon="alerts" />
            {s.alerts.length === 0 ? (
              <EmptyState title="No alerts yet" body="Create your first price or technical rule using the builder." icon="bell" />
            ) : (
              <div className="space-y-1.5">
                {s.alerts.map((a) => (
                  <div key={a.id} className="flex items-start gap-2.5 rounded-[14px] border border-line px-3 py-2">
                    <span className={cn("mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full", a.triggeredAt ? "bg-possoft text-pos" : "bg-brandsoft text-brand")}>
                      <Icon name={a.triggeredAt ? "check" : "bell"} size={13} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-semibold text-ink">{a.message}</p>
                      <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[10.5px] text-ink3">
                        <span className="font-semibold text-brand">{a.symbol}</span>
                        <span>{a.condition.replace(/_/g, " ")} {a.value}</span>
                        <span>· {a.frequency.replace(/_/g, " ")}</span>
                        {a.triggeredAt && <span className="text-pos">· triggered {new Date(a.triggeredAt).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}</span>}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <Pill size="sm" active={a.active} onClick={() => actions.toggleAlert(a.id)}>
                        {a.active ? "On" : "Off"}
                      </Pill>
                      <button onClick={() => actions.removeAlert(a.id)} className="rounded-full p-1 text-ink3 hover:bg-negsoft hover:text-neg" aria-label="Delete alert">
                        <Icon name="trash" size={12} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card>
            <CardHead title="Notification history" sub="Price · technical · market · earnings · system" icon="clock" right={<GhostButton onClick={actions.markAllRead}>Mark all read</GhostButton>} />
            <div className="max-h-[260px] space-y-1 overflow-y-auto">
              {s.notifications.map((n) => (
                <div key={n.id} className="flex items-start gap-2.5 rounded-[13px] px-2 py-1.5 hover:bg-muted">
                  <span className={cn("mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full", n.severity === 3 ? "bg-negsoft text-neg" : n.severity === 2 ? "bg-warnsoft text-warn" : n.severity === 1 ? "bg-infosoft text-info" : "bg-muted text-ink2")}>
                    <Icon name={n.severity >= 2 ? "warning" : n.severity === 1 ? "bell" : "info"} size={11} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12px] font-semibold text-ink">{n.title}</p>
                    <p className="truncate text-[10.5px] text-ink3">{n.body}</p>
                  </div>
                  <span className="shrink-0 text-[10px] text-ink3">{new Date(n.ts).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== *
 * JOURNAL
 * ================================================================== */
export function Journal() {
  const s = useApp();
  const [form, setForm] = useState({ symbol: s.symbol, thesis: "", notes: "", tags: "", mood: "calm" as "calm" | "confident" | "uncertain" | "regretful" });

  return (
    <div className="anim-page space-y-4">
      <ScreenHead title="Journal" sub="Thesis, reviews and mistakes · stored locally, never uploaded" />
      <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
        <Card>
          <CardHead title="New entry" icon="journal" />
          <div className="space-y-2.5">
            <div className="grid grid-cols-2 gap-2">
              <Field label="Symbol">
                <Input value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value.toUpperCase() })} className="py-1.5 text-[12.5px]" />
              </Field>
              <Field label="Conviction">
                <Select value={form.mood} onChange={(v) => setForm({ ...form, mood: v as typeof form.mood })} options={[
                  { value: "calm", label: "Calm" },
                  { value: "confident", label: "Confident" },
                  { value: "uncertain", label: "Uncertain" },
                  { value: "regretful", label: "Review needed" },
                ]} />
              </Field>
            </div>
            <Field label="Thesis">
              <Input value={form.thesis} onChange={(e) => setForm({ ...form, thesis: e.target.value })} placeholder="Why this trade / position" className="py-1.5 text-[12.5px]" />
            </Field>
            <Field label="Notes & review">
              <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="h-20 w-full resize-none rounded-[14px] border border-line bg-shell p-2.5 text-[12.5px] outline-none focus:border-brand" placeholder="Levels, invalidation, mistakes to avoid" />
            </Field>
            <Field label="Tags">
              <Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="core, swing, earnings" className="py-1.5 text-[12.5px]" />
            </Field>
            <PrimaryButton
              className="w-full justify-center"
              onClick={() => {
                if (!form.thesis.trim()) return;
                actions.addJournal({ symbol: form.symbol, thesis: form.thesis, notes: form.notes, tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean), mood: form.mood });
                setForm({ ...form, thesis: "", notes: "", tags: "" });
                actions.pushToast({ severity: 0, title: "Journal entry saved", body: `${form.symbol} · ${form.thesis.slice(0, 48)}` });
              }}
            >
              <Icon name="check" size={13} /> Save entry
            </PrimaryButton>
          </div>
        </Card>

        <Card>
          <CardHead title="Entries" sub={`${s.journal.length} saved`} icon="book" />
          <div className="space-y-2">
            {s.journal.length === 0 && <EmptyState title="No entries yet" body="Document the reasoning behind each position so future-you can review it." icon="journal" />}
            {s.journal.map((j) => (
              <div key={j.id} className="rounded-[14px] border border-line p-3">
                <div className="mb-1.5 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button onClick={() => actions.openSymbol(j.symbol, "detail")} className="text-[12.5px] font-bold text-ink hover:text-brand">
                      {j.symbol}
                    </button>
                    <Badge tone={j.mood === "confident" ? "pos" : j.mood === "regretful" ? "neg" : j.mood === "uncertain" ? "warn" : "info"}>{j.mood}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10.5px] text-ink3">{new Date(j.ts).toLocaleDateString("en-US", { day: "2-digit", month: "short" })}</span>
                    <button onClick={() => actions.removeJournal(j.id)} className="text-ink3 hover:text-neg" aria-label="Delete">
                      <Icon name="trash" size={12} />
                    </button>
                  </div>
                </div>
                <p className="text-[12px] leading-relaxed text-ink2">{j.thesis}</p>
                {j.notes && <p className="mt-1.5 border-l-2 border-brand/40 pl-2 text-[11.5px] leading-relaxed text-ink3">{j.notes}</p>}
                <div className="mt-2 flex flex-wrap gap-1">
                  {j.tags.map((t) => (
                    <span key={t} className="rounded-full bg-muted px-2 py-[2px] text-[10px] font-medium text-ink2">
                      #{t}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ================================================================== *
 * CALENDAR
 * ================================================================== */
export function CalendarScreen() {
  useTick();
  const s = useApp();
  const region = s.settings.region;
  const universe = region === "IN" ? ["RELIANCE", "TCS", "INFY", "HDFCBANK", "ICICIBANK", "SBIN", "ITC", "LT"] : ["AAPL", "MSFT", "NVDA", "AMZN", "META", "JPM"];
  const now = new Date();
  const first = new Date(now.getFullYear(), now.getMonth(), 1);
  const days = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const offset = first.getDay();

  return (
    <div className="anim-page space-y-4">
      <ScreenHead
        title="Calendar"
        sub="Earnings, ex-dividend and macro events"
        right={
          <Segmented
            value={region}
            onChange={(r) => actions.setSettings({ region: r })}
            options={[
              { value: "IN", label: "India" },
              { value: "US", label: "USA" },
            ]}
          />
        }
      />
      <Card>
        <CardHead title={now.toLocaleDateString("en-US", { month: "long", year: "numeric" })} sub="Weekends shaded · event density indicated by tile tint" icon="calendar" />
        <div className="grid grid-cols-7 gap-1.5">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <span key={d} className="pb-1 text-center text-[10px] font-bold uppercase tracking-[0.06em] text-ink3">
              {d}
            </span>
          ))}
          {Array.from({ length: offset }).map((_, i) => (
            <span key={`pad${i}`} />
          ))}
          {Array.from({ length: days }).map((_, i) => {
            const day = i + 1;
            const date = new Date(now.getFullYear(), now.getMonth(), day);
            const weekend = date.getDay() === 0 || date.getDay() === 6;
            const events = universe.filter((sym) => (day + sym.length) % 9 === 0);
            return (
              <div key={day} className={cn("min-h-[74px] rounded-[13px] border p-1.5", weekend ? "border-line bg-muted" : "border-line bg-shell")}>
                <p className={cn("tabnum text-[11px] font-bold", day === now.getDate() ? "text-brand" : "text-ink2")}>{day}</p>
                <div className="mt-1 space-y-0.5">
                  {events.slice(0, 2).map((sym) => (
                    <button key={sym} onClick={() => actions.openSymbol(sym, "detail")} className="block w-full truncate rounded-[6px] bg-brandsoft px-1 py-[2px] text-left text-[9.5px] font-semibold text-brand">
                      {sym}
                    </button>
                  ))}
                  {events.length > 2 && <span className="text-[9px] text-ink3">+{events.length - 2} more</span>}
                </div>
              </div>
            );
          })}
        </div>
      </Card>
      <div className="grid gap-3 lg:grid-cols-3">
        <Card>
          <CardHead title="This week" icon="clock" />
          <div className="space-y-1.5">
            {universe.slice(0, 5).map((sym) => (
              <div key={sym} className="flex items-center justify-between rounded-[12px] bg-muted px-2.5 py-1.5">
                <span className="text-[12px] font-semibold text-ink">{sym}</span>
                <span className="text-[10.5px] text-ink3">Results {(1 + (sym.length % 4))}d</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHead title="Dividend watch" icon="download" />
          <div className="space-y-1.5">
            {universe.slice(2, 7).map((sym) => (
              <Row key={sym} k={sym} v={`${(BY_SYMBOL[sym]?.divYield ?? 0).toFixed(2)}% yield`} />
            ))}
          </div>
        </Card>
        <Card>
          <CardHead title="Session state" icon="markets" />
          <div className="space-y-1.5">
            <Row k="India" v={session("IN").label} />
            <Row k="United States" v={session("US").label} />
            <Row k="IST clock" v={session("IN").tz.label} />
            <Row k="ET clock" v={session("US").tz.label} />
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ================================================================== *
 * DATA SOURCES
 * ================================================================== */
const PROVIDERS = [
  { id: "fyers", label: "FYERS API", region: "IN" as Region, kind: "Quotes · historical · WebSocket", secret: true, status: "Not connected" },
  { id: "upstox", label: "Upstox API", region: "IN" as Region, kind: "Quotes · historical", secret: true, status: "Optional alternative" },
  { id: "alpaca", label: "Alpaca Market Data", region: "US" as Region, kind: "IEX quotes · bars", secret: true, status: "Not connected" },
  { id: "edgar", label: "SEC EDGAR", region: "US" as Region, kind: "Filings · fundamentals", secret: false, status: "Public, keyless" },
  { id: "mock", label: "Mock Market Provider", region: "IN" as Region, kind: "Deterministic demo generator", secret: false, status: "Active" },
];

export function DataSources() {
  useTick();
  const s = useApp();
  return (
    <div className="anim-page space-y-4">
      <ScreenHead title="Data sources" sub="Adapters are swappable — the UI never depends on one vendor" right={<Badge tone={s.connected ? "pos" : "neg"}>{s.connected ? "Adapter healthy" : "Disconnected"}</Badge>} />

      <div className="grid gap-3 lg:grid-cols-2 xl:grid-cols-3">
        {PROVIDERS.map((p) => (
          <Card key={p.id} hover>
            <CardHead
              title={p.label}
              sub={p.kind}
              icon="database"
              right={<Badge tone={p.status === "Active" ? "pos" : p.status === "Public, keyless" ? "info" : "neutral"}>{p.status}</Badge>}
            />
            <div className="space-y-1.5">
              <Row k="Market" v={p.region === "IN" ? "India · NSE / BSE" : "United States"} />
              <Row k="Auth" v={p.secret ? "Server-side proxy required" : "No secret needed"} />
              <Row k="Transport" v={p.id === "mock" ? "Local generator" : "REST + WebSocket"} />
            </div>
            <div className="mt-3 flex items-center gap-1.5">
              <Pill size="sm" active={s.settings.dataMode === "mock" && p.id === "mock"} onClick={() => actions.setSettings({ dataMode: p.id === "mock" ? "mock" : "live" })}>
                {p.id === "mock" ? "Demo mode" : "Connect"}
              </Pill>
              <Pill size="sm" onClick={() => actions.pushToast({ severity: 1, title: `${p.label} health check`, body: "Adapter contract is implemented against the normalised MarketDataProvider interface." })}>
                Test
              </Pill>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <Card>
          <CardHead title="Provider interface" sub="Every adapter implements this contract" icon="layers" />
          <pre className="overflow-x-auto rounded-[14px] bg-[#18171C] p-3 text-[10.5px] leading-relaxed text-[#E8E6EC]">
{`interface MarketDataProvider {
  searchSymbols(q: string): Promise<Instrument[]>;
  getQuote(symbol: string): Promise<Quote>;
  getCandles(p: CandleRequest): Promise<Candle[]>;
  subscribeQuotes(symbols: string[],
    cb: QuoteHandler): Unsubscribe;
}`}
          </pre>
          <p className="mt-2 text-[10.5px] leading-relaxed text-ink3">
            Quotes are normalised to a single shape (symbol, exchange, currency, price, change, OHLC, volume, timestamp) so screens stay provider-agnostic.
          </p>
        </Card>
        <Card>
          <CardHead title="Runtime mode" sub="Frontend-first development" icon="settings" />
          <div className="space-y-2">
            <Segmented
              value={s.settings.dataMode}
              onChange={(v) => actions.setSettings({ dataMode: v })}
              options={[
                { value: "mock", label: "Demo / mock" },
                { value: "live", label: "Live provider" },
              ]}
            />
            <Row k="NEXT_PUBLIC_DATA_MODE" v={s.settings.dataMode} />
            <Row k="Secrets in bundle" v={s.settings.dataMode === "mock" ? "None" : "Proxied via serverless routes"} />
            <Row k="Cache" v="IndexedDB (Dexie) · candles + quotes" />
            <Row k="Rate limiting" v="Personal proxy, exponential backoff" />
            <div className="mt-2 rounded-[14px] bg-warnsoft p-2.5 text-[11px] leading-relaxed text-ink2">
              Never place FYERS / Alpaca secrets in <code className="font-semibold">NEXT_PUBLIC_</code> variables. Private keys are read only inside serverless functions and proxied to the browser.
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              <Pill
                size="sm"
                onClick={() => {
                  actions.setConnected(false);
                  actions.pushToast({ severity: 2, title: "Feed disconnected", body: "Cached market data is shown. Reconnect or continue in demo mode." });
                }}
              >
                Simulate disconnect
              </Pill>
              <Pill
                size="sm"
                active={s.connected}
                onClick={() => {
                  actions.setConnected(true);
                  actions.pushToast({ severity: 0, title: "Feed reconnected", body: "Live ticks resumed for the active adapter." });
                }}
              >
                Reconnect
              </Pill>
            </div>
          </div>
        </Card>
      </div>

      {!s.connected && (
        <Card className="border-neg/50 bg-negsoft/40">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-[13px] font-bold text-ink">Market data unavailable</p>
              <p className="text-[11.5px] text-ink2">Reconnect your data provider or continue in demo mode. Cached values are displayed with a delay flag.</p>
            </div>
            <div className="flex gap-1.5">
              <Pill size="sm" onClick={() => actions.setConnected(true)}>
                Retry
              </Pill>
              <Pill size="sm" onClick={() => actions.navigate("data")}>
                Open data sources
              </Pill>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

/* ================================================================== *
 * SETTINGS
 * ================================================================== */
export function SettingsScreen() {
  const s = useApp();
  const mood = marketMood(s.settings.region);
  return (
    <div className="anim-page space-y-4">
      <ScreenHead title="Settings" sub="Everything is stored locally on this device · nothing leaves the browser" />
      <div className="grid gap-3 lg:grid-cols-2 xl:grid-cols-3">
        <Card>
          <CardHead title="Appearance & motion" icon="sun" />
          <div className="space-y-2">
            <Field label="Density">
              <Segmented value={s.settings.density} onChange={(v) => actions.setSettings({ density: v })} options={[{ value: "compact", label: "Compact" }, { value: "comfortable", label: "Comfortable" }]} />
            </Field>
            <Field label="Motion" hint="Respects prefers-reduced-motion too">
              <Segmented value={s.settings.motion} onChange={(v) => actions.setSettings({ motion: v })} options={[{ value: "full", label: "Full" }, { value: "reduced", label: "Reduced" }, { value: "off", label: "Off" }]} />
            </Field>
            <Field label="Anime companion">
              <Segmented value={s.settings.anime} onChange={(v) => actions.setSettings({ anime: v })} options={[{ value: "full", label: "Full" }, { value: "minimal", label: "Minimal" }, { value: "off", label: "Off" }]} />
            </Field>
            <Toggle checked={s.settings.sidebarCollapsed} onChange={(v) => actions.setSettings({ sidebarCollapsed: v })} label="Collapse sidebar" />
            <Toggle checked={s.settings.watchlistPanelOpen} onChange={(v) => actions.setSettings({ watchlistPanelOpen: v })} label="Chart watchlist rail" />
          </div>
        </Card>

        <Card>
          <CardHead title="Chart defaults" icon="chart" />
          <div className="space-y-2">
            <Toggle checked={s.settings.showVolume} onChange={(v) => actions.setSettings({ showVolume: v })} label="Volume histogram" hint="Rendered under the price pane" />
            <Toggle checked={s.settings.logScale} onChange={(v) => actions.setSettings({ logScale: v })} label="Logarithmic scale" />
            <Toggle checked={s.settings.autoScale} onChange={(v) => actions.setSettings({ autoScale: v })} label="Auto scale" />
            <Field label="Default studies" hint={`${s.activeIndicators.length} active`}>
              <div className="flex flex-wrap gap-1">
                {INDICATOR_CATALOG.slice(0, 18).map((i) => (
                  <Pill key={i.id} size="sm" active={s.activeIndicators.includes(i.id)} onClick={() => actions.toggleIndicator(i.id)}>
                    {i.name}
                  </Pill>
                ))}
              </div>
            </Field>
          </div>
        </Card>

        <Card>
          <CardHead title="Alerts & companion thresholds" icon="bell" />
          <div className="space-y-3">
            <label className="block">
              <span className="mb-1 flex items-center justify-between text-[11.5px]">
                <span className="font-medium text-ink2">Crash index threshold</span>
                <span className="tabnum font-semibold text-neg">{s.settings.crashIndexThreshold}%</span>
              </span>
              <input type="range" min={-8} max={-1} step={0.5} value={s.settings.crashIndexThreshold} onChange={(e) => actions.setSettings({ crashIndexThreshold: +e.target.value })} className="w-full accent-[#E35D68]" />
            </label>
            <label className="block">
              <span className="mb-1 flex items-center justify-between text-[11.5px]">
                <span className="font-medium text-ink2">Crash single-stock threshold</span>
                <span className="tabnum font-semibold text-neg">{s.settings.crashStockThreshold}%</span>
              </span>
              <input type="range" min={-12} max={-2} step={0.5} value={s.settings.crashStockThreshold} onChange={(e) => actions.setSettings({ crashStockThreshold: +e.target.value })} className="w-full accent-[#E35D68]" />
            </label>
            <Toggle checked={s.settings.sound} onChange={(v) => actions.setSettings({ sound: v })} label="Alert chime" hint="Soft, never autoplayed loudly" />
            <Toggle checked={s.settings.browserNotify} onChange={(v) => actions.setSettings({ browserNotify: v })} label="Browser notifications" />
          </div>
        </Card>
      </div>

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
        <Card>
          <CardHead title="Companion preview" sub="All reaction states" icon="spark" />
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {(["neutral", "mildBull", "strongBull", "breakout", "mildBear", "strongBear", "crash", "rally", "closed", "disconnected"] as const).map((st) => (
              <div key={st} className="rounded-[13px] border border-line p-1.5 text-center">
                <CompanionMini state={st} />
                <p className="mt-1 text-[9.5px] font-semibold text-ink3">{st.replace(/([A-Z])/g, " $1")}</p>
              </div>
            ))}
          </div>
        </Card>
        <div className="space-y-3">
          <Card>
            <CardHead title="Local data" sub="Watchlists, notes, drawings, journal, transactions" icon="database" />
            <div className="space-y-2">
              <Row k="Watchlists" v={`${s.watchlists.length}`} />
              <Row k="Alerts" v={`${s.alerts.length}`} />
              <Row k="Journal entries" v={`${s.journal.length}`} />
              <Row k="Transactions" v={`${s.transactions.length}`} />
              <Row k="Chart objects" v={`${Object.values(s.drawings).reduce((a, b) => a + b.length, 0)}`} />
              <Row k="Current mood score" v={`${mood} · ${moodLabel(mood).label}`} />
              <div className="flex flex-wrap gap-1.5 pt-1">
                <Pill
                  size="sm"
                  onClick={() => {
                    localStorage.removeItem("aerrik.v1");
                    actions.pushToast({ severity: 1, title: "Local data cleared", body: "Reload the page to restore defaults." });
                  }}
                >
                  Clear local storage
                </Pill>
                <Pill size="sm" onClick={() => actions.navigate("overview")}>
                  Back to overview
                </Pill>
              </div>
            </div>
          </Card>
          <Card>
            <CardHead title="Keyboard shortcuts" icon="command" />
            <div className="grid grid-cols-2 gap-x-6">
              {[
                ["⌘ / Ctrl + K", "Global search"],
                ["/", "Search"],
                ["F", "Fullscreen chart"],
                ["I", "Indicators"],
                ["D", "Drawing tools"],
                ["W", "Watchlists"],
                ["1 / 2 / 3 / 4 / 5", "1m · 5m · 15m · 1H · 1D"],
                ["Esc", "Close modal / tool"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between border-b border-line/70 py-1.5 last:border-0">
                  <span className="text-[11.5px] text-ink3">{v}</span>
                  <kbd className="rounded-md border border-line bg-muted px-1.5 py-[1px] text-[10px] font-semibold text-ink2">{k}</kbd>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      <Card className="bg-subtle">
        <p className="text-[11px] leading-relaxed text-ink3">
          <strong className="font-semibold text-ink2">Disclaimer.</strong> AERRIK MARKET OS is a personal research and charting workstation. All data shown in demo mode is synthetically generated for
          interface development. Nothing here is investment advice, no signal guarantees profit, and no order execution is performed. Market-data display must comply with each provider's terms.
        </p>
      </Card>
    </div>
  );
}

function CompanionMini({ state }: { state: Parameters<typeof CompanionCard>[0]["state"] }) {
  return (
    <div className="flex justify-center overflow-hidden rounded-[11px] bg-subtle">
      <CompanionCard state={state} score={50} minimized />
    </div>
  );
}
