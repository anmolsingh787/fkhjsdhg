import React from "react";
import { cn } from "../../utils/cn";

/* ------------------------------------------------------------------ *
 * Icons — original 24px stroke set
 * ------------------------------------------------------------------ */
const P: Record<string, string> = {
  overview: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z",
  markets: "M3 17l5-6 4 3 4-6 5 5M3 21h18",
  chart: "M7 4v4M7 12v8M12 4v8M12 16v4M17 4v6M17 14v6M5 8h4M10 12h4M15 10h4",
  watchlist: "M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9L3.5 9.7l5.9-.8z",
  screener: "M4 5h16M7 12h10M10 19h4",
  heatmap: "M4 4h7v7H4zM13 4h7v4h-7zM13 10h7v10h-7zM4 13h7v7H4z",
  compare: "M6 4v12M6 20h.01M18 4v12M18 20h.01M6 8h12M6 16h12",
  portfolio: "M4 8h16v12H4zM9 8V6a3 3 0 013-3 3 3 0 013 3v2M4 13h16",
  analytics: "M4 19h16M7 16v-4M12 16V7M17 16v-6",
  alerts: "M12 4a5 5 0 015 5v4l2 3H5l2-3V9a5 5 0 015-5zM10 19a2 2 0 004 0",
  journal: "M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3zM8 9h7M8 13h7",
  calendar: "M4 6h16v14H4zM8 3v4M16 3v4M4 11h16",
  database: "M12 3c4.4 0 8 1.3 8 3s-3.6 3-8 3-8-1.3-8-3 3.6-3 8-3zM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3",
  settings: "M12 15.5a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-2.9 1.2v.2a2 2 0 11-4 0v-.1a1.7 1.7 0 00-2.9-1.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1A1.7 1.7 0 003.5 15a2 2 0 010-4h.2a1.7 1.7 0 001.2-2.9l-.1-.1a2 2 0 112.8-2.8l.1.1A1.7 1.7 0 0011 4.5V4a2 2 0 014 0v.2a1.7 1.7 0 002.9 1.2l.1-.1a2 2 0 112.8 2.8l-.1.1A1.7 1.7 0 0020.5 11h.2a2 2 0 010 4z",
  search: "M11 18a7 7 0 100-14 7 7 0 000 14zM20 20l-4-4",
  plus: "M12 5v14M5 12h14",
  close: "M6 6l12 12M18 6L6 18",
  chevronDown: "M6 9l6 6 6-6",
  chevronRight: "M9 6l6 6-6 6",
  chevronLeft: "M15 6l-6 6 6 6",
  chevronsLeft: "M11 7l-5 5 5 5M18 7l-5 5 5 5",
  arrowUp: "M12 19V5M6 11l6-6 6 6",
  arrowDown: "M12 5v14M6 13l6 6 6-6",
  arrowUpRight: "M7 17L17 7M9 7h8v8",
  star: "M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9L3.5 9.7l5.9-.8z",
  bell: "M12 4a5 5 0 015 5v4l2 3H5l2-3V9a5 5 0 015-5zM10 19a2 2 0 004 0",
  camera: "M4 8h3l1.5-2h7L17 8h3v11H4zM12 16.5a3.5 3.5 0 100-7 3.5 3.5 0 000 7z",
  expand: "M4 9V4h5M20 15v5h-5M20 9V4h-5M4 15v5h5",
  layers: "M12 3l8 4.5-8 4.5-8-4.5zM4 12l8 4.5 8-4.5M4 16.5L12 21l8-4.5",
  play: "M8 5l11 7-11 7z",
  trash: "M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13M10 11v6M14 11v6",
  lock: "M6 11h12v9H6zM9 11V8a3 3 0 016 0v3",
  eye: "M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6zM12 15a3 3 0 100-6 3 3 0 000 6z",
  eyeOff: "M4 4l16 16M10 6.2A9.9 9.9 0 0112 6c6.5 0 10 6 10 6a17 17 0 01-3 3.6M6.5 8.4A16 16 0 002 12s3.5 6 10 6a9.6 9.6 0 003.4-.6",
  grip: "M9 6h.01M9 12h.01M9 18h.01M15 6h.01M15 12h.01M15 18h.01",
  info: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 11v5M12 8h.01",
  warning: "M12 4l9 16H3zM12 10v4M12 17h.01",
  zap: "M13 3L5 14h5l-1 7 8-11h-5z",
  gauge: "M12 20a8 8 0 110-16 8 8 0 010 16zM12 12l4-4",
  refresh: "M20 12a8 8 0 10-2.6 5.9M20 19v-5h-5",
  plug: "M9 3v5M15 3v5M6 8h12v3a6 6 0 01-6 6 6 6 0 01-6-6zM12 17v4",
  check: "M5 13l4 4L19 7",
  filter: "M4 5h16l-6 7v6l-4-2v-4z",
  download: "M12 4v10M8 11l4 4 4-4M5 19h14",
  sliders: "M4 8h10M18 8h2M4 16h4M12 16h8M14 5v6M8 13v6",
  book: "M4 5a2 2 0 012-2h13v18H6a2 2 0 01-2-2zM9 3v18",
  tag: "M4 12l8-8h8v8l-8 8zM16 8h.01",
  clock: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2",
  flame: "M12 3s5 4 5 9a5 5 0 01-10 0c0-2 1-3 1-3s0 3 2 3 1-4 2-9z",
  trendUp: "M3 17l6-6 4 4 8-8M15 7h6v6",
  trendDown: "M3 7l6 6 4-4 8 8M15 17h6v-6",
  wave: "M3 12c2-5 4 5 6 0s4 5 6 0 4 5 6 0",
  sun: "M12 17a5 5 0 100-10 5 5 0 000 10zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19",
  command: "M9 3a3 3 0 013 3v12a3 3 0 11-3-3h6a3 3 0 113-3V6a3 3 0 11-3 3",
};

export function Icon({
  name,
  size = 16,
  className,
  strokeWidth = 1.7,
}: {
  name: keyof typeof P | string;
  size?: number;
  className?: string;
  strokeWidth?: number;
}) {
  const d = P[name] ?? P.info;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      <path d={d} />
    </svg>
  );
}

/* ------------------------------------------------------------------ *
 * Surfaces
 * ------------------------------------------------------------------ */
export function Card({
  className,
  children,
  pad = true,
  hover = false,
  ...rest
}: React.HTMLAttributes<HTMLDivElement> & { pad?: boolean; hover?: boolean }) {
  return (
    <div
      className={cn(
        "rounded-[20px] border border-line bg-shell shadow-[var(--shadow-soft)]",
        pad && "p-4",
        hover && "card-hover",
        className,
      )}
      {...rest}
    >
      {children}
    </div>
  );
}

export function CardHead({
  title,
  sub,
  right,
  icon,
  className,
}: {
  title: string;
  sub?: string;
  right?: React.ReactNode;
  icon?: string;
  className?: string;
}) {
  return (
    <div className={cn("mb-3 flex items-start justify-between gap-3", className)}>
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          {icon && (
            <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-brandsoft text-brand">
              <Icon name={icon} size={13} />
            </span>
          )}
          <h3 className="truncate text-[13.5px] font-semibold tracking-[-0.01em] text-ink">{title}</h3>
        </div>
        {sub && <p className="mt-0.5 truncate text-[11.5px] text-ink3">{sub}</p>}
      </div>
      {right && <div className="flex shrink-0 items-center gap-1.5">{right}</div>}
    </div>
  );
}

export function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-end justify-between">
      <h2 className="font-display text-[17px] font-bold tracking-[-0.02em] text-ink">{children}</h2>
      {right}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Controls
 * ------------------------------------------------------------------ */
export function Pill({
  active,
  children,
  className,
  size = "md",
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean; size?: "sm" | "md" }) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium transition-all duration-150",
        size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-[12px]",
        active
          ? "border-transparent bg-brand text-white shadow-[0_2px_10px_rgba(128,102,255,0.28)]"
          : "border-line bg-shell text-ink2 hover:border-line2 hover:text-ink",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  className,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-line bg-shell px-3 py-1.5 text-[12px] font-medium text-ink2 transition-all hover:border-line2 hover:text-ink",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

export function PrimaryButton({
  children,
  className,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full bg-brand px-3.5 py-1.5 text-[12px] font-semibold text-white shadow-[0_2px_12px_rgba(128,102,255,0.3)] transition-all hover:bg-brandhover",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

export function IconButton({
  name,
  label,
  active,
  badge,
  className,
  size = 16,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  name: string;
  label: string;
  active?: boolean;
  badge?: number;
  size?: number;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      className={cn(
        "relative flex h-9 w-9 items-center justify-center rounded-full border transition-all",
        active ? "border-transparent bg-brandsoft text-brand" : "border-line bg-shell text-ink2 hover:border-line2 hover:text-ink",
        className,
      )}
      {...rest}
    >
      <Icon name={name} size={size} />
      {!!badge && (
        <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-neg px-1 text-[9px] font-bold text-white">
          {badge > 9 ? "9+" : badge}
        </span>
      )}
    </button>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className,
  size = "md",
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
  size?: "sm" | "md";
}) {
  return (
    <div className={cn("inline-flex items-center gap-0.5 rounded-full border border-line bg-muted p-0.5", className)}>
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "rounded-full font-medium transition-all duration-150",
            size === "sm" ? "px-2.5 py-[3px] text-[11px]" : "px-3 py-1 text-[11.5px]",
            value === o.value ? "bg-shell text-ink shadow-[0_1px_4px_rgba(20,18,30,0.08)]" : "text-ink3 hover:text-ink2",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Select({
  value,
  onChange,
  options,
  className,
  label,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  className?: string;
  label?: string;
}) {
  return (
    <div className={cn("relative", className)}>
      <select
        aria-label={label}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full appearance-none rounded-[14px] border border-line bg-shell py-1.5 pl-3 pr-7 text-[12px] font-medium text-ink2 outline-none transition-colors hover:border-line2"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      <Icon name="chevronDown" size={13} className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-ink3" />
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  hint,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  hint?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-4 rounded-[14px] px-1 py-2 text-left"
      aria-pressed={checked}
    >
      <span>
        <span className="block text-[12.5px] font-medium text-ink">{label}</span>
        {hint && <span className="block text-[11px] text-ink3">{hint}</span>}
      </span>
      <span
        className={cn(
          "relative h-[20px] w-[36px] shrink-0 rounded-full transition-colors",
          checked ? "bg-brand" : "bg-line2",
        )}
      >
        <span
          className={cn(
            "absolute top-[2px] h-4 w-4 rounded-full bg-white shadow transition-all",
            checked ? "left-[18px]" : "left-[2px]",
          )}
        />
      </span>
    </button>
  );
}

/* ------------------------------------------------------------------ *
 * Data display
 * ------------------------------------------------------------------ */
export function Delta({
  value,
  size = "sm",
  showAbs,
  abs,
  className,
  arrow = true,
}: {
  value: number;
  size?: "xs" | "sm" | "md";
  showAbs?: boolean;
  abs?: number;
  className?: string;
  arrow?: boolean;
}) {
  const pos = value >= 0;
  const tones = pos
    ? "bg-possoft text-pos"
    : "bg-negsoft text-neg";
  const sizes = { xs: "text-[10px] px-1.5 py-[1px] gap-0.5", sm: "text-[11.5px] px-2 py-[3px] gap-1", md: "text-[13px] px-2.5 py-1 gap-1" };
  return (
    <span
      className={cn(
        "tabnum inline-flex items-center rounded-full font-semibold",
        tones,
        sizes[size],
        className,
      )}
    >
      {arrow && (
        <svg width="9" height="9" viewBox="0 0 10 10" fill="none" aria-hidden>
          <path d={pos ? "M5 1.5L9 8H1z" : "M5 8.5L1 2h8z"} fill="currentColor" />
        </svg>
      )}
      {pos ? "+" : "−"}
      {Math.abs(value).toFixed(2)}%
      {showAbs && abs !== undefined && <span className="opacity-70">({pos ? "+" : "−"}{Math.abs(abs).toFixed(2)})</span>}
    </span>
  );
}

export function Sparkline({
  data,
  width = 96,
  height = 30,
  positive,
  className,
  strokeWidth = 1.6,
  fill = true,
}: {
  data: number[];
  width?: number;
  height?: number;
  positive?: boolean;
  className?: string;
  strokeWidth?: number;
  fill?: boolean;
}) {
  if (data.length < 2) return <svg width={width} height={height} className={className} />;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const step = width / (data.length - 1);
  const pts = data.map((v, i) => [i * step, height - 2 - ((v - min) / span) * (height - 4)] as const);
  const d = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const up = positive ?? data[data.length - 1] >= data[0];
  const color = up ? "#27A66A" : "#E35D68";
  const id = `sp${Math.round(min * 1000)}${data.length}${up ? "u" : "d"}`;
  return (
    <svg width={width} height={height} className={className} aria-hidden>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {fill && <path d={`${d} L${width},${height} L0,${height} Z`} fill={`url(#${id})`} />}
      <path d={d} fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Badge({
  children,
  tone = "brand",
  className,
}: {
  children: React.ReactNode;
  tone?: "brand" | "pos" | "neg" | "warn" | "info" | "neutral";
  className?: string;
}) {
  const tones: Record<string, string> = {
    brand: "bg-brandsoft text-brand",
    pos: "bg-possoft text-pos",
    neg: "bg-negsoft text-neg",
    warn: "bg-warnsoft text-warn",
    info: "bg-infosoft text-info",
    neutral: "bg-muted text-ink2",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-[3px] text-[10.5px] font-semibold", tones[tone], className)}>
      {children}
    </span>
  );
}

export function KV({ k, v, tone }: { k: string; v: React.ReactNode; tone?: "pos" | "neg" }) {
  return (
    <div className="flex items-center justify-between gap-2 border-b border-line/70 py-[7px] last:border-0">
      <span className="text-[11.5px] text-ink3">{k}</span>
      <span className={cn("tabnum text-[12px] font-semibold text-ink", tone === "pos" && "text-pos", tone === "neg" && "text-neg")}>{v}</span>
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} />;
}

export function EmptyState({
  icon = "info",
  title,
  body,
  action,
}: {
  icon?: string;
  title: string;
  body?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-[16px] border border-dashed border-line bg-subtle px-6 py-10 text-center">
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brandsoft text-brand">
        <Icon name={icon} size={18} />
      </span>
      <p className="text-[13px] font-semibold text-ink">{title}</p>
      {body && <p className="max-w-[320px] text-[11.5px] leading-relaxed text-ink3">{body}</p>}
      {action}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
  width = "max-w-lg",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  width?: string;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-[8vh]" role="dialog" aria-modal>
      <div className="anim-fade absolute inset-0 bg-[#1a1726]/25 backdrop-blur-[2px]" onClick={onClose} />
      <div className={cn("anim-pop relative w-full rounded-[22px] border border-line bg-shell p-5 shadow-[0_24px_80px_rgba(28,24,54,0.18)]", width)}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-[16px] font-bold tracking-[-0.02em] text-ink">{title}</h3>
          <IconButton name="close" label="Close" onClick={onClose} className="h-8 w-8" size={15} />
        </div>
        <div className="max-h-[70vh] overflow-y-auto pr-1">{children}</div>
      </div>
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-semibold uppercase tracking-[0.06em] text-ink3">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-ink3">{hint}</span>}
    </label>
  );
}

export function Input({ className, ...rest }: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "w-full rounded-[14px] border border-line bg-shell px-3 py-2 text-[13px] text-ink outline-none transition-colors placeholder:text-ink3 focus:border-brand",
        className,
      )}
      {...rest}
    />
  );
}
