import { useEffect, useMemo, useRef, useState } from "react";
import { actions, useApp } from "../../lib/store";
import {
  BY_SYMBOL,
  breadth,
  fmtCompact,
  fmtPrice,
  fmtSigned,
  fmtVol,
  quote,
  sectorPerformance,
  session,
  sparkline,
} from "../../lib/marketData";
import type { Region, Timeframe } from "../../lib/types";
import { Badge, Card, Delta, Icon, Sparkline } from "../ui/primitives";
import { cn } from "../../utils/cn";

/* ------------------------------------------------------------------ *
 * Index / KPI cards
 * ------------------------------------------------------------------ */
export function IndexCard({ symbol, timeframe = "1D" }: { symbol: string; timeframe?: Timeframe }) {
  useApp();
  const inst = BY_SYMBOL[symbol];
  const q = quote(symbol);
  const data = sparkline(symbol, 34, timeframe);
  const sess = session(inst?.region ?? "IN");
  const up = q.changePercent >= 0;
  const isVix = /VIX/i.test(symbol);

  return (
    <button
      onClick={() => actions.openSymbol(symbol, "chart")}
      className="card-hover w-full rounded-[20px] border border-line bg-shell p-4 text-left shadow-[var(--shadow-soft)]"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-[11.5px] font-semibold text-ink2">{inst?.name ?? symbol}</p>
          <p className="text-[10.5px] text-ink3">
            {inst?.exchange} · {sess.label}
          </p>
        </div>
        <span
          className={cn(
            "flex h-6 w-6 shrink-0 items-center justify-center rounded-full",
            isVix ? "bg-warnsoft text-warn" : up ? "bg-possoft text-pos" : "bg-negsoft text-neg",
          )}
        >
          <Icon name={isVix ? "gauge" : up ? "trendUp" : "trendDown"} size={12} />
        </span>
      </div>

      <div className="mt-2.5 flex items-end justify-between gap-2">
        <div>
          <p className="tabnum font-display text-[22px] font-extrabold leading-none tracking-[-0.02em] text-ink">
            {q.price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <p className="tabnum mt-1.5 text-[11.5px] font-semibold">
            <span className={up ? "text-pos" : "text-neg"}>
              {fmtSigned(q.change)} ({fmtSigned(q.changePercent)}%)
            </span>
          </p>
        </div>
        <Sparkline data={data} width={82} height={34} />
      </div>
    </button>
  );
}

export function KpiCard({
  label,
  value,
  sub,
  delta,
  spark,
  icon = "arrowUpRight",
  tone = "brand",
}: {
  label: string;
  value: string;
  sub?: string;
  delta?: number;
  spark?: number[];
  icon?: string;
  tone?: "brand" | "pos" | "neg" | "warn";
}) {
  const tones = { brand: "bg-brandsoft text-brand", pos: "bg-possoft text-pos", neg: "bg-negsoft text-neg", warn: "bg-warnsoft text-warn" };
  return (
    <Card hover className="flex flex-col justify-between">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[12px] font-semibold text-ink2">{label}</p>
          {sub && <p className="mt-0.5 text-[10.5px] text-ink3">{sub}</p>}
        </div>
        <span className={cn("flex h-7 w-7 items-center justify-center rounded-full", tones[tone])}>
          <Icon name={icon} size={13} />
        </span>
      </div>
      <div className="mt-3 flex items-end justify-between gap-2">
        <div>
          <p className="tabnum font-display text-[25px] font-extrabold leading-none tracking-[-0.025em] text-ink">{value}</p>
          {delta !== undefined && (
            <div className="mt-2 flex items-center gap-1.5">
              <Delta value={delta} size="xs" />
              {sub && <span className="text-[10.5px] text-ink3">vs last session</span>}
            </div>
          )}
        </div>
        {spark && <Sparkline data={spark} width={78} height={30} positive={(delta ?? 0) >= 0} />}
      </div>
    </Card>
  );
}

/* ------------------------------------------------------------------ *
 * Watchlist table
 * ------------------------------------------------------------------ */
/** Live price cell with a pale green / coral flash on change. */
export function LivePrice({ value, currency = "INR", className }: { value: number; currency?: "INR" | "USD"; className?: string }) {
  const [cls, setCls] = useState("");
  const prev = useRef(value);
  useEffect(() => {
    if (prev.current === value) return;
    const up = value > prev.current;
    prev.current = value;
    setCls(up ? "flash-pos" : "flash-neg");
    const t = window.setTimeout(() => setCls(""), 520);
    return () => window.clearTimeout(t);
  }, [value]);
  return (
    <span className={cn("tabnum inline-block rounded-md px-1 font-semibold text-ink", cls, className)}>
      {value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      {currency === "INR" ? "" : ""}
    </span>
  );
}

export function WatchlistTable({
  symbols,
  density = "comfortable",
  showSpark = true,
  watchlistId,
  region,
}: {
  symbols: string[];
  density?: "compact" | "comfortable";
  showSpark?: boolean;
  watchlistId?: string;
  region?: Region;
}) {
  const s = useApp();
  const density_ = density ?? s.settings.density;
  const rowH = density_ === "compact" ? 38 : 46;

  if (!symbols.length)
    return (
      <div className="flex flex-col items-center gap-2 py-8 text-center">
        <p className="text-[12.5px] font-semibold text-ink">No symbols yet</p>
        <p className="max-w-[240px] text-[11.5px] text-ink3">Use ⌘K to add instruments to this list.</p>
      </div>
    );

  return (
    <div className="overflow-hidden">
      <div className="grid grid-cols-[1fr_auto] items-center gap-2 border-b border-line px-1 pb-1.5 text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">
        <span>Symbol</span>
        <span className="flex items-center gap-3">
          {showSpark && <span className="hidden sm:block">Trend</span>}
          <span className="w-[62px] text-right">LTP</span>
          <span className="w-[64px] text-right">Chg%</span>
        </span>
      </div>
      <div>
        {symbols.map((sym) => {
          const inst = BY_SYMBOL[sym];
          if (!inst) return null;
          const q = quote(sym);
          const up = q.changePercent >= 0;
          const relVol = q.avgVolume ? q.volume / q.avgVolume : 1;
          const sess = session(inst.region);
          return (
            <div
              key={sym}
              className="group grid grid-cols-[1fr_auto] items-center gap-2 border-b border-line/60 px-1 transition-colors last:border-0 hover:bg-subtle"
              style={{ height: rowH }}
            >
              <button onClick={() => actions.openSymbol(sym, "chart")} className="flex min-w-0 items-center gap-2 text-left">
                <span
                  className={cn(
                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px] text-[10px] font-bold",
                    up ? "bg-possoft text-pos" : "bg-negsoft text-neg",
                  )}
                >
                  {sym.slice(0, 2)}
                </span>
                <span className="min-w-0">
                  <span className="flex items-center gap-1.5">
                    <span className="truncate text-[12.5px] font-semibold text-ink">{sym}</span>
                    {s.favorites.includes(sym) && <Icon name="star" size={10} className="shrink-0 text-warn" />}
                    {sess.phase !== "open" && <span className="hidden text-[9.5px] text-ink3 lg:inline">{inst.exchange}</span>}
                  </span>
                  <span className="block truncate text-[10.5px] text-ink3">
                    {relVol.toFixed(2)}× vol · {fmtVol(q.volume)}
                  </span>
                </span>
              </button>
              <div className="flex items-center gap-3">
                {showSpark && (
                  <span className="hidden sm:block">
                    <Sparkline data={sparkline(sym, 26)} width={54} height={22} strokeWidth={1.4} />
                  </span>
                )}
                <span className="tabnum w-[62px] text-right text-[12px] font-semibold text-ink">
                  {q.price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className="w-[64px] text-right">
                  <span className={cn("tabnum rounded-full px-1.5 py-[2px] text-[11px] font-bold", up ? "bg-possoft text-pos" : "bg-negsoft text-neg")}>
                    {up ? "+" : "−"}
                    {Math.abs(q.changePercent).toFixed(2)}%
                  </span>
                </span>
                {watchlistId && (
                  <button
                    onClick={() => actions.removeFromWatchlist(watchlistId, sym)}
                    className="opacity-0 transition-opacity group-hover:opacity-100"
                    aria-label={`Remove ${sym}`}
                  >
                    <Icon name="close" size={12} className="text-ink3 hover:text-neg" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
      {region && <p className="pt-2 text-[10px] text-ink3">Showing {symbols.length} instruments · {region === "IN" ? "NSE / BSE" : "NYSE / Nasdaq"}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Movers
 * ------------------------------------------------------------------ */
export function MoversList({ items, kind }: { items: { inst: { symbol: string; name: string; sector: string }; q: { price: number; changePercent: number; change: number } }[]; kind: "gain" | "lose" }) {
  return (
    <div className="space-y-1">
      {items.map(({ inst, q }) => (
        <button
          key={inst.symbol}
          onClick={() => actions.openSymbol(inst.symbol, "chart")}
          className="flex w-full items-center gap-2.5 rounded-[12px] px-2 py-1.5 text-left transition-colors hover:bg-muted"
        >
          <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px]", kind === "gain" ? "bg-possoft text-pos" : "bg-negsoft text-neg")}>
            <Icon name={kind === "gain" ? "trendUp" : "trendDown"} size={13} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[12px] font-semibold text-ink">{inst.symbol}</span>
            <span className="block truncate text-[10.5px] text-ink3">{inst.sector}</span>
          </span>
          <span className="text-right">
            <span className="tabnum block text-[12px] font-semibold text-ink">{fmtPrice(q.price, BY_SYMBOL[inst.symbol]?.currency ?? "INR")}</span>
            <span className={cn("tabnum block text-[10.5px] font-semibold", q.changePercent >= 0 ? "text-pos" : "text-neg")}>{fmtSigned(q.changePercent)}%</span>
          </span>
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Sector performance bars
 * ------------------------------------------------------------------ */
export function SectorBars({ region, limit = 8 }: { region: Region; limit?: number }) {
  const data = useMemo(() => sectorPerformance(region).slice(0, limit), [region, limit]);
  const max = Math.max(...data.map((d) => Math.abs(d.change)), 0.5);
  return (
    <div className="space-y-2">
      {data.map((d) => {
        const up = d.change >= 0;
        return (
          <div key={d.sector} className="flex items-center gap-2.5">
            <span className="w-[92px] shrink-0 truncate text-[11.5px] font-medium text-ink2">{d.sector}</span>
            <span className="relative h-[7px] flex-1 overflow-hidden rounded-full bg-muted">
              <span
                className={cn("absolute top-0 h-full rounded-full", up ? "left-1/2 bg-pos" : "right-1/2 bg-neg")}
                style={{ width: `${(Math.abs(d.change) / max) * 50}%` }}
              />
              <span className="absolute left-1/2 top-0 h-full w-px bg-line2" />
            </span>
            <span className={cn("tabnum w-[52px] shrink-0 text-right text-[11px] font-bold", up ? "text-pos" : "text-neg")}>{fmtSigned(d.change)}%</span>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Breadth
 * ------------------------------------------------------------------ */
export function BreadthCard({ region }: { region: Region }) {
  const b = breadth(region);
  const advPct = (b.adv / Math.max(1, b.total)) * 100;
  return (
    <div>
      <div className="mb-3 flex items-end justify-between">
        <div>
          <p className="tabnum font-display text-[22px] font-extrabold leading-none tracking-[-0.02em] text-ink">
            {b.adv}
            <span className="text-ink3"> / </span>
            {b.dec}
          </p>
          <p className="mt-1 text-[11px] text-ink3">advancing / declining</p>
        </div>
        <Badge tone={b.ratio >= 1.2 ? "pos" : b.ratio <= 0.85 ? "neg" : "neutral"}>A/D {b.ratio.toFixed(2)}</Badge>
      </div>
      <div className="flex h-2.5 overflow-hidden rounded-full bg-muted">
        <span className="bg-pos" style={{ width: `${advPct}%` }} />
        <span className="bg-negsoft" style={{ width: `${(b.unc / Math.max(1, b.total)) * 100}%` }} />
        <span className="flex-1 bg-neg" />
      </div>
      <div className="mt-2 flex justify-between text-[10.5px] text-ink3">
        <span>{advPct.toFixed(0)}% advancing</span>
        <span>{b.total} instruments</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Heatmap
 * ------------------------------------------------------------------ */
export function Heatmap({
  symbols,
  onPick,
  metric = "changePercent",
  cols,
}: {
  symbols: string[];
  onPick?: (s: string) => void;
  metric?: "changePercent" | "relvol";
  cols?: number;
}) {
  const cells = symbols.map((sym) => {
    const inst = BY_SYMBOL[sym];
    const q = quote(sym);
    return { sym, name: inst?.name ?? sym, sector: inst?.sector ?? "", mcap: inst?.mcap ?? 1, value: metric === "changePercent" ? q.changePercent : q.avgVolume ? q.volume / q.avgVolume : 1, price: q.price };
  });
  const max = Math.max(...cells.map((c) => Math.abs(c.value)), 0.6);

  const color = (v: number) => {
    const t = Math.min(1, Math.abs(v) / max);
    const alpha = 0.14 + t * 0.72;
    return v >= 0 ? `rgba(39,166,106,${alpha})` : `rgba(227,93,104,${alpha})`;
  };

  return (
    <div
      className="grid gap-1.5"
      style={{ gridTemplateColumns: `repeat(${cols ?? Math.min(6, Math.ceil(Math.sqrt(cells.length)))}, minmax(0,1fr))` }}
    >
      {cells.map((c) => (
        <button
          key={c.sym}
          onClick={() => (onPick ? onPick(c.sym) : actions.openSymbol(c.sym, "chart"))}
          className="group relative flex flex-col justify-between overflow-hidden rounded-[13px] border border-line/70 p-2.5 text-left transition-transform hover:z-10 hover:scale-[1.03]"
          style={{ background: color(c.value), aspectRatio: "1.35" }}
          title={`${c.name} · ${c.sector}`}
        >
          <span className="text-[11.5px] font-bold tracking-[-0.01em] text-ink">{c.sym}</span>
          <span>
            <span className="tabnum block text-[11px] font-bold text-ink/85">
              {metric === "changePercent" ? `${fmtSigned(c.value)}%` : `${c.value.toFixed(2)}×`}
            </span>
            <span className="tabnum block text-[9.5px] font-medium text-ink/55">{fmtCompact(c.mcap, BY_SYMBOL[c.sym]?.currency ?? "USD")}</span>
          </span>
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Simple SVG area chart (dashboard performance)
 * ------------------------------------------------------------------ */
export function AreaChart({
  data,
  labels,
  height = 190,
  color = "#8066FF",
  baseline,
  showGrid = true,
  className,
}: {
  data: number[];
  labels?: string[];
  height?: number;
  color?: string;
  baseline?: number;
  showGrid?: boolean;
  className?: string;
}) {
  const W = 700;
  const H = height;
  const padB = labels ? 22 : 8;
  const min = Math.min(...data, baseline ?? Infinity);
  const max = Math.max(...data, baseline ?? -Infinity);
  const span = max - min || 1;
  const step = W / Math.max(1, data.length - 1);
  const y = (v: number) => H - padB - ((v - min) / span) * (H - padB - 12);
  const pts = data.map((v, i) => [i * step, y(v)] as const);
  const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const up = data[data.length - 1] >= data[0];
  const stroke = color === "auto" ? (up ? "#27A66A" : "#E35D68") : color;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className={cn("w-full", className)} style={{ height }} preserveAspectRatio="none" aria-hidden>
      <defs>
        <linearGradient id={`ac-${stroke.slice(1)}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={stroke} stopOpacity="0.22" />
          <stop offset="100%" stopColor={stroke} stopOpacity="0" />
        </linearGradient>
      </defs>
      {showGrid &&
        [0.25, 0.5, 0.75].map((f) => (
          <line key={f} x1="0" x2={W} y1={(H - padB) * f + 12} y2={(H - padB) * f + 12} stroke="#F1EFF6" strokeWidth="1" />
        ))}
      {baseline !== undefined && <line x1="0" x2={W} y1={y(baseline)} y2={y(baseline)} stroke="#DCD9E3" strokeDasharray="4 4" />}
      <path d={`${line} L${W},${H - padB} L0,${H - padB} Z`} fill={`url(#ac-${stroke.slice(1)})`} />
      <path d={line} fill="none" stroke={stroke} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="3.5" fill={stroke} stroke="#fff" strokeWidth="2" />
      {labels &&
        labels.map((l, i) => (
          <text
            key={l + i}
            x={(i / Math.max(1, labels.length - 1)) * W}
            y={H - 4}
            textAnchor={i === 0 ? "start" : i === labels.length - 1 ? "end" : "middle"}
            className="fill-[#A4A2AB]"
            style={{ fontSize: 10, fontWeight: 500 }}
          >
            {l}
          </text>
        ))}
    </svg>
  );
}

/* ------------------------------------------------------------------ *
 * Radial gauge
 * ------------------------------------------------------------------ */
export function RadialGauge({
  value,
  label,
  sub,
  size = 150,
  segments = 5,
}: {
  value: number;
  label: string;
  sub?: string;
  size?: number;
  segments?: number;
}) {
  const r = size / 2 - 10;
  const c = 2 * Math.PI * r;
  const filled = (value / 100) * c;
  const colors = ["#E35D68", "#E9A23B", "#8066FF", "#27A66A", "#1F8F58"];
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#F1EFF6" strokeWidth="11" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={colors[Math.min(colors.length - 1, Math.floor((value / 100) * segments))]}
          strokeWidth="11"
          strokeLinecap="round"
          strokeDasharray={`${filled} ${c - filled}`}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="tabnum font-display text-[24px] font-extrabold leading-none text-ink">{value}</span>
        <span className="mt-0.5 text-[10.5px] font-semibold text-ink2">{label}</span>
        {sub && <span className="mt-0.5 text-[9.5px] text-ink3">{sub}</span>}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Donut allocation
 * ------------------------------------------------------------------ */
export function Donut({ items, size = 140, thickness = 16 }: { items: { label: string; value: number; color: string }[]; size?: number; thickness?: number }) {
  const total = items.reduce((a, b) => a + b.value, 0) || 1;
  const r = size / 2 - thickness / 2;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <div className="flex items-center gap-4">
      <svg width={size} height={size} className="-rotate-90 shrink-0">
        {items.map((it) => {
          const len = (it.value / total) * c;
          const el = (
            <circle
              key={it.label}
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              stroke={it.color}
              strokeWidth={thickness}
              strokeDasharray={`${Math.max(0, len - 2)} ${c - Math.max(0, len - 2)}`}
              strokeDashoffset={-offset}
              strokeLinecap="round"
            />
          );
          offset += len;
          return el;
        })}
      </svg>
      <div className="min-w-0 flex-1 space-y-1.5">
        {items.map((it) => (
          <div key={it.label} className="flex items-center gap-2 text-[11.5px]">
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: it.color }} />
            <span className="min-w-0 flex-1 truncate text-ink2">{it.label}</span>
            <span className="tabnum font-semibold text-ink">{((it.value / total) * 100).toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ChartSkeleton({ height = 220 }: { height?: number }) {
  return (
    <div className="flex flex-col justify-end gap-2" style={{ height }}>
      {[0.9, 0.65, 0.8, 0.5, 0.72].map((f, i) => (
        <div key={i} className="skeleton" style={{ width: `${f * 100}%`, height: 9 }} />
      ))}
    </div>
  );
}

export function periodLabel(tf: Timeframe) {
  const map: Partial<Record<Timeframe, string>> = { "1D": "1D", "1W": "1W", "1M": "1M" };
  return map[tf] ?? tf;
}
