import { useMemo } from "react";
import { BY_SYMBOL, getSeries, quote } from "./marketData";
import { correlation, cagr, drawdownSeries, maxDrawdown, returns, sharpe, beta, alpha } from "./indicators";
import type { Transaction } from "./types";

export interface Holding {
  symbol: string;
  qty: number;
  avgPrice: number;
  invested: number;
  price: number;
  value: number;
  pnl: number;
  pnlPct: number;
  dayPnl: number;
  currency: "INR" | "USD";
  region: "IN" | "US";
  sector: string;
  weight: number;
  realized: number;
}

export interface PortfolioStats {
  holdings: Holding[];
  value: number;
  invested: number;
  dayPnl: number;
  dayPnlPct: number;
  totalPnl: number;
  totalPnlPct: number;
  unrealized: number;
  realized: number;
  cash: number;
  cagr: number;
  mdd: number;
  sharpe: number;
  beta: number;
  alpha: number;
  equity: number[];
  dd: number[];
  sectorMix: { label: string; value: number; color: string }[];
  countryMix: { label: string; value: number; color: string }[];
  monthly: { label: string; ret: number }[];
  contributions: { symbol: string; contribution: number }[];
  winRate: number;
}

const PALETTE = ["#8066FF", "#6D72E8", "#27A66A", "#E9A23B", "#E35D68", "#A78BFA", "#34D399", "#F0A5AC"];

export function computePortfolio(txs: Transaction[]): PortfolioStats {
  const map = new Map<string, { qty: number; cost: number; realized: number }>();
  for (const t of [...txs].sort((a, b) => a.date.localeCompare(b.date))) {
    const cur = map.get(t.symbol) ?? { qty: 0, cost: 0, realized: 0 };
    if (t.side === "buy") {
      cur.qty += t.qty;
      cur.cost += t.qty * t.price + t.fees;
    } else {
      const avg = cur.qty ? cur.cost / cur.qty : t.price;
      cur.realized += (t.price - avg) * t.qty - t.fees;
      cur.qty = Math.max(0, cur.qty - t.qty);
      cur.cost = Math.max(0, cur.cost - avg * t.qty);
    }
    map.set(t.symbol, cur);
  }

  const holdings: Holding[] = [];
  for (const [symbol, v] of map) {
    if (v.qty <= 0) continue;
    const inst = BY_SYMBOL[symbol];
    if (!inst) continue;
    const q = quote(symbol);
    const invested = v.cost;
    const value = v.qty * q.price;
    holdings.push({
      symbol,
      qty: v.qty,
      avgPrice: invested / v.qty,
      invested,
      price: q.price,
      value,
      pnl: value - invested,
      pnlPct: invested ? ((value - invested) / invested) * 100 : 0,
      dayPnl: v.qty * q.change,
      currency: inst.currency,
      region: inst.region,
      sector: inst.sector,
      weight: 0,
      realized: v.realized,
    });
  }

  const value = holdings.reduce((a, h) => a + h.value, 0);
  const invested = holdings.reduce((a, h) => a + h.invested, 0);
  const dayPnl = holdings.reduce((a, h) => a + h.dayPnl, 0);
  const realized = holdings.reduce((a, h) => a + h.realized, 0);
  for (const h of holdings) h.weight = value ? (h.value / value) * 100 : 0;

  // equity curve: walk the last 240 daily closes of each holding
  const len = 240;
  const curves = holdings.map((h) => {
    const s = getSeries(h.symbol, "1D", len).map((c) => c.close);
    const pad = new Array(Math.max(0, len - s.length)).fill(s[0] ?? h.price);
    return [...pad, ...s].map((p) => (p / (s[0] ?? h.price)) * h.invested);
  });
  const equity: number[] = [];
  for (let i = 0; i < len; i++) {
    let sum = 0;
    for (const c of curves) sum += c[i] ?? 0;
    equity.push(sum + 250000 * (1 + i * 0.0006));
  }
  const benchSym = "NIFTY50";
  const bench = getSeries(benchSym, "1D", len).map((c) => c.close);

  // monthly returns from equity curve (approx 21 trading days per month)
  const monthly: { label: string; ret: number }[] = [];
  for (let i = 21; i < equity.length; i += 21) {
    const r = (equity[i] / equity[i - 21] - 1) * 100;
    const d = new Date();
    d.setMonth(d.getMonth() - Math.floor((equity.length - i) / 21));
    monthly.push({ label: d.toLocaleDateString("en-US", { month: "short" }), ret: r });
  }

  const sectorAgg = new Map<string, number>();
  for (const h of holdings) sectorAgg.set(h.sector, (sectorAgg.get(h.sector) ?? 0) + h.value);
  const sectorMix = [...sectorAgg.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([label, v], i) => ({ label, value: v, color: PALETTE[i % PALETTE.length] }));

  const countryAgg = new Map<string, number>();
  for (const h of holdings) countryAgg.set(h.region === "IN" ? "India" : "United States", (countryAgg.get(h.region === "IN" ? "India" : "United States") ?? 0) + h.value);
  const countryMix = [...countryAgg.entries()].map(([label, v], i) => ({ label, value: v, color: PALETTE[(i + 2) % PALETTE.length] }));

  const contributions = holdings
    .map((h) => ({ symbol: h.symbol, contribution: value ? ((h.value - h.invested) / value) * 100 : 0 }))
    .sort((a, b) => b.contribution - a.contribution);

  const wins = holdings.filter((h) => h.pnl > 0).length;

  return {
    holdings: holdings.sort((a, b) => b.value - a.value),
    value,
    invested,
    dayPnl,
    dayPnlPct: invested ? (dayPnl / Math.max(1, value - dayPnl)) * 100 : 0,
    totalPnl: value - invested,
    totalPnlPct: invested ? ((value - invested) / invested) * 100 : 0,
    unrealized: value - invested,
    realized,
    cash: 250000 * 0.35,
    cagr: cagr(equity, equity.length / 252),
    mdd: maxDrawdown(equity),
    sharpe: sharpe(equity),
    beta: beta(equity, bench),
    alpha: alpha(equity, bench),
    equity,
    dd: drawdownSeries(equity),
    sectorMix,
    countryMix,
    monthly,
    contributions,
    winRate: holdings.length ? (wins / holdings.length) * 100 : 0,
  };
}

export function usePortfolio(txs: Transaction[]): PortfolioStats {
  const key = useMemo(() => txs.map((t) => t.id).join("|"), [txs]);
  return useMemo(() => computePortfolio(txs), [key]); // eslint-disable-line react-hooks/exhaustive-deps
}

export function useCorrelationMatrix(symbols: string[], days = 120) {
  return useMemo(() => {
    const rets = symbols.map((s) => returns(getSeries(s, "1D", days).map((c) => c.close)));
    return symbols.map((_, i) => symbols.map((__, j) => correlation(rets[i], rets[j])));
  }, [symbols.join("|"), days]); // eslint-disable-line react-hooks/exhaustive-deps
}
