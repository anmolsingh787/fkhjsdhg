import { useRef, useState } from "react";
import { actions, useApp, useMotionClass } from "../../lib/store";
import { breadth, regionChange, session } from "../../lib/marketData";
import { cn } from "../../utils/cn";
import { Badge, Delta, Icon, IconButton, Pill, PrimaryButton } from "../ui/primitives";

export const NAV = [
  { id: "overview", label: "Overview", icon: "overview" },
  { id: "markets", label: "Markets", icon: "markets" },
  { id: "chart", label: "Pro Chart", icon: "chart" },
  { id: "watchlists", label: "Watchlists", icon: "watchlist" },
  { id: "screener", label: "Screener", icon: "screener" },
  { id: "heatmap", label: "Heatmap", icon: "heatmap" },
  { id: "compare", label: "Compare", icon: "compare" },
  { id: "portfolio", label: "Portfolio", icon: "portfolio" },
  { id: "analytics", label: "Analytics", icon: "analytics" },
  { id: "alerts", label: "Alerts", icon: "alerts" },
  { id: "journal", label: "Journal", icon: "journal" },
  { id: "calendar", label: "Calendar", icon: "calendar" },
  { id: "data", label: "Data Sources", icon: "database" },
  { id: "settings", label: "Settings", icon: "settings" },
];

/* ------------------------------------------------------------------ *
 * Sidebar
 * ------------------------------------------------------------------ */
export function Sidebar() {
  const s = useApp();
  const collapsed = s.settings.sidebarCollapsed;
  const motion = useMotionClass();

  return (
    <aside
      className={cn(
        "flex shrink-0 flex-col border-r border-line bg-shell transition-[width] duration-[220ms] ease-out",
        collapsed ? "w-[68px]" : "w-[168px]",
        motion,
      )}
    >
      <div className="flex items-center gap-2 px-4 py-4">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-ink">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M5 18V9l4 4 3-6 3 5 4-7v13z" stroke="#fff" strokeWidth="1.8" strokeLinejoin="round" />
          </svg>
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <p className="truncate font-display text-[13.5px] font-extrabold tracking-[-0.02em] text-ink">AERRIK</p>
            <p className="truncate text-[9.5px] font-medium uppercase tracking-[0.14em] text-ink3">Market OS</p>
          </div>
        )}
      </div>

      <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 pb-2">
        {NAV.map((n) => {
          const active = s.screen === n.id;
          return (
            <button
              key={n.id}
              onClick={() => actions.navigate(n.id)}
              title={collapsed ? n.label : undefined}
              className={cn(
                "group flex w-full items-center gap-2.5 rounded-[13px] px-2.5 py-2 text-left transition-all duration-150",
                active ? "bg-brand text-white shadow-[0_2px_10px_rgba(128,102,255,0.24)]" : "text-ink2 hover:bg-muted hover:text-ink",
              )}
            >
              <Icon name={n.icon} size={16} className="shrink-0" />
              {!collapsed && <span className="truncate text-[12.5px] font-medium">{n.label}</span>}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-line p-2">
        <button
          onClick={() => actions.setSettings({ sidebarCollapsed: !collapsed })}
          className="flex w-full items-center justify-center rounded-[13px] py-2 text-ink3 transition-colors hover:bg-muted hover:text-ink"
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <Icon name={collapsed ? "chevronRight" : "chevronsLeft"} size={16} />
        </button>
      </div>
    </aside>
  );
}

/* ------------------------------------------------------------------ *
 * Notification center
 * ------------------------------------------------------------------ */
export function NotificationCenter({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useApp();
  if (!open) return null;
  const sevTone = ["bg-muted text-ink2", "bg-infosoft text-info", "bg-warnsoft text-warn", "bg-negsoft text-neg"];
  const sevIcon = ["info", "bell", "warning", "zap"];
  return (
    <>
      <div className="fixed inset-0 z-40" onClick={onClose} />
      <div className="anim-pop absolute right-0 top-12 z-50 w-[352px] rounded-[18px] border border-line bg-shell p-3 shadow-[0_20px_60px_rgba(28,24,54,0.14)]">
        <div className="mb-2 flex items-center justify-between px-1">
          <div>
            <p className="text-[13px] font-bold tracking-[-0.01em] text-ink">Notifications</p>
            <p className="text-[10.5px] text-ink3">
              {s.notifications.filter((n) => !n.read).length} unread · {s.alerts.filter((a) => a.active).length} live alerts
            </p>
          </div>
          <div className="flex gap-1">
            <button onClick={actions.markAllRead} className="rounded-full px-2 py-1 text-[11px] font-medium text-ink2 hover:bg-muted">
              Mark read
            </button>
            <button onClick={actions.clearNotifications} className="rounded-full p-1.5 text-ink3 hover:bg-muted" aria-label="Clear">
              <Icon name="trash" size={13} />
            </button>
          </div>
        </div>
        <div className="max-h-[340px] space-y-1 overflow-y-auto">
          {s.notifications.length === 0 && <p className="px-2 py-6 text-center text-[11.5px] text-ink3">No notifications yet.</p>}
          {s.notifications.map((n) => (
            <button
              key={n.id}
              onClick={() => {
                if (n.symbol) actions.openSymbol(n.symbol, "chart");
                onClose();
              }}
              className="flex w-full gap-2.5 rounded-[13px] p-2 text-left transition-colors hover:bg-muted"
            >
              <span className={cn("mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full", sevTone[n.severity])}>
                <Icon name={sevIcon[n.severity]} size={12} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-1.5">
                  <span className="truncate text-[12px] font-semibold text-ink">{n.title}</span>
                  {!n.read && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-neg" />}
                </span>
                {n.body && <span className="block truncate text-[11px] text-ink3">{n.body}</span>}
                <span className="mt-0.5 flex items-center gap-1.5 text-[10px] text-ink3">
                  <span>{n.category}</span>
                  {n.symbol && <span className="font-semibold text-brand">{n.symbol}</span>}
                  <span>· {new Date(n.ts).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}</span>
                </span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ *
 * Toasts
 * ------------------------------------------------------------------ */
export function Toasts() {
  const s = useApp();
  const tones = [
    "border-line bg-shell",
    "border-brand/40 bg-shell",
    "border-warn/50 bg-warnsoft/60",
    "border-neg/50 bg-negsoft/70",
  ];
  const icons = ["info", "bell", "warning", "zap"];
  return (
    <div className="pointer-events-none fixed bottom-5 right-5 z-[60] flex w-[318px] flex-col gap-2">
      {s.toasts.map((t) => (
        <div
          key={t.id}
          className={cn(
            "anim-pop pointer-events-auto flex items-start gap-2.5 rounded-[16px] border p-3 shadow-[0_18px_44px_rgba(28,24,54,0.14)] backdrop-blur",
            tones[t.severity],
          )}
          role="status"
        >
          <span
            className={cn(
              "flex h-7 w-7 shrink-0 items-center justify-center rounded-full",
              t.severity === 3 ? "bg-neg text-white" : t.severity === 2 ? "bg-warn text-white" : t.severity === 1 ? "bg-brandsoft text-brand" : "bg-muted text-ink2",
            )}
          >
            <Icon name={icons[t.severity]} size={14} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[12.5px] font-semibold text-ink">{t.title}</p>
            {t.body && <p className="mt-0.5 text-[11px] leading-snug text-ink2">{t.body}</p>}
            <div className="mt-1.5 flex items-center gap-2">
              {t.symbol && (
                <button
                  onClick={() => {
                    actions.openSymbol(t.symbol!, "chart");
                    actions.dismissToast(t.id);
                  }}
                  className="rounded-full bg-brandsoft px-2 py-[3px] text-[10.5px] font-semibold text-brand"
                >
                  Open chart
                </button>
              )}
              <button onClick={() => actions.dismissToast(t.id)} className="text-[10.5px] font-medium text-ink3 hover:text-ink">
                Dismiss
              </button>
            </div>
          </div>
          <button onClick={() => actions.dismissToast(t.id)} className="text-ink3 hover:text-ink" aria-label="Close">
            <Icon name="close" size={13} />
          </button>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ *
 * Header
 * ------------------------------------------------------------------ */
function Avatar() {
  return (
    <div className="flex items-center gap-2 rounded-full border border-line bg-shell py-1 pl-1 pr-3">
      <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-brand to-info text-[11px] font-bold text-white">
        AR
      </span>
      <span className="hidden leading-tight lg:block">
        <span className="block text-[12px] font-semibold text-ink">Aerrik</span>
        <span className="block text-[10px] text-ink3">Personal workstation</span>
      </span>
    </div>
  );
}

export function Header({ onOpenPalette }: { onOpenPalette: () => void }) {
  const s = useApp();
  const region = s.settings.region;
  const sess = session(region);
  const idxChange = regionChange(region);
  const b = breadth(region);
  const [notifOpen, setNotifOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const unread = s.notifications.filter((n) => !n.read).length;

  const hour = new Date().getHours();
  const greet = hour < 5 ? "Late night session" : hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const today = new Date().toLocaleDateString("en-US", { weekday: "long", day: "numeric", month: "long" });

  return (
    <header className="relative flex items-center justify-between gap-4 px-6 pb-1 pt-5" ref={ref}>
      <div className="min-w-0">
        <h1 className="font-display text-[26px] font-extrabold leading-tight tracking-[-0.03em] text-ink">
          {greet}, Aerrik
        </h1>
        <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[12px] text-ink2">
          <span className="inline-flex items-center gap-1.5">
            <span className={cn("h-1.5 w-1.5 rounded-full", sess.phase === "open" ? "bg-pos" : sess.phase === "pre" || sess.phase === "post" ? "bg-warn" : "bg-ink3")} />
            {sess.label}
          </span>
          <span className="text-ink3">·</span>
          <span className="tabnum">{sess.tz.label} {region === "IN" ? "IST" : "ET"}</span>
          <span className="text-ink3">·</span>
          <span>{today}</span>
          <span className="text-ink3">·</span>
          <span className="tabnum">
            {region === "IN" ? "NIFTY" : "S&P 500"} <Delta value={idxChange} size="xs" />
          </span>
          <span className="text-ink3">·</span>
          <span className="tabnum">
            A/D {b.adv}:{b.dec}
          </span>
        </p>
      </div>

      <div className="flex shrink-0 items-center gap-2">
        <button
          onClick={onOpenPalette}
          className="hidden items-center gap-2 rounded-full border border-line bg-shell py-1.5 pl-3 pr-2 text-[12px] text-ink3 transition-colors hover:border-line2 md:flex"
        >
          <Icon name="search" size={14} />
          <span className="pr-6">Search symbols, pages…</span>
          <kbd className="rounded-md border border-line bg-muted px-1.5 py-[1px] font-sans text-[10px] font-semibold text-ink3">⌘K</kbd>
        </button>
        <div className="inline-flex items-center gap-0.5 rounded-full border border-line bg-muted p-0.5">
          {(["IN", "US"] as const).map((r) => (
            <button
              key={r}
              onClick={() => actions.setSettings({ region: r })}
              className={cn(
                "rounded-full px-3 py-1 text-[11.5px] font-semibold transition-all",
                region === r ? "bg-shell text-ink shadow-[0_1px_4px_rgba(20,18,30,0.08)]" : "text-ink3 hover:text-ink2",
              )}
            >
              {r === "IN" ? "India" : "USA"}
            </button>
          ))}
        </div>
        <div className="relative">
          <IconButton name="bell" label="Notifications" badge={unread} onClick={() => setNotifOpen((v) => !v)} active={notifOpen} />
          <NotificationCenter open={notifOpen} onClose={() => setNotifOpen(false)} />
        </div>
        <IconButton name="settings" label="Settings" onClick={() => actions.navigate("settings")} />
        <Avatar />
      </div>
    </header>
  );
}

export function HeaderToolbar({ children }: { children?: React.ReactNode }) {
  return <div className="flex flex-wrap items-center justify-between gap-3 px-6 pb-3 pt-2">{children}</div>;
}

export function MarketStatusPill({ region }: { region: "IN" | "US" }) {
  const sess = session(region);
  const b = breadth(region);
  return (
    <div className="flex items-center gap-2 rounded-full border border-line bg-shell px-3 py-1.5">
      <Icon name="clock" size={13} className="text-ink3" />
      <span className="text-[12px] font-medium text-ink2">{sess.label}</span>
      <span className="h-3 w-px bg-line" />
      <Badge tone={b.ratio >= 1 ? "pos" : "neg"}>{b.ratio >= 1 ? "Advancing" : "Declining"}</Badge>
      <span className="tabnum text-[11.5px] text-ink3">{b.adv}/{b.dec}</span>
    </div>
  );
}

export { Pill, PrimaryButton };
