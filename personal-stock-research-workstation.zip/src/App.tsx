import { useEffect, useRef, useState } from "react";
import { actions, getState, useApp, useMotionClass, useTick } from "./lib/store";
import { INDICES, breadth, marketMood, quote, session } from "./lib/marketData";
import { Header, Sidebar, Toasts } from "./components/shell/Shell";
import { CommandPalette } from "./components/shell/CommandPalette";
import { Overview } from "./screens/Overview";
import { ProChart } from "./screens/ProChart";
import { Compare, HeatmapScreen, Markets, Screener, StockDetail, Watchlists } from "./screens/Research";
import { Alerts, Analytics, CalendarScreen, DataSources, Journal, PortfolioScreen, SettingsScreen } from "./screens/Work";
import { Icon } from "./components/ui/primitives";
import { cn } from "./utils/cn";

export default function App() {
  const s = useApp();
  const tick = useTick();
  const motionClass = useMotionClass();
  const [paletteOpen, setPaletteOpen] = useState(false);
  const fired = useRef<Set<string>>(new Set());
  const shocked = useRef(false);

  /* ---------------- global shortcuts ---------------- */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName)) return;
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      } else if (e.key === "/" && !paletteOpen) {
        e.preventDefault();
        setPaletteOpen(true);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [paletteOpen]);

  /* ---------------- alert engine ---------------- */
  useEffect(() => {
    const st = getState();
    if (!st.connected) return;
    for (const a of st.alerts) {
      if (!a.active) continue;
      const q = quote(a.symbol);
      if (!q.price) continue;
      let hit = false;
      let detail = "";
      switch (a.condition) {
        case "price_above":
          hit = q.price >= a.value;
          detail = `trading at ${q.price.toFixed(2)}`;
          break;
        case "price_below":
          hit = q.price <= a.value;
          detail = `trading at ${q.price.toFixed(2)}`;
          break;
        case "price_cross_up":
          hit = q.price >= a.value;
          detail = `crossed above ${a.value}`;
          break;
        case "price_cross_down":
          hit = q.price <= a.value;
          detail = `crossed below ${a.value}`;
          break;
        case "pct_move":
          hit = Math.abs(q.changePercent) >= a.value;
          detail = `moved ${q.changePercent.toFixed(2)}%`;
          break;
        case "volume_above": {
          const rv = q.avgVolume ? q.volume / q.avgVolume : 0;
          hit = rv >= a.value;
          detail = `relative volume ${rv.toFixed(2)}×`;
          break;
        }
        default:
          hit = false;
      }
      if (hit && !fired.current.has(a.id)) {
        fired.current.add(a.id);
        actions.pushToast({
          severity: 1,
          title: a.message,
          body: `${a.symbol} ${detail} · ${new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`,
          symbol: a.symbol,
        });
        actions.pushNotification({ severity: 1, category: "Price", title: a.message, body: `${a.symbol} ${detail}`, symbol: a.symbol });
        if (a.channels.browser && "Notification" in window && Notification.permission === "granted") {
          try {
            new Notification("AERRIK Markets", { body: a.message });
          } catch {
            /* ignore */
          }
        }
      }
    }
  }, [tick]);

  /* ---------------- market shock detection ---------------- */
  const region = s.settings.region;
  const idxSym = INDICES[region][0];
  const idxChange = quote(idxSym).changePercent;
  const mood = marketMood(region);
  const shock = s.connected && idxChange <= s.settings.crashIndexThreshold;

  useEffect(() => {
    if (shock && !shocked.current) {
      shocked.current = true;
      actions.pushToast({
        severity: 3,
        title: "Market shock detected",
        body: `${region === "IN" ? "NIFTY 50" : "S&P 500"} ${idxChange.toFixed(2)}% intraday. Breadth and worst performers surfaced.`,
      });
      actions.pushNotification({
        severity: 3,
        category: "Market",
        title: "High volatility event",
        body: `${region === "IN" ? "NIFTY 50" : "S&P 500"} moved ${idxChange.toFixed(2)}% — review breadth before acting.`,
      });
    }
    if (!shock) shocked.current = false;
  }, [shock, idxChange, region]);

  const screen = s.screen;
  const wide = ["overview", "markets", "screener", "heatmap", "compare", "portfolio", "analytics", "alerts", "journal", "calendar", "data", "settings", "watchlists", "detail"].includes(screen);

  return (
    <div className={cn("min-h-screen bg-app p-3 sm:p-5 lg:p-7", motionClass)}>
      <div className="mx-auto flex h-[calc(100vh-56px)] min-h-[620px] max-w-[1720px] overflow-hidden rounded-[28px] bg-shell shadow-[0_2px_6px_rgba(16,16,20,0.04),0_28px_70px_rgba(43,39,72,0.08)]">
        <Sidebar />

        <div className="flex min-w-0 flex-1 flex-col">
          <Header onOpenPalette={() => setPaletteOpen(true)} />

          {shock && (
            <div className="mx-6 mb-2 flex items-center gap-2.5 rounded-[14px] border border-neg/40 bg-negsoft px-3 py-2">
              <span className="pulse-ring flex h-6 w-6 items-center justify-center rounded-full bg-neg text-white">
                <Icon name="warning" size={13} />
              </span>
              <p className="text-[12px] font-semibold text-ink">
                Market shock · {region === "IN" ? "NIFTY 50" : "S&P 500"} {idxChange.toFixed(2)}%
              </p>
              <span className="tabnum text-[11.5px] text-ink2">
                Breadth {breadth(region).adv}:{breadth(region).dec} · Mood {mood}
              </span>
              <span className="ml-auto text-[10.5px] text-ink3">Visualisation of market state, not advice</span>
            </div>
          )}

          {!s.connected && (
            <div className="mx-6 mb-2 flex items-center gap-2.5 rounded-[14px] border border-warn/40 bg-warnsoft px-3 py-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-warn text-white">
                <Icon name="plug" size={13} />
              </span>
              <p className="text-[12px] font-semibold text-ink">Data provider unreachable</p>
              <span className="text-[11.5px] text-ink2">Cached values shown · last tick {new Date(quote(s.symbol).timestamp).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</span>
              <button onClick={() => actions.setConnected(true)} className="ml-auto rounded-full bg-shell px-2.5 py-1 text-[11px] font-semibold text-ink">
                Retry
              </button>
            </div>
          )}

          <main className={cn("min-h-0 flex-1 overflow-y-auto px-6 pb-6", wide ? "" : "pb-4")}>
            {screen === "overview" && <Overview />}
            {screen === "markets" && <Markets />}
            {screen === "chart" && (
              <div className="h-[calc(100vh-150px)] min-h-[560px]">
                <ProChart />
              </div>
            )}
            {screen === "detail" && <StockDetail />}
            {screen === "watchlists" && <Watchlists />}
            {screen === "screener" && <Screener />}
            {screen === "heatmap" && <HeatmapScreen />}
            {screen === "compare" && <Compare />}
            {screen === "portfolio" && <PortfolioScreen />}
            {screen === "analytics" && <Analytics />}
            {screen === "alerts" && <Alerts />}
            {screen === "journal" && <Journal />}
            {screen === "calendar" && <CalendarScreen />}
            {screen === "data" && <DataSources />}
            {screen === "settings" && <SettingsScreen />}
          </main>

          <footer className="flex items-center justify-between gap-3 border-t border-line px-6 py-2 text-[10.5px] text-ink3">
            <span>For personal research and informational purposes only. Not investment advice.</span>
            <span className="flex items-center gap-2">
              <span className={cn("h-1.5 w-1.5 rounded-full", s.connected ? "bg-pos" : "bg-neg")} />
              {s.settings.dataMode === "mock" ? "Demo market data" : "Live provider"} · {session(region).label}
            </span>
          </footer>
        </div>
      </div>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
      <Toasts />
    </div>
  );
}
