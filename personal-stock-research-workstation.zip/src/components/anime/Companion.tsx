import { useEffect, useMemo, useState } from "react";
import type { AnimeState } from "../../lib/types";
import { cn } from "../../utils/cn";
import { Icon } from "../ui/primitives";

interface Expr {
  eye: "open" | "happy" | "wide" | "sleep" | "spiral" | "focus";
  mouth: string;
  brow: number;
  pose: "idle" | "bounce" | "shake" | "point" | "hug" | "sleep";
  aura: string;
  particles: "none" | "up" | "down" | "spark" | "confetti" | "zzz";
  bubble?: string;
  ring: string;
}

const EXPR: Record<AnimeState, Expr> = {
  neutral: { eye: "open", mouth: "M92 120q8 5 16 0", brow: 0, pose: "idle", aura: "rgba(128,102,255,0.10)", particles: "none", ring: "#EEE9FF" },
  mildBull: { eye: "happy", mouth: "M90 118q10 9 20 0", brow: -1, pose: "bounce", aura: "rgba(39,166,106,0.12)", particles: "up", ring: "#EAF8F1" },
  strongBull: { eye: "happy", mouth: "M88 116q12 12 24 0", brow: -2, pose: "bounce", aura: "rgba(39,166,106,0.2)", particles: "up", ring: "#D7F2E5" },
  breakout: { eye: "focus", mouth: "M92 122q8 7 16 0", brow: -3, pose: "point", aura: "rgba(109,114,232,0.16)", particles: "spark", bubble: "Breakout detected", ring: "#EFF0FF" },
  mildBear: { eye: "focus", mouth: "M92 122q8 -6 16 0", brow: 3, pose: "idle", aura: "rgba(227,93,104,0.10)", particles: "down", ring: "#FDECEF" },
  strongBear: { eye: "open", mouth: "M94 124q6 -5 12 0", brow: 5, pose: "hug", aura: "rgba(227,93,104,0.18)", particles: "down", ring: "#FBDEE1" },
  crash: { eye: "wide", mouth: "M96 126q4 -9 8 0", brow: 7, pose: "shake", aura: "rgba(227,93,104,0.26)", particles: "down", bubble: "Market shock", ring: "#F8D3D7" },
  rally: { eye: "happy", mouth: "M86 114q14 14 28 0", brow: -3, pose: "bounce", aura: "rgba(39,166,106,0.22)", particles: "confetti", ring: "#D7F2E5" },
  closed: { eye: "sleep", mouth: "M94 121q6 3 12 0", brow: 0, pose: "sleep", aura: "rgba(128,102,255,0.08)", particles: "zzz", ring: "#F1EEFB" },
  disconnected: { eye: "spiral", mouth: "M95 122q5 -4 10 1", brow: 4, pose: "idle", aura: "rgba(233,162,59,0.16)", particles: "none", bubble: "Feed offline", ring: "#FFF0D6" },
};

const STATE_COPY: Record<AnimeState, { title: string; body: string }> = {
  neutral: { title: "Range-bound session", body: "Index is holding inside its normal intraday band. Nothing urgent." },
  mildBull: { title: "Mild bullish drift", body: "Breadth leans positive and momentum is building slowly." },
  strongBull: { title: "Strong bullish tape", body: "Wide participation with index momentum above the daily average." },
  breakout: { title: "Breakout watch", body: "A tracked level or session high was just taken out." },
  mildBear: { title: "Soft tape", body: "Slight weakness — leaders are lagging the index." },
  strongBear: { title: "Defensive tape", body: "Breadth deteriorating and volatility picking up." },
  crash: { title: "Market shock", body: "Severe intraday move detected. Breadth and losers surfaced in the panel." },
  rally: { title: "Rally conditions", body: "Index advance is well above the normal session range." },
  closed: { title: "Market closed", body: "Session is shut. Reviewing the day's notes and alerts." },
  disconnected: { title: "Data disconnected", body: "No provider response. Cached prices are shown." },
};

function Eyes({ kind }: { kind: Expr["eye"] }) {
  const stroke = "#3B3550";
  if (kind === "happy")
    return (
      <g stroke={stroke} strokeWidth="2.4" fill="none" strokeLinecap="round">
        <path d="M80 96q5 -6 10 0" />
        <path d="M110 96q5 -6 10 0" />
      </g>
    );
  if (kind === "sleep")
    return (
      <g stroke={stroke} strokeWidth="2.2" fill="none" strokeLinecap="round">
        <path d="M79 97h11M110 97h11" />
      </g>
    );
  if (kind === "spiral")
    return (
      <g stroke={stroke} strokeWidth="1.6" fill="none">
        <path d="M85 96a4 4 0 100 1a3 3 0 100 1" />
        <path d="M115 96a4 4 0 100 1a3 3 0 100 1" />
      </g>
    );
  if (kind === "focus")
    return (
      <g className="anim-blink">
        <ellipse cx="85" cy="97" rx="4.4" ry="3.2" fill={stroke} />
        <ellipse cx="115" cy="97" rx="4.4" ry="3.2" fill={stroke} />
      </g>
    );
  const ry = kind === "wide" ? 6.4 : 5.4;
  return (
    <g className="anim-blink">
      <ellipse cx="85" cy="97" rx="4.6" ry={ry} fill={stroke} />
      <ellipse cx="115" cy="97" rx="4.6" ry={ry} fill={stroke} />
      <circle cx="86.6" cy="94.6" r="1.5" fill="#fff" />
      <circle cx="116.6" cy="94.6" r="1.5" fill="#fff" />
    </g>
  );
}

export function Companion({
  state,
  className,
  size = 176,
}: {
  state: AnimeState;
  className?: string;
  size?: number;
}) {
  const e = EXPR[state];
  const poseClass =
    e.pose === "bounce" ? "anim-bounce" : e.pose === "shake" ? "anim-shake" : e.pose === "sleep" ? "" : "anim-breathe";
  const tilt = e.pose === "hug" ? -3 : 0;

  return (
    <div className={cn("relative", className)} style={{ width: size }}>
      <svg viewBox="0 0 200 180" width={size} height={size * 0.9} className="overflow-visible">
        <defs>
          <linearGradient id="c-hair" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#8E76FF" />
            <stop offset="100%" stopColor="#6A55E8" />
          </linearGradient>
          <linearGradient id="c-hood" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#F3F0FF" />
          </linearGradient>
          <radialGradient id="c-aura">
            <stop offset="0%" stopColor={e.aura} />
            <stop offset="100%" stopColor="rgba(255,255,255,0)" />
          </radialGradient>
        </defs>

        <ellipse cx="100" cy="96" rx="86" ry="80" fill="url(#c-aura)" />

        <g className={poseClass} style={{ transformOrigin: "100px 150px", transform: `rotate(${tilt}deg)` }}>
          {/* hair back */}
          <path
            className="anim-hair"
            d="M60 76c0-24 18-40 40-40s40 16 40 40c0 20-4 34-4 48 0 8 3 14 3 18H61c0-4 3-10 3-18 0-14-4-28-4-48z"
            fill="url(#c-hair)"
          />
          {/* neck + body */}
          <path d="M92 116h16v14H92z" fill="#F6D9C8" />
          <path
            d="M64 178c0-22 16-40 36-40s36 18 36 40z"
            fill="url(#c-hood)"
            stroke="#E4DEFA"
            strokeWidth="2"
          />
          <path d="M100 138l-10 40h20z" fill="#EEE9FF" />
          {/* tablet */}
          <rect x="72" y="150" width="56" height="26" rx="5" fill="#18171C" />
          <rect x="76" y="154" width="48" height="18" rx="3" fill="#FAFAFC" />
          <path
            d="M80 167l8-6 6 3 7-7 6 4 9-8"
            fill="none"
            stroke={state === "crash" || state === "strongBear" ? "#E35D68" : state === "strongBull" || state === "rally" ? "#27A66A" : "#8066FF"}
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          {/* arm */}
          {e.pose === "point" ? (
            <g>
              <path d="M132 156c10-8 16-18 18-28" stroke="#F6D9C8" strokeWidth="9" strokeLinecap="round" fill="none" />
              <path d="M150 126l6-8" stroke="#F6D9C8" strokeWidth="9" strokeLinecap="round" fill="none" />
            </g>
          ) : e.pose === "hug" ? (
            <path d="M70 160c8 6 18 6 26 2" stroke="#F6D9C8" strokeWidth="9" strokeLinecap="round" fill="none" />
          ) : (
            <>
              <path d="M68 158c-4 6-4 12-2 16" stroke="#F6D9C8" strokeWidth="9" strokeLinecap="round" fill="none" />
              <path d="M132 156c4 6 4 12 2 16" stroke="#F6D9C8" strokeWidth="9" strokeLinecap="round" fill="none" />
            </>
          )}
          {/* face */}
          <path d="M72 68c0-16 12-28 28-28s28 12 28 28v26c0 16-12 28-28 28s-28-12-28-28z" fill="#FBDFCE" />
          <ellipse cx="78" cy="106" rx="6" ry="3.4" fill="#F8B7B7" opacity="0.75" />
          <ellipse cx="122" cy="106" rx="6" ry="3.4" fill="#F8B7B7" opacity="0.75" />
          {/* bangs */}
          <path
            d="M70 74c0-18 13-30 30-30s30 12 30 30c-6-8-12-10-18-8-4-8-12-10-20-6-6 3-14 6-22 14z"
            fill="url(#c-hair)"
          />
          {/* beret */}
          <path d="M64 56c4-18 22-26 38-24 16 2 28 12 30 24-12-6-24-8-34-6-12 2-24 4-34 6z" fill="#8066FF" />
          <circle cx="132" cy="44" r="4" fill="#EEE9FF" />
          {/* brows */}
          <g stroke="#4A4160" strokeWidth="1.8" strokeLinecap="round" fill="none">
            <path d={`M79 ${86 + e.brow}q6 -3 12 0`} />
            <path d={`M109 ${86 + e.brow}q6 -3 12 0`} />
          </g>
          <Eyes kind={e.eye} />
          <path d={e.mouth} stroke="#4A4160" strokeWidth="1.8" fill="none" strokeLinecap="round" />
          {/* sleep cup */}
          {e.pose === "sleep" && (
            <g>
              <rect x="140" y="150" width="16" height="14" rx="4" fill="#fff" stroke="#E4DEFA" strokeWidth="1.6" />
              <path d="M156 154c4 0 4 6 0 6" stroke="#E4DEFA" strokeWidth="1.6" fill="none" />
              <path d="M144 146q2 -3 0 -5M151 147q2 -3 0 -5" stroke="#C9C4DB" strokeWidth="1.4" fill="none" strokeLinecap="round" />
            </g>
          )}
        </g>
      </svg>

      {/* particles */}
      {e.particles === "up" && (
        <div className="pointer-events-none absolute inset-0">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="absolute text-pos"
              style={{
                left: `${30 + i * 22}%`,
                bottom: "18%",
                animation: `amos-rise 2.1s ease-out ${i * 0.5}s infinite`,
              }}
            >
              <svg width="14" height="14" viewBox="0 0 10 10" fill="currentColor"><path d="M5 1l4 7H1z" /></svg>
            </span>
          ))}
        </div>
      )}
      {e.particles === "down" && (
        <div className="pointer-events-none absolute inset-0">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="absolute text-neg"
              style={{
                left: `${34 + i * 20}%`,
                top: "22%",
                animation: `amos-fall 2s ease-in ${i * 0.45}s infinite`,
              }}
            >
              <svg width="14" height="14" viewBox="0 0 10 10" fill="currentColor"><path d="M5 9L1 2h8z" /></svg>
            </span>
          ))}
        </div>
      )}
      {e.particles === "spark" && (
        <div className="pointer-events-none absolute inset-0">
          {[0, 1, 2, 3].map((i) => (
            <span
              key={i}
              className="absolute text-info"
              style={{ left: `${28 + i * 16}%`, top: `${18 + (i % 2) * 10}%`, animation: `amos-rise 1.6s ease-out ${i * 0.22}s infinite` }}
            >
              <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor"><path d="M6 0l1.6 4.4L12 6l-4.4 1.6L6 12 4.4 7.6 0 6l4.4-1.6z" /></svg>
            </span>
          ))}
        </div>
      )}
      {e.particles === "confetti" && (
        <div className="pointer-events-none absolute inset-0">
          {[0, 1, 2, 3, 4].map((i) => (
            <span
              key={i}
              className="absolute h-1.5 w-1.5 rounded-[2px]"
              style={{
                left: `${24 + i * 14}%`,
                bottom: "20%",
                background: ["#27A66A", "#8066FF", "#E9A23B", "#6D72E8", "#27A66A"][i],
                animation: `amos-rise 1.9s ease-out ${i * 0.18}s infinite`,
              }}
            />
          ))}
        </div>
      )}
      {e.particles === "zzz" && (
        <div className="pointer-events-none absolute right-2 top-4 text-[13px] font-bold text-brand/70">
          {["z", "z", "z"].map((c, i) => (
            <span key={i} className="absolute" style={{ left: i * 9, top: -i * 11, animation: `amos-rise 3s ease-out ${i * 0.7}s infinite` }}>
              {c}
            </span>
          ))}
        </div>
      )}

      {e.bubble && (
        <div className="anim-pop absolute -top-1 right-0 rounded-[12px] rounded-br-[3px] border border-line bg-white px-2.5 py-1 text-[10.5px] font-semibold text-ink shadow-[var(--shadow-lift)]">
          {e.bubble}
        </div>
      )}
    </div>
  );
}

export function CompanionCard({
  state,
  score,
  onOpenSettings,
  minimized,
  onToggleMin,
}: {
  state: AnimeState;
  score: number;
  onOpenSettings?: () => void;
  minimized?: boolean;
  onToggleMin?: () => void;
}) {
  const copy = STATE_COPY[state];
  const off = state === "disconnected";
  const danger = state === "crash" || state === "strongBear";
  const good = state === "strongBull" || state === "rally" || state === "breakout";

  if (minimized)
    return (
      <button
        onClick={onToggleMin}
        className="flex w-full items-center justify-between rounded-[16px] border border-line bg-shell px-3 py-2 text-left shadow-[var(--shadow-soft)]"
      >
        <span className="flex items-center gap-2">
          <span className={cn("h-2 w-2 rounded-full", off ? "bg-warn" : danger ? "bg-neg" : good ? "bg-pos" : "bg-brand")} />
          <span className="text-[12px] font-semibold text-ink">{copy.title}</span>
        </span>
        <Icon name="chevronDown" size={14} className="text-ink3" />
      </button>
    );

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-[20px] border bg-shell p-4 shadow-[var(--shadow-soft)]",
        off ? "border-warn/40" : danger ? "border-neg/40" : "border-line",
      )}
    >
      <div className="mb-1 flex items-start justify-between">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.09em] text-ink3">Market companion</p>
          <h3 className="mt-0.5 font-display text-[15px] font-bold tracking-[-0.02em] text-ink">{copy.title}</h3>
        </div>
        <div className="flex items-center gap-1">
          {onOpenSettings && (
            <button onClick={onOpenSettings} className="rounded-full p-1 text-ink3 transition-colors hover:bg-muted hover:text-ink" aria-label="Companion settings">
              <Icon name="settings" size={14} />
            </button>
          )}
          {onToggleMin && (
            <button onClick={onToggleMin} className="rounded-full p-1 text-ink3 transition-colors hover:bg-muted hover:text-ink" aria-label="Minimize companion">
              <Icon name="chevronRight" size={14} />
            </button>
          )}
        </div>
      </div>

      <div className="flex items-end justify-center">
        <Companion state={state} size={168} />
      </div>

      <p className="mb-3 text-center text-[11.5px] leading-relaxed text-ink2">{copy.body}</p>

      <div className="rounded-[14px] bg-muted p-2.5">
        <div className="mb-1.5 flex items-center justify-between text-[10.5px]">
          <span className="font-semibold uppercase tracking-[0.07em] text-ink3">Market mood</span>
          <span className="tabnum font-bold text-ink">{score}/100</span>
        </div>
        <div className="relative h-1.5 overflow-hidden rounded-full bg-gradient-to-r from-neg via-warn to-pos">
          <span className="absolute top-1/2 h-3.5 w-[3px] -translate-y-1/2 rounded-full bg-ink shadow" style={{ left: `${score}%` }} />
        </div>
        <p className="mt-1.5 text-[9.5px] leading-tight text-ink3">
          Custom visualisation built from index change, breadth, volatility and momentum. Not a prediction.
        </p>
      </div>
    </div>
  );
}

/** Small floating companion used on the Pro Chart screen. */
export function FloatingCompanion({ state, hidden }: { state: AnimeState; hidden: boolean }) {
  const [tip, setTip] = useState(false);
  const copy = STATE_COPY[state];
  useEffect(() => {
    const t = window.setTimeout(() => setTip(true), 900);
    const t2 = window.setTimeout(() => setTip(false), 4200);
    return () => {
      window.clearTimeout(t);
      window.clearTimeout(t2);
    };
  }, [state]);
  if (hidden) return null;
  return (
    <div className="pointer-events-none absolute bottom-2 right-2 z-20">
      <div className="relative">
        {tip && (
          <div className="anim-pop absolute bottom-3 right-[86%] w-[188px] rounded-[12px] border border-line bg-white/95 px-2.5 py-2 text-[10.5px] leading-snug text-ink2 shadow-[var(--shadow-lift)] backdrop-blur">
            <span className="mb-0.5 block text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">{copy.title}</span>
            {copy.body}
          </div>
        )}
        <div className="rounded-full bg-white/80 p-1 shadow-[var(--shadow-soft)] backdrop-blur">
          <Companion state={state} size={78} />
        </div>
      </div>
    </div>
  );
}

export function useAnimeStates() {
  return useMemo(() => Object.keys(EXPR) as AnimeState[], []);
}
