import { useMemo, useState } from "react";
import { actions, useApp, useTick } from "../lib/store";
import {
  BY_SYMBOL,
  INDICES,
  IN_STOCKS,
  US_STOCKS,
  breadth,
  fmtCompact,
  fmtSigned,
  fmtVol,
  getSeries,
  marketMood,
  moodLabel,
  movers,
  quote,
  session,
  sparkline,
} from "../lib/marketData";
import { useCorrelationMatrix, usePortfolio } from "../lib/portfolio";
import { atr, closes, correlation, ema, maxDrawdown, returns, rsi, sma, sharpe } from "../lib/indicators";
import { AreaChart, BreadthCard, Donut, Heatmap, IndexCard, MoversList, RadialGauge, SectorBars, WatchlistTable } from "../components/market/widgets";
import { Badge, Card, CardHead, Delta, EmptyState, GhostButton, Icon, Input, Pill, PrimaryButton, Segmented, Select, Sparkline } from "../components/ui/primitives";
import { ScreenHead } from "./Overview";
import { cn } from "../utils/cn";
import type { Region } from "../lib/types";

const universe = (r: Region) => (r === "IN" ? IN_STOCKS : US_STOCKS);

/* ================================================================== *
 * MARKETS
 * ================================================================== */
export function Markets() {
  useTick();
  const s = useApp();
  const region = s.settings.region;
  const mv = movers(region, 8);
  const b = breadth(region);
  const mood = marketMood(region);

  return (
    <div className="anim-page space-y-4">
      <ScreenHead
        title="Markets"
        sub={`${region === "IN" ? "NSE · BSE" : "NYSE · Nasdaq · AMEX"} live snapshot · ${session(region).label}`}
        right={
          <Segmented
            value={region}
            onChange={(r) => actions.setSettings({ region: r })}
            options={[
              { value: "IN", label: "India" },
              { value: "US", label: "USA" },
            ]}
          />
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {INDICES[region].map((sym) => (
          <IndexCard key={sym} symbol={sym} />
        ))}
      </div>

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_minmax(0,1fr)]">
        <Card>
          <CardHead title="Index performance" sub={BY_SYMBOL[INDICES[region][0]].name} icon="markets" />
          <AreaChart data={sparkline(INDICES[region][0], 60)} height={172} baseline={quote(INDICES[region][0]).previousClose} />
        </Card>
        <Card>
          <CardHead title="Market breadth" sub="Universe advances / declines" icon="wave" />
          <BreadthCard region={region} />
        </Card>
        <Card>
          <CardHead title="Market mood" sub="Custom composite score" icon="spark" />
          <div className="flex items-center gap-4">
            <RadialGauge value={mood} label={moodLabel(mood).label} size={112} />
            <div className="space-y-1.5 text-[11.5px]">
              <p className="flex justify-between gap-3"><span className="text-ink3">Advancing</span><span className="tabnum font-semibold text-pos">{b.adv}</span></p>
              <p className="flex justify-between gap-3"><span className="text-ink3">Declining</span><span className="tabnum font-semibold text-neg">{b.dec}</span></p>
              <p className="flex justify-between gap-3"><span className="text-ink3">A/D ratio</span><span className="tabnum font-semibold text-ink">{b.ratio.toFixed(2)}</span></p>
              <p className="flex justify-between gap-3"><span className="text-ink3">Volatility</span><span className="tabnum font-semibold text-ink">{quote(region === "IN" ? "INDIAVIX" : "VIX").price.toFixed(2)}</span></p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,1.2fr)]">
        <Card>
          <CardHead title="Top gainers" sub="Intraday leaders" icon="trendUp" />
          <MoversList items={mv.gainers} kind="gain" />
        </Card>
        <Card>
          <CardHead title="Top losers" sub="Intraday laggards" icon="trendDown" />
          <MoversList items={mv.losers} kind="lose" />
        </Card>
        <Card>
          <CardHead title="Quick heatmap" sub="Equal weight, 1D change" icon="heatmap" right={<GhostButton onClick={() => actions.navigate("heatmap")}>Full heatmap</GhostButton>} />
          <Heatmap symbols={universe(region).map((i) => i.symbol).slice(0, 18)} cols={6} />
        </Card>
      </div>

      <Card>
        <CardHead title="Universe" sub={`${universe(region).length} instruments · live quotes`} icon="database" />
        <div className="overflow-x-auto">
          <table className="w-full min-w-[620px]">
            <thead>
              <tr className="border-b border-line text-left text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">
                <th className="pb-2">Symbol</th>
                <th className="pb-2">Sector</th>
                <th className="pb-2 text-right">LTP</th>
                <th className="pb-2 text-right">Chg%</th>
                <th className="pb-2 text-right">Volume</th>
                <th className="pb-2 text-right">Mkt cap</th>
                <th className="pb-2 text-right">P/E</th>
                <th className="pb-2 text-right">Trend</th>
              </tr>
            </thead>
            <tbody>
              {universe(region).map((i) => {
                const q = quote(i.symbol);
                return (
                  <tr key={i.symbol} className="border-b border-line/60 transition-colors last:border-0 hover:bg-subtle">
                    <td className="py-2">
                      <button onClick={() => actions.openSymbol(i.symbol, "chart")} className="text-left">
                        <span className="block text-[12px] font-semibold text-ink">{i.symbol}</span>
                        <span className="block text-[10px] text-ink3">{i.name}</span>
                      </button>
                    </td>
                    <td className="text-[11.5px] text-ink2">{i.sector}</td>
                    <td className="tabnum text-right text-[12px] font-semibold text-ink">{q.price.toFixed(2)}</td>
                    <td className="text-right"><Delta value={q.changePercent} size="xs" arrow={false} /></td>
                    <td className="tabnum text-right text-[11.5px] text-ink2">{fmtVol(q.volume)}</td>
                    <td className="tabnum text-right text-[11.5px] text-ink2">{fmtCompact(i.mcap, i.currency)}</td>
                    <td className="tabnum text-right text-[11.5px] text-ink2">{i.pe?.toFixed(1) ?? "—"}</td>
                    <td className="text-right">
                      <span className="inline-block align-middle">
                        <SparkCell symbol={i.symbol} />
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function SparkCell({ symbol }: { symbol: string }) {
  const data = sparkline(symbol, 24);
  const up = data[data.length - 1] >= data[0];
  return <Sparkline data={data} width={64} height={24} strokeWidth={1.4} positive={up} />;
}

/* ================================================================== *
 * WATCHLISTS
 * ================================================================== */
export function Watchlists() {
  useTick();
  const s = useApp();
  const [newSym, setNewSym] = useState("");
  const [newList, setNewList] = useState("");
  const wl = s.watchlists.find((w) => w.id === s.activeWatchlist) ?? s.watchlists[0];
  const [dragIdx, setDragIdx] = useState<number | null>(null);

  return (
    <div className="anim-page space-y-4">
      <ScreenHead
        title="Watchlists"
        sub={`${s.watchlists.length} lists · stored locally on this device`}
        right={
          <Segmented
            value={s.settings.density}
            onChange={(d) => actions.setSettings({ density: d })}
            options={[
              { value: "compact", label: "Compact" },
              { value: "comfortable", label: "Comfortable" },
            ]}
          />
        }
      />
      <div className="grid gap-3 xl:grid-cols-[236px_minmax(0,1fr)]">
        <Card className="h-fit">
          <CardHead title="Lists" icon="watchlist" />
          <div className="space-y-1">
            {s.watchlists.map((w) => (
              <button
                key={w.id}
                onClick={() => actions.setActiveWatchlist(w.id)}
                className={cn(
                  "flex w-full items-center gap-2 rounded-[12px] px-2.5 py-2 text-left transition-colors",
                  w.id === wl?.id ? "bg-brandsoft" : "hover:bg-muted",
                )}
              >
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: w.color }} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12px] font-semibold text-ink">{w.name}</span>
                  <span className="block text-[10px] text-ink3">{w.symbols.length} symbols · {w.region}</span>
                </span>
                {w.id !== s.watchlists[0].id && (
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      actions.deleteWatchlist(w.id);
                    }}
                    className="text-ink3 hover:text-neg"
                  >
                    <Icon name="trash" size={12} />
                  </span>
                )}
              </button>
            ))}
          </div>
          <div className="mt-3 flex gap-1.5 border-t border-line pt-3">
            <Input value={newList} onChange={(e) => setNewList(e.target.value)} placeholder="New list name" className="py-1.5 text-[12px]" />
            <PrimaryButton
              onClick={() => {
                if (newList.trim()) {
                  actions.addWatchlist(newList.trim(), s.settings.region);
                  setNewList("");
                }
              }}
            >
              <Icon name="plus" size={13} />
            </PrimaryButton>
          </div>
        </Card>

        <Card>
          <CardHead
            title={wl?.name ?? "Watchlist"}
            sub={`${wl?.symbols.length ?? 0} instruments · ${session(s.settings.region).label}`}
            icon="layers"
            right={
              <>
                <GhostButton onClick={() => actions.navigate("chart")}>Open pro chart</GhostButton>
                <GhostButton onClick={() => actions.navigate("screener")}>Screen market</GhostButton>
              </>
            }
          />
          <div className="mb-3 flex gap-2">
            <Input
              value={newSym}
              onChange={(e) => setNewSym(e.target.value.toUpperCase())}
              onKeyDown={(e) => {
                if (e.key === "Enter" && BY_SYMBOL[newSym]) {
                  actions.addToWatchlist(wl.id, newSym);
                  setNewSym("");
                }
              }}
              placeholder="Add symbol (e.g. TCS, NVDA) and press Enter"
              className="text-[12.5px]"
            />
            <PrimaryButton
              onClick={() => {
                if (BY_SYMBOL[newSym]) {
                  actions.addToWatchlist(wl.id, newSym);
                  setNewSym("");
                }
              }}
            >
              <Icon name="plus" size={13} /> Add
            </PrimaryButton>
          </div>
          <WatchlistTable symbols={wl?.symbols ?? []} watchlistId={wl?.id} />
          <div className="mt-3 flex flex-wrap gap-1.5 border-t border-line pt-3">
            {(wl?.symbols ?? []).map((sym, i) => (
              <span
                key={sym}
                draggable
                onDragStart={() => setDragIdx(i)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => {
                  if (dragIdx !== null && dragIdx !== i) actions.moveSymbol(wl.id, dragIdx, i);
                  setDragIdx(null);
                }}
                className="flex cursor-grab items-center gap-1 rounded-full border border-line bg-shell px-2 py-1 text-[11px] font-medium text-ink2"
              >
                <Icon name="grip" size={11} className="text-ink3" />
                {sym}
              </span>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ================================================================== *
 * SCREENER
 * ================================================================== */
interface Filters {
  rsiMin: number;
  rsiMax: number;
  relVol: number;
  chgMin: number;
  aboveSMA50: boolean;
  aboveEMA21: boolean;
  peMax: number;
  mcapMin: number;
  region: Region;
}

const SAVED: { id: string; name: string; filters: Partial<Filters> }[] = [
  { id: "s1", name: "Momentum Breakout", filters: { rsiMin: 60, rsiMax: 100, relVol: 1.4, aboveSMA50: true, chgMin: 0.5 } },
  { id: "s2", name: "Oversold Quality", filters: { rsiMin: 0, rsiMax: 38, peMax: 40, aboveSMA50: false } },
  { id: "s3", name: "High Volume Movers", filters: { relVol: 1.8, chgMin: 1 } },
  { id: "s4", name: "Long-Term Trend", filters: { aboveSMA50: true, aboveEMA21: true, peMax: 45 } },
  { id: "s5", name: "Low Volatility Compounders", filters: { peMax: 35, mcapMin: 300000 } },
  { id: "s6", name: "Earnings Watch", filters: { chgMin: 2 } },
];

export function Screener() {
  useTick();
  const s = useApp();
  const [f, setF] = useState<Filters>({ rsiMin: 0, rsiMax: 100, relVol: 0, chgMin: -100, aboveSMA50: false, aboveEMA21: false, peMax: 500, mcapMin: 0, region: s.settings.region });
  const [activeSaved, setActiveSaved] = useState("s1");

  const results = useMemo(() => {
    return universe(f.region)
      .map((i) => {
        const series = getSeries(i.symbol, "1D", 120);
        const src = closes(series);
        const r = rsi(src, 14);
        const rsiVal = (r[r.length - 1] as number) ?? 50;
        const sma50 = (sma(src, 50)[src.length - 1] as number) ?? src[src.length - 1];
        const ema21 = (ema(src, 21)[src.length - 1] as number) ?? src[src.length - 1];
        const q = quote(i.symbol);
        const relVol = q.avgVolume ? q.volume / q.avgVolume : 1;
        return { i, q, rsiVal, sma50, ema21, relVol, atr: (atr(series, 14)[src.length - 1] as number) ?? 0 };
      })
      .filter((x) => {
        if (x.rsiVal < f.rsiMin || x.rsiVal > f.rsiMax) return false;
        if (x.relVol < f.relVol) return false;
        if (x.q.changePercent < f.chgMin) return false;
        if (f.aboveSMA50 && x.q.price < x.sma50) return false;
        if (f.aboveEMA21 && x.q.price < x.ema21) return false;
        if ((x.i.pe ?? 999) > f.peMax) return false;
        if (x.i.mcap < f.mcapMin) return false;
        return true;
      })
      .sort((a, b) => b.q.changePercent - a.q.changePercent);
  }, [f]);

  return (
    <div className="anim-page space-y-4">
      <ScreenHead title="Screener" sub="Technical + fundamental filters across the live universe" right={<Badge tone="brand">{results.length} matches</Badge>} />

      <div className="grid gap-3 xl:grid-cols-[260px_minmax(0,1fr)]">
        <div className="space-y-3">
          <Card>
            <CardHead title="Saved screens" icon="filter" />
            <div className="space-y-1">
              {SAVED.map((sv) => (
                <button
                  key={sv.id}
                  onClick={() => {
                    setActiveSaved(sv.id);
                    setF((prev) => ({ ...prev, ...sv.filters }));
                  }}
                  className={cn(
                    "flex w-full items-center justify-between rounded-[12px] px-2.5 py-1.5 text-left text-[12px] transition-colors",
                    activeSaved === sv.id ? "bg-brandsoft text-brand" : "text-ink2 hover:bg-muted",
                  )}
                >
                  {sv.name}
                  <Icon name="chevronRight" size={12} />
                </button>
              ))}
            </div>
          </Card>

          <Card>
            <CardHead title="Filters" icon="sliders" right={<GhostButton onClick={() => setF({ rsiMin: 0, rsiMax: 100, relVol: 0, chgMin: -100, aboveSMA50: false, aboveEMA21: false, peMax: 500, mcapMin: 0, region: f.region })}>Reset</GhostButton>} />
            <div className="space-y-3">
              <Select
                value={f.region}
                onChange={(v) => setF({ ...f, region: v as Region })}
                options={[
                  { value: "IN", label: "India (NSE/BSE)" },
                  { value: "US", label: "USA (NYSE/Nasdaq)" },
                ]}
              />
              <Range label="RSI (14)" min={f.rsiMin} max={f.rsiMax} onChange={(a, b) => setF({ ...f, rsiMin: a, rsiMax: b })} />
              <Slider label="Min relative volume" value={f.relVol} min={0} max={3} step={0.1} onChange={(v) => setF({ ...f, relVol: v })} suffix="×" />
              <Slider label="Min change %" value={f.chgMin} min={-5} max={8} step={0.5} onChange={(v) => setF({ ...f, chgMin: v })} suffix="%" />
              <Slider label="Max P/E" value={f.peMax} min={5} max={500} step={5} onChange={(v) => setF({ ...f, peMax: v })} />
              <Slider label="Min market cap" value={f.mcapMin} min={0} max={1000000} step={50000} onChange={(v) => setF({ ...f, mcapMin: v })} />
              <div className="space-y-1">
                <Pill active={f.aboveSMA50} onClick={() => setF({ ...f, aboveSMA50: !f.aboveSMA50 })}>
                  Price &gt; SMA 50
                </Pill>
                <Pill active={f.aboveEMA21} onClick={() => setF({ ...f, aboveEMA21: !f.aboveEMA21 })} className="ml-1">
                  Price &gt; EMA 21
                </Pill>
              </div>
            </div>
          </Card>
        </div>

        <Card>
          <CardHead title="Results" sub="Ranked by intraday performance" icon="screener" />
          <div className="overflow-x-auto">
            <table className="w-full min-w-[680px]">
              <thead>
                <tr className="border-b border-line text-left text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">
                  <th className="pb-2">Symbol</th>
                  <th className="pb-2 text-right">LTP</th>
                  <th className="pb-2 text-right">Chg%</th>
                  <th className="pb-2 text-right">RSI</th>
                  <th className="pb-2 text-right">Rel vol</th>
                  <th className="pb-2 text-right">vs SMA50</th>
                  <th className="pb-2 text-right">ATR%</th>
                  <th className="pb-2 text-right">P/E</th>
                  <th className="pb-2 text-right">Signals</th>
                </tr>
              </thead>
              <tbody>
                {results.map(({ i, q, rsiVal, sma50, relVol, atr }) => (
                  <tr key={i.symbol} className="border-b border-line/60 transition-colors last:border-0 hover:bg-subtle">
                    <td className="py-2">
                      <button onClick={() => actions.openSymbol(i.symbol, "chart")} className="text-left">
                        <span className="block text-[12px] font-semibold text-ink">{i.symbol}</span>
                        <span className="block text-[10px] text-ink3">{i.sector}</span>
                      </button>
                    </td>
                    <td className="tabnum text-right text-[12px] font-semibold text-ink">{q.price.toFixed(2)}</td>
                    <td className="text-right"><Delta value={q.changePercent} size="xs" arrow={false} /></td>
                    <td className={cn("tabnum text-right text-[11.5px] font-semibold", rsiVal > 70 ? "text-neg" : rsiVal < 30 ? "text-pos" : "text-ink2")}>{rsiVal.toFixed(0)}</td>
                    <td className="tabnum text-right text-[11.5px] text-ink2">{relVol.toFixed(2)}×</td>
                    <td className="tabnum text-right text-[11.5px] text-ink2">{fmtSigned(((q.price - sma50) / sma50) * 100)}%</td>
                    <td className="tabnum text-right text-[11.5px] text-ink2">{((atr / q.price) * 100).toFixed(2)}%</td>
                    <td className="tabnum text-right text-[11.5px] text-ink2">{i.pe?.toFixed(1) ?? "—"}</td>
                    <td className="py-1.5 text-right">
                      <span className="flex flex-wrap justify-end gap-1">
                        {rsiVal > 65 && <Badge tone="neg">Overbought</Badge>}
                        {rsiVal < 35 && <Badge tone="pos">Oversold</Badge>}
                        {relVol > 1.5 && <Badge tone="warn">Vol spike</Badge>}
                        {q.price > sma50 && <Badge tone="brand">Uptrend</Badge>}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {results.length === 0 && <EmptyState title="No instruments match" body="Loosen a filter or reset the screen to see the full universe." icon="filter" />}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  suffix = "",
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  suffix?: string;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[11px]">
        <span className="font-medium text-ink2">{label}</span>
        <span className="tabnum font-semibold text-ink">
          {value}
          {suffix}
        </span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(+e.target.value)} className="w-full accent-[#8066FF]" />
    </div>
  );
}

function Range({ label, min, max, onChange }: { label: string; min: number; max: number; onChange: (a: number, b: number) => void }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[11px]">
        <span className="font-medium text-ink2">{label}</span>
        <span className="tabnum font-semibold text-ink">
          {min} – {max}
        </span>
      </div>
      <div className="flex items-center gap-2">
        <input type="range" min={0} max={100} value={min} onChange={(e) => onChange(Math.min(+e.target.value, max), max)} className="w-full accent-[#8066FF]" />
        <input type="range" min={0} max={100} value={max} onChange={(e) => onChange(min, Math.max(+e.target.value, min))} className="w-full accent-[#8066FF]" />
      </div>
    </div>
  );
}

/* ================================================================== *
 * HEATMAP
 * ================================================================== */
export function HeatmapScreen() {
  useTick();
  const s = useApp();
  const region = s.settings.region;
  const [metric, setMetric] = useState<"changePercent" | "relvol">("changePercent");
  const [sector, setSector] = useState("All");
  const [cols, setCols] = useState(7);
  const sectors = ["All", ...new Set(universe(region).map((i) => i.sector))];
  const syms = universe(region).filter((i) => sector === "All" || i.sector === sector).map((i) => i.symbol);

  return (
    <div className="anim-page space-y-4">
      <ScreenHead
        title="Market heatmap"
        sub="Tile colour = performance · tile size weight = market cap bucket"
        right={
          <>
            <Select
              value={sector}
              onChange={setSector}
              options={sectors.map((x) => ({ value: x, label: x }))}
              className="w-[170px]"
            />
            <Segmented value={metric} onChange={setMetric} options={[{ value: "changePercent", label: "1D change" }, { value: "relvol", label: "Rel. volume" }]} />
            <Segmented value={String(cols)} onChange={(v) => setCols(+v)} options={[5, 6, 7, 8].map((n) => ({ value: String(n), label: `${n}` }))} />
          </>
        }
      />
      <Card>
        <CardHead title={`${region === "IN" ? "India" : "United States"} equity heatmap`} sub={`${syms.length} instruments · ${sector}`} icon="heatmap" />
        <Heatmap symbols={syms} metric={metric} cols={cols} />
      </Card>
      <div className="grid gap-3 lg:grid-cols-3">
        <Card>
          <CardHead title="Sector leaders" icon="flame" />
          <SectorBars region={region} limit={9} />
        </Card>
        <Card>
          <CardHead title="Breadth" icon="wave" />
          <BreadthCard region={region} />
        </Card>
        <Card>
          <CardHead title="Index cards" icon="markets" />
          <div className="grid grid-cols-2 gap-2">
            {INDICES[region].map((i) => (
              <IndexCard key={i} symbol={i} />
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ================================================================== *
 * COMPARE LAB
 * ================================================================== */
export function Compare() {
  useTick();
  const s = useApp();
  const [syms, setSyms] = useState<string[]>(s.compareSymbols.length ? s.compareSymbols : ["RELIANCE", "TCS", "NIFTY50"]);
  const [mode, setMode] = useState<"normalized" | "raw" | "returns" | "risk" | "corr">("normalized");
  const [add, setAdd] = useState("");

  const data = useMemo(() => {
    const series = syms.map((sym) => {
      const c = getSeries(sym, "1D", 200).map((x) => x.close);
      return { sym, closes: c };
    });
    const rets = series.map((x) => returns(x.closes));
    return { series, rets };
  }, [syms.join("|")]); // eslint-disable-line react-hooks/exhaustive-deps

  const colors = ["#8066FF", "#27A66A", "#E9A23B", "#E35D68", "#6D72E8", "#0EA5A5"];

  const normalized = useMemo(() => {
    if (!data.series.length) return [];
    const len = Math.min(...data.series.map((x) => x.closes.length));
    const rows: number[][] = [];
    for (let i = 0; i < len; i++) {
      const row = data.series.map((x) => (x.closes[x.closes.length - len] ? (x.closes[i + x.closes.length - len] / x.closes[x.closes.length - len]) * 100 : 100));
      rows.push(row);
    }
    return rows;
  }, [data]);

  const stats = syms.map((sym, i) => {
    const c = data.series[i].closes;
    const q = quote(sym);
    return {
      symbol: sym,
      ret: ((c[c.length - 1] / c[c.length - 61] - 1) * 100).toFixed(2),
      vol: (sharpe(c) || 0).toFixed(2),
      mdd: maxDrawdown(c).toFixed(1),
      rsi: ((rsi(closes(getSeries(sym, "1D", 100)), 14).slice(-1)[0] as number) ?? 50).toFixed(0),
      price: q.price,
      chg: q.changePercent,
    };
  });

  const matrix = useCorrelationMatrix(syms, 120);

  return (
    <div className="anim-page space-y-4">
      <ScreenHead
        title="Compare lab"
        sub="2–6 instruments · normalised performance, risk and correlation"
        right={
          <div className="flex items-center gap-1.5">
            <Input value={add} onChange={(e) => setAdd(e.target.value.toUpperCase())} placeholder="Add symbol" className="w-[150px] py-1.5 text-[12px]" />
            <PrimaryButton
              onClick={() => {
                if (BY_SYMBOL[add] && !syms.includes(add) && syms.length < 6) setSyms([...syms, add]);
                setAdd("");
              }}
            >
              <Icon name="plus" size={13} /> Add
            </PrimaryButton>
          </div>
        }
      />

      <div className="flex flex-wrap items-center gap-1.5">
        {syms.map((sym, i) => (
          <span key={sym} className="flex items-center gap-1.5 rounded-full border border-line bg-shell px-2.5 py-1 text-[11.5px] font-semibold text-ink">
            <span className="h-2 w-2 rounded-full" style={{ background: colors[i % colors.length] }} />
            {sym}
            <button onClick={() => setSyms(syms.filter((x) => x !== sym))} className="text-ink3 hover:text-neg" aria-label={`Remove ${sym}`}>
              <Icon name="close" size={11} />
            </button>
          </span>
        ))}
        {syms.length < 2 && <span className="text-[11.5px] text-ink3">Add at least two symbols to compare.</span>}
      </div>

      <Segmented
        value={mode}
        onChange={setMode}
        options={[
          { value: "normalized", label: "Normalised" },
          { value: "raw", label: "Raw price" },
          { value: "returns", label: "Returns" },
          { value: "risk", label: "Risk" },
          { value: "corr", label: "Correlation" },
        ]}
      />

      <Card>
        {mode === "normalized" && (
          <>
            <CardHead title="Normalised performance" sub="Rebased to 100 across the window" icon="compare" />
            <MultiLine rows={normalized} labels={syms} colors={colors} height={260} />
          </>
        )}
        {mode === "raw" && (
          <div className="grid gap-3 md:grid-cols-2">
            {syms.map((sym, i) => (
              <div key={sym} className="rounded-[16px] border border-line p-3">
                <div className="mb-1 flex items-center justify-between">
                  <p className="text-[12.5px] font-bold text-ink">{sym}</p>
                  <Delta value={quote(sym).changePercent} size="xs" />
                </div>
                <AreaChart data={getSeries(sym, "1D", 120).map((c) => c.close)} height={120} color={colors[i % colors.length]} />
              </div>
            ))}
          </div>
        )}
        {mode === "returns" && (
          <Table
            head={["Symbol", "LTP", "1D %", "60D %", "RSI", "Sharpe", "Max DD %"]}
            rows={stats.map((st) => [st.symbol, st.price.toFixed(2), fmtSigned(st.chg), st.ret, st.rsi, st.vol, st.mdd])}
          />
        )}
        {mode === "risk" && (
          <div className="grid gap-3 md:grid-cols-2">
            <Card>
              <CardHead title="Volatility vs return" sub="60-day window" icon="gauge" />
              <div className="space-y-2">
                {stats.map((st, i) => (
                  <div key={st.symbol} className="flex items-center gap-2">
                    <span className="w-[74px] text-[11.5px] font-semibold text-ink2">{st.symbol}</span>
                    <span className="relative h-2 flex-1 rounded-full bg-muted">
                      <span className="absolute inset-y-0 left-0 rounded-full" style={{ width: `${Math.min(100, Math.abs(+st.mdd) * 4)}%`, background: colors[i % colors.length] }} />
                    </span>
                    <span className="tabnum w-[60px] text-right text-[11px] text-ink2">{st.mdd}%</span>
                  </div>
                ))}
              </div>
            </Card>
            <Card>
              <CardHead title="Contribution" sub="Portfolio mix of compared names" icon="portfolio" />
              <Donut items={syms.map((sym, i) => ({ label: sym, value: 1 + Math.abs(Math.sin(i + 1)), color: colors[i % colors.length] }))} size={128} />
            </Card>
          </div>
        )}
        {mode === "corr" && (
          <div className="overflow-x-auto">
            <table className="min-w-[420px]">
              <thead>
                <tr>
                  <th />
                  {syms.map((sym) => (
                    <th key={sym} className="px-2 pb-2 text-[10.5px] font-bold uppercase tracking-[0.06em] text-ink3">
                      {sym}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {matrix.map((row, i) => (
                  <tr key={syms[i]}>
                    <td className="pr-3 text-right text-[11px] font-semibold text-ink2">{syms[i]}</td>
                    {row.map((v, j) => (
                      <td key={j} className="p-1">
                        <div
                          className="tabnum flex h-11 items-center justify-center rounded-[10px] text-[11.5px] font-bold text-ink"
                          style={{ background: `rgba(128,102,255,${Math.max(0.06, (v + 1) / 2 * 0.55)})` }}
                        >
                          {v.toFixed(2)}
                        </div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-2 text-[10.5px] text-ink3">Pearson correlation of daily returns, 120-day window. Values near 1 move together; near 0 are uncorrelated.</p>
          </div>
        )}
      </Card>
    </div>
  );
}

function MultiLine({ rows, labels, colors, height = 240 }: { rows: number[][]; labels: string[]; colors: string[]; height?: number }) {
  const W = 700;
  const len = rows.length;
  if (!len) return null;
  const all = rows.flat();
  const min = Math.min(...all);
  const max = Math.max(...all);
  const y = (v: number) => height - 24 - ((v - min) / (max - min || 1)) * (height - 40);
  return (
    <svg viewBox={`0 0 ${W} ${height}`} className="w-full" style={{ height }} preserveAspectRatio="none">
      {[0.2, 0.4, 0.6, 0.8].map((f) => (
        <line key={f} x1="0" x2={W} y1={(height - 24) * f} y2={(height - 24) * f} stroke="#F1EFF6" />
      ))}
      {labels.map((_, si) => (
        <path
          key={si}
          d={rows.map((r, i) => `${i === 0 ? "M" : "L"}${(i / (len - 1)) * W},${y(r[si])}`).join(" ")}
          fill="none"
          stroke={colors[si % colors.length]}
          strokeWidth="2"
          vectorEffect="non-scaling-stroke"
        />
      ))}
      <text x="4" y="12" className="fill-[#A4A2AB]" style={{ fontSize: 10 }}>
        {max.toFixed(0)}
      </text>
      <text x="4" y={height - 4} className="fill-[#A4A2AB]" style={{ fontSize: 10 }}>
        {min.toFixed(0)}
      </text>
    </svg>
  );
}

function Table({ head, rows }: { head: string[]; rows: (string | number)[][] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[560px]">
        <thead>
          <tr className="border-b border-line text-left text-[10px] font-bold uppercase tracking-[0.07em] text-ink3">
            {head.map((h, i) => (
              <th key={h} className={cn("pb-2", i > 0 && "text-right")}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-line/60 last:border-0">
              {r.map((c, j) => (
                <td key={j} className={cn("py-2 text-[12px]", j === 0 ? "font-semibold text-ink" : "tabnum text-right text-ink2")}>
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ================================================================== *
 * STOCK DETAIL
 * ================================================================== */
export function StockDetail() {
  useTick();
  const s = useApp();
  const symbol = s.symbol;
  const inst = BY_SYMBOL[symbol];
  const q = quote(symbol);
  const pf = usePortfolio(s.transactions);
  const holding = pf.holdings.find((h) => h.symbol === symbol);
  const day = getSeries(symbol, "1D", 200);

  return (
    <div className="anim-page space-y-4">
      <ScreenHead
        title={`${symbol} · ${inst?.name ?? ""}`}
        sub={`${inst?.exchange} · ${inst?.sector} · ${session(inst?.region ?? "IN").label}`}
        right={
          <>
            <GhostButton onClick={() => actions.toggleFavorite(symbol)}>
              <Icon name="star" size={12} className={s.favorites.includes(symbol) ? "text-warn" : ""} />
              {s.favorites.includes(symbol) ? "Starred" : "Star"}
            </GhostButton>
            <PrimaryButton onClick={() => actions.navigate("chart")}>Open pro chart</PrimaryButton>
          </>
        }
      />

      <div className="grid gap-3 xl:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <Card>
          <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="tabnum font-display text-[30px] font-extrabold leading-none tracking-[-0.03em] text-ink">{q.price.toFixed(2)}</p>
              <div className="mt-2 flex items-center gap-2">
                <Delta value={q.changePercent} size="sm" showAbs abs={q.change} />
                <span className="text-[11px] text-ink3">{inst?.currency} · live</span>
              </div>
            </div>
            <div className="text-right text-[11px] text-ink3">
              <p>52w high {(Math.max(...day.map((c) => c.high)) * 1.05).toFixed(2)}</p>
              <p>52w low {(Math.min(...day.map((c) => c.low)) * 0.82).toFixed(2)}</p>
              <p>Avg vol {fmtVol(q.avgVolume)}</p>
            </div>
          </div>
          <AreaChart data={sparkline(symbol, 120)} height={214} baseline={q.previousClose} color={q.changePercent >= 0 ? "#27A66A" : "#E35D68"} />
          <div className="mt-3 grid grid-cols-2 gap-x-6 gap-y-2 border-t border-line pt-3 md:grid-cols-5">
            {[
              ["Open", q.open],
              ["High", q.high],
              ["Low", q.low],
              ["Prev close", q.previousClose],
              ["Volume", fmtVol(q.volume)],
              ["Mkt cap", fmtCompact(inst?.mcap ?? 0, inst?.currency ?? "USD")],
              ["P/E", inst?.pe ?? "—"],
              ["EPS", inst?.eps ?? "—"],
              ["Beta", inst?.beta ?? "—"],
              ["Div yield", inst?.divYield ? `${inst.divYield}%` : "—"],
            ].map(([k, v]) => (
              <div key={k as string}>
                <p className="text-[10.5px] text-ink3">{k}</p>
                <p className="tabnum text-[13px] font-semibold text-ink">{typeof v === "number" ? v.toLocaleString("en-US", { maximumFractionDigits: 2 }) : v}</p>
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-3">
          {holding && (
            <Card>
              <CardHead title="Your position" sub={`${holding.qty} shares · avg ${holding.avgPrice.toFixed(2)}`} icon="portfolio" />
              <div className="grid grid-cols-2 gap-2">
                <MiniStat label="Market value" value={fmtCompact(holding.value, holding.currency)} />
                <MiniStat label="Unrealised" value={fmtSigned(holding.pnl)} tone={holding.pnl >= 0 ? "pos" : "neg"} />
                <MiniStat label="Return" value={`${fmtSigned(holding.pnlPct)}%`} tone={holding.pnl >= 0 ? "pos" : "neg"} />
                <MiniStat label="Weight" value={`${holding.weight.toFixed(1)}%`} />
              </div>
            </Card>
          )}
          <Card>
            <CardHead title="Financial snapshot" sub="Provider fundamentals" icon="database" />
            <div className="grid grid-cols-2 gap-2">
              <MiniStat label="Revenue growth" value={inst?.revGrowth ? `${inst.revGrowth}%` : "—"} />
              <MiniStat label="Net margin" value={inst?.netMargin ? `${inst.netMargin}%` : "—"} />
              <MiniStat label="ROE" value={inst?.roe ? `${inst.roe}%` : "—"} />
              <MiniStat label="Debt / equity" value={inst?.debtEquity?.toFixed(2) ?? "—"} />
              <MiniStat label="EPS growth" value={inst?.epsGrowth ? `${inst.epsGrowth}%` : "—"} />
              <MiniStat label="P/B" value={inst?.pb?.toFixed(2) ?? "—"} />
            </div>
          </Card>
          <Card>
            <CardHead title="Notes" sub="Local-first research notes" icon="journal" />
            <textarea
              value={s.notes[symbol] ?? ""}
              onChange={(e) => actions.setNote(symbol, e.target.value)}
              placeholder="Thesis, levels, catalysts…"
              className="h-24 w-full resize-none rounded-[14px] border border-line bg-subtle p-3 text-[12.5px] outline-none focus:border-brand"
            />
          </Card>
        </div>
      </div>
    </div>
  );
}

function MiniStat({ label, value, tone }: { label: string; value: string; tone?: "pos" | "neg" }) {
  return (
    <div className="rounded-[13px] bg-muted px-3 py-2">
      <p className="text-[10.5px] text-ink3">{label}</p>
      <p className={cn("tabnum text-[13.5px] font-bold", tone === "pos" ? "text-pos" : tone === "neg" ? "text-neg" : "text-ink")}>{value}</p>
    </div>
  );
}

export { correlation };
 { correlation };
