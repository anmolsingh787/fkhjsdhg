import type { Candle } from "./types";

/* ------------------------------------------------------------------ *
 * Primitive series helpers
 * ------------------------------------------------------------------ */
export const closes = (c: Candle[]) => c.map((x) => x.close);
export const highs = (c: Candle[]) => c.map((x) => x.high);
export const lows = (c: Candle[]) => c.map((x) => x.low);
export const vols = (c: Candle[]) => c.map((x) => x.volume);

/** Value point used for plotting: null gaps preserved so charts skip leading values. */
export type Pt = number | null;

function fill(len: number, startIdx: number, values: (number | null)[]): Pt[] {
  const out: Pt[] = new Array(len).fill(null);
  for (let i = 0; i < values.length; i++) out[startIdx + i] = values[i];
  return out;
}

export function sma(src: number[], len: number): Pt[] {
  const out: number[] = [];
  let sum = 0;
  for (let i = 0; i < src.length; i++) {
    sum += src[i];
    if (i >= len) sum -= src[i - len];
    if (i >= len - 1) out.push(sum / len);
  }
  return fill(src.length, len - 1, out);
}

export function ema(src: number[], len: number): Pt[] {
  const k = 2 / (len + 1);
  const out: number[] = [];
  let prev = 0;
  for (let i = 0; i < src.length; i++) {
    if (i === 0) {
      prev = src[0];
      out.push(prev);
      continue;
    }
    prev = src[i] * k + prev * (1 - k);
    out.push(prev);
  }
  return fill(src.length, 0, out);
}

export function wma(src: number[], len: number): Pt[] {
  const denom = (len * (len + 1)) / 2;
  const out: number[] = [];
  for (let i = len - 1; i < src.length; i++) {
    let s = 0;
    for (let j = 0; j < len; j++) s += src[i - j] * (len - j);
    out.push(s / denom);
  }
  return fill(src.length, len - 1, out);
}

export function vwma(c: Candle[], len: number): Pt[] {
  const pv = c.map((x) => x.close * x.volume);
  return div(sma(pv, len), sma(vols(c), len), c.length);
}

function div(a: (number | null)[], b: (number | null)[], len: number): Pt[] {
  const out: Pt[] = new Array(len).fill(null);
  for (let i = 0; i < len; i++) {
    const x = a[i];
    const y = b[i];
    if (x != null && y != null && y !== 0) out[i] = x / y;
  }
  return out;
}

export function hma(src: number[], len: number): Pt[] {
  const half = Math.max(1, Math.floor(len / 2));
  const w1 = wma(src, half).map((v) => v ?? 0);
  const w2 = wma(src, len).map((v) => v ?? 0);
  const raw = src.map((_, i) => 2 * w1[i] - w2[i]);
  return wma(raw, Math.max(1, Math.round(Math.sqrt(len))));
}

export function stdev(src: number[], len: number): Pt[] {
  const m = sma(src, len);
  const out: number[] = [];
  for (let i = len - 1; i < src.length; i++) {
    const mean = m[i] as number;
    let s = 0;
    for (let j = 0; j < len; j++) s += (src[i - j] - mean) ** 2;
    out.push(Math.sqrt(s / len));
  }
  return fill(src.length, len - 1, out);
}

export function vwap(c: Candle[]): Pt[] {
  let pv = 0;
  let vv = 0;
  const out: number[] = [];
  for (const x of c) {
    const tp = (x.high + x.low + x.close) / 3;
    pv += tp * x.volume;
    vv += x.volume;
    out.push(vv ? pv / vv : x.close);
  }
  return fill(c.length, 0, out);
}

export function trueRange(c: Candle[]): number[] {
  return c.map((x, i) =>
    i === 0 ? x.high - x.low : Math.max(x.high - x.low, Math.abs(x.high - c[i - 1].close), Math.abs(x.low - c[i - 1].close)),
  );
}

export function atr(c: Candle[], len = 14): Pt[] {
  return ema(trueRange(c), len);
}

export function rsi(src: number[], len = 14): Pt[] {
  const out: number[] = [];
  let g = 0;
  let l = 0;
  for (let i = 1; i < src.length; i++) {
    const d = src[i] - src[i - 1];
    const up = Math.max(d, 0);
    const dn = Math.max(-d, 0);
    if (i <= len) {
      g += up;
      l += dn;
      if (i === len) {
        g /= len;
        l /= len;
        out.push(l === 0 ? 100 : 100 - 100 / (1 + g / l));
      }
    } else {
      g = (g * (len - 1) + up) / len;
      l = (l * (len - 1) + dn) / len;
      out.push(l === 0 ? 100 : 100 - 100 / (1 + g / l));
    }
  }
  return fill(src.length, len, out);
}

export function macd(src: number[], fast = 12, slow = 26, sig = 9) {
  const f = ema(src, fast);
  const s = ema(src, slow);
  const line = src.map((_, i) => ((f[i] as number) ?? 0) - ((s[i] as number) ?? 0));
  const signal = ema(line, sig);
  const hist = line.map((v, i) => v - ((signal[i] as number) ?? 0));
  return { line: fill(src.length, 0, line), signal: fill(src.length, 0, signal), hist: fill(src.length, 0, hist) };
}

export function stochastic(c: Candle[], len = 14, smoothK = 3, smoothD = 3) {
  const raw: number[] = [];
  for (let i = 0; i < c.length; i++) {
    if (i < len - 1) {
      raw.push(50);
      continue;
    }
    let hi = -Infinity;
    let lo = Infinity;
    for (let j = 0; j < len; j++) {
      hi = Math.max(hi, c[i - j].high);
      lo = Math.min(lo, c[i - j].low);
    }
    raw.push(hi === lo ? 50 : ((c[i].close - lo) / (hi - lo)) * 100);
  }
  const k = sma(raw, smoothK);
  const d = sma(k.map((v) => v ?? 50), smoothD);
  return { k, d };
}

export function stochRsi(src: number[], len = 14) {
  const r = rsi(src, len).map((v) => v ?? 50);
  const k = sma(r, 3);
  const d = sma(k.map((v) => v ?? 50), 3);
  return { k, d };
}

export function cci(c: Candle[], len = 20): Pt[] {
  const tp = c.map((x) => (x.high + x.low + x.close) / 3);
  const m = sma(tp, len);
  const out: number[] = [];
  for (let i = len - 1; i < tp.length; i++) {
    const mean = m[i] as number;
    let dev = 0;
    for (let j = 0; j < len; j++) dev += Math.abs(tp[i - j] - mean);
    dev /= len;
    out.push(dev === 0 ? 0 : (tp[i] - mean) / (0.015 * dev));
  }
  return fill(c.length, len - 1, out);
}

export function roc(src: number[], len = 12): Pt[] {
  const out: number[] = [];
  for (let i = len; i < src.length; i++) out.push(((src[i] - src[i - len]) / src[i - len]) * 100);
  return fill(src.length, len, out);
}

export function williamsR(c: Candle[], len = 14): Pt[] {
  const out: number[] = [];
  for (let i = len - 1; i < c.length; i++) {
    let hi = -Infinity;
    let lo = Infinity;
    for (let j = 0; j < len; j++) {
      hi = Math.max(hi, c[i - j].high);
      lo = Math.min(lo, c[i - j].low);
    }
    out.push(hi === lo ? -50 : ((hi - c[i].close) / (hi - lo)) * -100);
  }
  return fill(c.length, len - 1, out);
}

export function mfi(c: Candle[], len = 14): Pt[] {
  const tp = c.map((x) => (x.high + x.low + x.close) / 3);
  const out: number[] = [];
  for (let i = len; i < c.length; i++) {
    let pos = 0;
    let neg = 0;
    for (let j = 0; j < len; j++) {
      const k = i - j;
      const flow = tp[k] * c[k].volume;
      if (tp[k] > tp[k - 1]) pos += flow;
      else neg += flow;
    }
    out.push(neg === 0 ? 100 : 100 - 100 / (1 + pos / neg));
  }
  return fill(c.length, len, out);
}

export function trix(src: number[], len = 15): Pt[] {
  const e1 = ema(src, len).map((v) => v ?? 0);
  const e2 = ema(e1, len).map((v) => v ?? 0);
  const e3 = ema(e2, len).map((v) => v ?? 0);
  const out = e3.map((v, i) => (i === 0 || e3[i - 1] === 0 ? 0 : ((v - e3[i - 1]) / e3[i - 1]) * 10000));
  return fill(src.length, 1, out.slice(1));
}

export function ppo(src: number[], fast = 12, slow = 26, sig = 9) {
  const f = ema(src, fast);
  const s = ema(src, slow);
  const line = src.map((_, i) => (s[i] ? (((f[i] as number) - (s[i] as number)) / (s[i] as number)) * 100 : 0));
  const signal = ema(line, sig);
  const hist = line.map((v, i) => v - ((signal[i] as number) ?? 0));
  return { line: fill(src.length, 0, line), signal: fill(src.length, 0, signal), hist: fill(src.length, 0, hist) };
}

export function ultimateOsc(c: Candle[], p = 7, m = 14, l = 28): Pt[] {
  const bp: number[] = [];
  const tr: number[] = [];
  for (let i = 0; i < c.length; i++) {
    const prevClose = i === 0 ? c[0].close : c[i - 1].close;
    bp.push(c[i].close - Math.min(c[i].low, prevClose));
    tr.push(Math.max(c[i].high, prevClose) - Math.min(c[i].low, prevClose));
  }
  const out: number[] = [];
  for (let i = l; i < c.length; i++) {
    const s = (n: number[], len: number) => n.slice(i - len + 1, i + 1).reduce((a, b) => a + b, 0);
    const a = s(bp, p) / (s(tr, p) || 1);
    const b = s(bp, m) / (s(tr, m) || 1);
    const d = s(bp, l) / (s(tr, l) || 1);
    out.push((100 * (4 * a + 2 * b + d)) / 7);
  }
  return fill(c.length, l, out);
}

export function awesomeOsc(c: Candle[]): Pt[] {
  const mp = c.map((x) => (x.high + x.low) / 2);
  const f = sma(mp, 5);
  const s = sma(mp, 34);
  return mp.map((_, i) => ((f[i] as number) ?? 0) - ((s[i] as number) ?? 0));
}

export function momentum(src: number[], len = 10): Pt[] {
  return src.map((v, i) => (i < len ? null : v - src[i - len]));
}

export function rvi(c: Candle[], len = 10): Pt[] {
  const out: number[] = [];
  for (let i = len; i < c.length; i++) {
    let num = 0;
    let den = 0;
    for (let j = 0; j < len; j++) {
      const k = i - j;
      num += (c[k].close - c[k].open) + 2 * (c[k - 1].close - c[k - 1].open) + (c[k - 2].close - c[k - 2].open);
      den += (c[k].high - c[k].low) + 2 * (c[k - 1].high - c[k - 1].low) + (c[k - 2].high - c[k - 2].low);
    }
    out.push(den === 0 ? 0 : num / den);
  }
  return fill(c.length, len, out);
}

/* ---------------- volatility ---------------- */
export function histVol(src: number[], len = 20): Pt[] {
  const rets = src.map((v, i) => (i === 0 ? 0 : Math.log(v / src[i - 1])));
  return stdev(rets.slice(1), len).map((v) => (v == null ? null : v * Math.sqrt(252) * 100));
}

export function bbWidth(src: number[], len = 20, mult = 2): Pt[] {
  const m = sma(src, len);
  const sd = stdev(src, len);
  return src.map((_v, i) => {
    const a = m[i];
    const b = sd[i];
    if (a == null || b == null || a === 0) return null;
    return ((2 * mult * b) / a) * 100;
  });
}

export function chaikinVol(c: Candle[], len = 10): Pt[] {
  const tr = ema(trueRange(c), len).map((v) => v ?? 0);
  const out: number[] = [];
  for (let i = len; i < tr.length; i++) out.push(tr[i - len] === 0 ? 0 : ((tr[i] - tr[i - len]) / tr[i - len]) * 100);
  return fill(c.length, len, out);
}

/* ---------------- volume ---------------- */
export function obv(c: Candle[]): Pt[] {
  let acc = 0;
  const out: number[] = [];
  for (let i = 0; i < c.length; i++) {
    if (i > 0) acc += c[i].close > c[i - 1].close ? c[i].volume : c[i].close < c[i - 1].close ? -c[i].volume : 0;
    out.push(acc);
  }
  return fill(c.length, 0, out);
}

export function adLine(c: Candle[]): Pt[] {
  let acc = 0;
  const out: number[] = [];
  for (const x of c) {
    const range = x.high - x.low;
    const mfm = range === 0 ? 0 : ((x.close - x.low) - (x.high - x.close)) / range;
    acc += mfm * x.volume;
    out.push(acc);
  }
  return fill(c.length, 0, out);
}

export function cmf(c: Candle[], len = 20): Pt[] {
  const mfv = c.map((x) => {
    const range = x.high - x.low;
    const mfm = range === 0 ? 0 : ((x.close - x.low) - (x.high - x.close)) / range;
    return mfm * x.volume;
  });
  return div(sma(mfv, len), sma(vols(c), len), c.length);
}

export function volumeOsc(c: Candle[], fast = 5, slow = 10): Pt[] {
  const f = sma(vols(c), fast);
  const s = sma(vols(c), slow);
  return c.map((_, i) => {
    const a = f[i];
    const b = s[i];
    if (a == null || b == null || b === 0) return null;
    return ((a - b) / b) * 100;
  });
}

export function relVolume(c: Candle[], len = 20): Pt[] {
  const m = sma(vols(c), len);
  return c.map((x, i) => (m[i] == null ? null : x.volume / (m[i] as number)));
}

/* ---------------- overlays ---------------- */
export function bollinger(src: number[], len = 20, mult = 2) {
  const mid = sma(src, len);
  const sd = stdev(src, len);
  const upper = src.map((_, i) => (mid[i] == null || sd[i] == null ? null : (mid[i] as number) + mult * (sd[i] as number)));
  const lower = src.map((_, i) => (mid[i] == null || sd[i] == null ? null : (mid[i] as number) - mult * (sd[i] as number)));
  return { mid, upper, lower };
}

export function keltner(c: Candle[], len = 20, mult = 2) {
  const mid = ema(closes(c), len);
  const a = atr(c, len);
  return {
    mid,
    upper: c.map((_, i) => (mid[i] == null || a[i] == null ? null : (mid[i] as number) + mult * (a[i] as number))),
    lower: c.map((_, i) => (mid[i] == null || a[i] == null ? null : (mid[i] as number) - mult * (a[i] as number))),
  };
}

export function donchian(c: Candle[], len = 20) {
  const up: Pt[] = [];
  const dn: Pt[] = [];
  for (let i = 0; i < c.length; i++) {
    if (i < len - 1) {
      up.push(null);
      dn.push(null);
      continue;
    }
    let hi = -Infinity;
    let lo = Infinity;
    for (let j = 0; j < len; j++) {
      hi = Math.max(hi, c[i - j].high);
      lo = Math.min(lo, c[i - j].low);
    }
    up.push(hi);
    dn.push(lo);
  }
  const mid = up.map((v, i) => (v == null || dn[i] == null ? null : (v + (dn[i] as number)) / 2));
  return { upper: up, lower: dn, mid };
}

export function supertrend(c: Candle[], len = 10, mult = 3) {
  const a = atr(c, len);
  const dir: Pt[] = [];
  const line: Pt[] = [];
  let up = 0;
  let dn = 0;
  let trend = 1;
  for (let i = 0; i < c.length; i++) {
    const av = a[i];
    if (av == null) {
      dir.push(null);
      line.push(null);
      continue;
    }
    const mid = (c[i].high + c[i].low) / 2;
    let nUp = mid - mult * av;
    let nDn = mid + mult * av;
    const prevClose = i > 0 ? c[i - 1].close : c[i].close;
    nUp = prevClose > up ? Math.max(nUp, up) : nUp;
    nDn = prevClose < dn ? Math.min(nDn, dn) : nDn;
    if (c[i].close > dn) trend = 1;
    else if (c[i].close < up) trend = -1;
    up = nUp;
    dn = nDn;
    dir.push(trend);
    line.push(trend === 1 ? nUp : nDn);
  }
  return { dir, line };
}

export function ichimoku(c: Candle[], conv = 9, base = 26, spanB = 52) {
  const donch = (len: number) => {
    const out: Pt[] = [];
    for (let i = 0; i < c.length; i++) {
      if (i < len - 1) {
        out.push(null);
        continue;
      }
      let hi = -Infinity;
      let lo = Infinity;
      for (let j = 0; j < len; j++) {
        hi = Math.max(hi, c[i - j].high);
        lo = Math.min(lo, c[i - j].low);
      }
      out.push((hi + lo) / 2);
    }
    return out;
  };
  return { tenkan: donch(conv), kijun: donch(base), senkouB: donch(spanB) };
}

export function psar(c: Candle[], step = 0.02, max = 0.2): Pt[] {
  const out: Pt[] = [];
  let bull = true;
  let af = step;
  let ep = c[0].high;
  let sar = c[0].low;
  for (let i = 0; i < c.length; i++) {
    if (i === 0) {
      out.push(sar);
      continue;
    }
    sar = sar + af * (ep - sar);
    if (bull) {
      if (c[i].low < sar) {
        bull = false;
        sar = ep;
        ep = c[i].low;
        af = step;
      } else if (c[i].high > ep) {
        ep = c[i].high;
        af = Math.min(max, af + step);
      }
    } else {
      if (c[i].high > sar) {
        bull = true;
        sar = ep;
        ep = c[i].high;
        af = step;
      } else if (c[i].low < ep) {
        ep = c[i].low;
        af = Math.min(max, af + step);
      }
    }
    out.push(sar);
  }
  return out;
}

export function linReg(src: number[], len = 100): Pt[] {
  const out: Pt[] = [];
  for (let i = 0; i < src.length; i++) {
    const start = Math.max(0, i - len + 1);
    const n = i - start + 1;
    let sx = 0;
    let sy = 0;
    let sxy = 0;
    let sxx = 0;
    for (let j = 0; j < n; j++) {
      const x = j;
      const y = src[start + j];
      sx += x;
      sy += y;
      sxy += x * y;
      sxx += x * x;
    }
    const slope = (n * sxy - sx * sy) / (n * sxx - sx * sx || 1);
    const intercept = (sy - slope * sx) / n;
    out.push(intercept + slope * (n - 1));
  }
  return fill(src.length, 0, out);
}

export function maRibbon(src: number[], lens = [8, 13, 21, 34, 55, 89]) {
  return lens.map((l) => ({ len: l, values: ema(src, l) }));
}

/* ---------------- transforms ---------------- */
export function heikinAshi(c: Candle[]): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i < c.length; i++) {
    const close = (c[i].open + c[i].high + c[i].low + c[i].close) / 4;
    const open = i === 0 ? (c[0].open + c[0].close) / 2 : (out[i - 1].open + out[i - 1].close) / 2;
    out.push({
      time: c[i].time,
      open,
      close,
      high: Math.max(c[i].high, open, close),
      low: Math.min(c[i].low, open, close),
      volume: c[i].volume,
    });
  }
  return out;
}

export function renko(c: Candle[], brickPct = 0.012): Candle[] {
  const out: Candle[] = [];
  const brick = c[0].close * brickPct;
  let base = c[0].close;
  for (const x of c) {
    while (x.close >= base + brick) {
      out.push({ time: x.time, open: base, close: base + brick, high: base + brick, low: base, volume: x.volume });
      base += brick;
    }
    while (x.close <= base - brick) {
      out.push({ time: x.time, open: base, close: base - brick, high: base, low: base - brick, volume: x.volume });
      base -= brick;
    }
  }
  return out.length ? out : c;
}

export function rangeBars(c: Candle[], pct = 0.008): Candle[] {
  const out: Candle[] = [];
  let cur: Candle | null = null;
  const size = c[0].close * pct;
  for (const x of c) {
    if (!cur) cur = { ...x };
    cur.high = Math.max(cur.high, x.high);
    cur.low = Math.min(cur.low, x.low);
    cur.close = x.close;
    cur.volume += x.volume;
    if (cur.high - cur.low >= size) {
      out.push(cur);
      cur = null;
    }
  }
  if (cur) out.push(cur);
  return out.length ? out : c;
}

/* ---------------- portfolio math ---------------- */
export function returns(src: number[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < src.length; i++) out.push(src[i - 1] === 0 ? 0 : src[i] / src[i - 1] - 1);
  return out;
}

export function maxDrawdown(src: number[]): number {
  let peak = -Infinity;
  let mdd = 0;
  for (const v of src) {
    peak = Math.max(peak, v);
    mdd = Math.min(mdd, v / peak - 1);
  }
  return mdd * 100;
}

export function drawdownSeries(src: number[]): number[] {
  let peak = -Infinity;
  return src.map((v) => {
    peak = Math.max(peak, v);
    return (v / peak - 1) * 100;
  });
}

export function sharpe(src: number[], rf = 0.05): number {
  const r = returns(src);
  if (!r.length) return 0;
  const mean = r.reduce((a, b) => a + b, 0) / r.length;
  const sd = Math.sqrt(r.reduce((a, b) => a + (b - mean) ** 2, 0) / r.length) || 1;
  return ((mean - rf / 252) / sd) * Math.sqrt(252);
}

export function correlation(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length);
  if (n < 3) return 0;
  const x = a.slice(-n);
  const y = b.slice(-n);
  const mx = x.reduce((s, v) => s + v, 0) / n;
  const my = y.reduce((s, v) => s + v, 0) / n;
  let num = 0;
  let dx = 0;
  let dy = 0;
  for (let i = 0; i < n; i++) {
    num += (x[i] - mx) * (y[i] - my);
    dx += (x[i] - mx) ** 2;
    dy += (y[i] - my) ** 2;
  }
  return dx && dy ? num / Math.sqrt(dx * dy) : 0;
}

export function beta(stock: number[], bench: number[]): number {
  const n = Math.min(stock.length, bench.length);
  const rs = returns(stock.slice(-n));
  const rb = returns(bench.slice(-n));
  const mb = rb.reduce((s, v) => s + v, 0) / (rb.length || 1);
  const ms = rs.reduce((s, v) => s + v, 0) / (rs.length || 1);
  let num = 0;
  let den = 0;
  for (let i = 0; i < rb.length; i++) {
    num += (rb[i] - mb) * (rs[i] - ms);
    den += (rb[i] - mb) ** 2;
  }
  return den ? num / den : 1;
}

export function alpha(stock: number[], bench: number[]): number {
  const b = beta(stock, bench);
  const rs = returns(stock);
  const rb = returns(bench);
  const annual = (arr: number[]) => (arr.reduce((s, v) => s + v, 0) / (arr.length || 1)) * 252 * 100;
  return annual(rs) - 0.05 - b * (annual(rb) - 0.05);
}

export function rolling(src: number[], len: number, fn: (win: number[]) => number): Pt[] {
  const out: Pt[] = [];
  for (let i = 0; i < src.length; i++) out.push(i < len ? null : fn(src.slice(i - len + 1, i + 1)));
  return out;
}

export function cagr(src: number[], years: number): number {
  if (src.length < 2 || src[0] <= 0) return 0;
  return ((src[src.length - 1] / src[0]) ** (1 / years) - 1) * 100;
}

/* ---------------- catalog ---------------- */
export interface IndicatorMeta {
  id: string;
  name: string;
  group: "Trend" | "Momentum" | "Volatility" | "Volume" | "Breadth" | "Portfolio";
  pane: "overlay" | "sub";
  params?: { key: string; label: string; def: number }[];
}

export const INDICATOR_CATALOG: IndicatorMeta[] = [
  { id: "sma20", name: "SMA 20", group: "Trend", pane: "overlay" },
  { id: "sma50", name: "SMA 50", group: "Trend", pane: "overlay" },
  { id: "sma200", name: "SMA 200", group: "Trend", pane: "overlay" },
  { id: "ema9", name: "EMA 9", group: "Trend", pane: "overlay" },
  { id: "ema21", name: "EMA 21", group: "Trend", pane: "overlay" },
  { id: "ema50", name: "EMA 50", group: "Trend", pane: "overlay" },
  { id: "wma20", name: "WMA 20", group: "Trend", pane: "overlay" },
  { id: "vwma20", name: "VWMA 20", group: "Trend", pane: "overlay" },
  { id: "hma21", name: "HMA 21", group: "Trend", pane: "overlay" },
  { id: "vwap", name: "VWAP", group: "Trend", pane: "overlay" },
  { id: "bb", name: "Bollinger Bands", group: "Trend", pane: "overlay", params: [{ key: "len", label: "Length", def: 20 }] },
  { id: "keltner", name: "Keltner Channels", group: "Trend", pane: "overlay" },
  { id: "donchian", name: "Donchian Channels", group: "Trend", pane: "overlay" },
  { id: "supertrend", name: "Supertrend", group: "Trend", pane: "overlay" },
  { id: "ichimoku", name: "Ichimoku Cloud", group: "Trend", pane: "overlay" },
  { id: "psar", name: "Parabolic SAR", group: "Trend", pane: "overlay" },
  { id: "linreg", name: "Linear Regression", group: "Trend", pane: "overlay" },
  { id: "ribbon", name: "MA Ribbon", group: "Trend", pane: "overlay" },
  { id: "rsi", name: "RSI", group: "Momentum", pane: "sub" },
  { id: "macd", name: "MACD", group: "Momentum", pane: "sub" },
  { id: "stoch", name: "Stochastic", group: "Momentum", pane: "sub" },
  { id: "stochrsi", name: "Stochastic RSI", group: "Momentum", pane: "sub" },
  { id: "cci", name: "CCI", group: "Momentum", pane: "sub" },
  { id: "roc", name: "Rate of Change", group: "Momentum", pane: "sub" },
  { id: "willr", name: "Williams %R", group: "Momentum", pane: "sub" },
  { id: "mfi", name: "Money Flow Index", group: "Momentum", pane: "sub" },
  { id: "trix", name: "TRIX", group: "Momentum", pane: "sub" },
  { id: "ppo", name: "PPO", group: "Momentum", pane: "sub" },
  { id: "uo", name: "Ultimate Oscillator", group: "Momentum", pane: "sub" },
  { id: "ao", name: "Awesome Oscillator", group: "Momentum", pane: "sub" },
  { id: "mom", name: "Momentum", group: "Momentum", pane: "sub" },
  { id: "rvi", name: "Relative Vigor Index", group: "Momentum", pane: "sub" },
  { id: "atr", name: "ATR", group: "Volatility", pane: "sub" },
  { id: "histvol", name: "Historical Volatility", group: "Volatility", pane: "sub" },
  { id: "stdev", name: "Standard Deviation", group: "Volatility", pane: "sub" },
  { id: "bbwidth", name: "Bollinger Width", group: "Volatility", pane: "sub" },
  { id: "chaikinvol", name: "Chaikin Volatility", group: "Volatility", pane: "sub" },
  { id: "volume", name: "Volume", group: "Volume", pane: "sub" },
  { id: "obv", name: "On Balance Volume", group: "Volume", pane: "sub" },
  { id: "adline", name: "Accumulation / Distribution", group: "Volume", pane: "sub" },
  { id: "cmf", name: "Chaikin Money Flow", group: "Volume", pane: "sub" },
  { id: "volosc", name: "Volume Oscillator", group: "Volume", pane: "sub" },
  { id: "relvol", name: "Relative Volume", group: "Volume", pane: "sub" },
  { id: "vwapdev", name: "VWAP Deviation", group: "Volume", pane: "sub" },
  { id: "volprofile", name: "Volume Profile", group: "Volume", pane: "overlay" },
  { id: "adline_mkt", name: "Advance / Decline", group: "Breadth", pane: "sub" },
  { id: "nhnl", name: "New High / New Low", group: "Breadth", pane: "sub" },
  { id: "relperf", name: "Relative Performance", group: "Breadth", pane: "sub" },
  { id: "sectorrs", name: "Sector Relative Strength", group: "Breadth", pane: "sub" },
  { id: "corr", name: "Index Correlation", group: "Breadth", pane: "sub" },
  { id: "equity", name: "Equity Curve", group: "Portfolio", pane: "sub" },
  { id: "drawdown", name: "Drawdown", group: "Portfolio", pane: "sub" },
  { id: "rollret", name: "Rolling Return", group: "Portfolio", pane: "sub" },
  { id: "rollvol", name: "Rolling Volatility", group: "Portfolio", pane: "sub" },
  { id: "sharpe", name: "Sharpe Ratio", group: "Portfolio", pane: "sub" },
  { id: "beta", name: "Beta", group: "Portfolio", pane: "sub" },
  { id: "alpha", name: "Alpha", group: "Portfolio", pane: "sub" },
  { id: "corrmatrix", name: "Correlation Matrix", group: "Portfolio", pane: "sub" },
  { id: "sectalloc", name: "Sector Allocation", group: "Portfolio", pane: "sub" },
  { id: "countryalloc", name: "Country Allocation", group: "Portfolio", pane: "sub" },
  { id: "monthlypl", name: "Monthly P&L Heatmap", group: "Portfolio", pane: "sub" },
  { id: "winloss", name: "Win / Loss Distribution", group: "Portfolio", pane: "sub" },
];

export const INDICATOR_GROUPS = ["Trend", "Momentum", "Volatility", "Volume", "Breadth", "Portfolio"] as const;
